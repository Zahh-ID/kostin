import { useState, useEffect } from "react";
import { CreditCard, X } from "lucide-react";
import { Button } from "./ui/button";

interface FloatingPayButtonProps {
  amount: number;
  onPayClick: () => void;
}

export function FloatingPayButton({ amount, onPayClick }: FloatingPayButtonProps) {
  const [isVisible, setIsVisible] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      // Show button when scrolled down 300px
      setIsVisible(window.scrollY > 300);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll)  ;
  }, []);

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <div className="relative">
        {/* Expanded Card */}
        {isExpanded && (
          <div className="absolute bottom-full right-0 mb-4 bg-white rounded-xl shadow-2xl border border-gray-200 p-4 w-64">
            <div className="flex items-start justify-between mb-3">
              <div>
                <p className="text-sm text-gray-600 mb-1">Tagihan Pending</p>
                <p className="text-xl text-blue-600">
                  Rp {amount.toLocaleString('id-ID')}
                </p>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6 -mt-1 -mr-1"
                onClick={(e) => {
                  e.stopPropagation();
                  setIsExpanded(false);
                }}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
            <Button
              className="w-full bg-blue-600 hover:bg-blue-700"
              onClick={onPayClick}
            >
              <CreditCard className="h-4 w-4 mr-2" />
              Bayar Sekarang
            </Button>
            <p className="text-xs text-gray-500 text-center mt-2">
              Via QRIS, GoPay, ShopeePay
            </p>
          </div>
        )}

        {/* Main Button */}
        <div className="transition-transform hover:scale-105 active:scale-95">
          <Button
            size="lg"
            className="h-16 w-16 rounded-full bg-gradient-to-br from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 shadow-2xl relative"
            onClick={() => setIsExpanded(!isExpanded)}
          >
            {/* Pulse Animation */}
            <span className="absolute inset-0 rounded-full bg-blue-400 animate-ping opacity-75" />
            
            {/* Icon */}
            <CreditCard className="h-7 w-7 relative z-10" />
            
            {/* Badge */}
            <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-6 w-6 flex items-center justify-center z-10 animate-bounce">
              1
            </span>
          </Button>
        </div>
      </div>
    </div>
  );
}
