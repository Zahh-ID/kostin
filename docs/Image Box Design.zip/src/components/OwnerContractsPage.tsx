import { useState } from "react";
import { 
  ArrowLeft, 
  FileText, 
  Calendar, 
  Download,
  CheckCircle,
  Clock,
  AlertCircle,
  Plus,
  Search,
  Filter,
  Eye,
  Edit,
  XCircle
} from "lucide-react";
import { Card, CardContent, CardHeader } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "./ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import { Separator } from "./ui/separator";

interface OwnerContractsPageProps {
  onNavigate: (path: string) => void;
}

export function OwnerContractsPage({ onNavigate }: OwnerContractsPageProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [propertyFilter, setPropertyFilter] = useState("all");
  const [selectedContract, setSelectedContract] = useState<any>(null);

  const contracts = [
    {
      id: "CTR-2024-001",
      property: "Kos Melati Residence",
      room: "Kamar 101",
      roomType: "Tipe A - Standard",
      tenant: "Ahmad Fauzi",
      tenantEmail: "ahmad@email.com",
      tenantPhone: "+62 812-1234-5678",
      startDate: "2024-01-01",
      endDate: "2024-12-31",
      monthlyRent: 1200000,
      deposit: 2400000,
      status: "active",
      daysRemaining: 61,
      signedDate: "2023-12-20",
      paymentDue: 5,
    },
    {
      id: "CTR-2024-002",
      property: "Kos Mawar Indah",
      room: "Kamar 201",
      roomType: "Tipe B - Deluxe",
      tenant: "Siti Nurhaliza",
      tenantEmail: "siti@email.com",
      tenantPhone: "+62 813-2345-6789",
      startDate: "2024-02-01",
      endDate: "2025-01-31",
      monthlyRent: 1500000,
      deposit: 3000000,
      status: "active",
      daysRemaining: 92,
      signedDate: "2024-01-25",
      paymentDue: 5,
    },
    {
      id: "CTR-2024-003",
      property: "Kos Anggrek Premium",
      room: "Kamar 301",
      roomType: "Tipe C - Suite",
      tenant: "Budi Santoso",
      tenantEmail: "budi@email.com",
      tenantPhone: "+62 814-3456-7890",
      startDate: "2024-03-01",
      endDate: "2024-11-15",
      monthlyRent: 1800000,
      deposit: 3600000,
      status: "active",
      daysRemaining: 15,
      signedDate: "2024-02-20",
      paymentDue: 1,
    },
    {
      id: "CTR-2023-045",
      property: "Kos Melati Residence",
      room: "Kamar 102",
      roomType: "Tipe A - Standard",
      tenant: "Dewi Lestari",
      tenantEmail: "dewi@email.com",
      tenantPhone: "+62 815-4567-8901",
      startDate: "2023-06-01",
      endDate: "2024-05-31",
      monthlyRent: 1200000,
      deposit: 2400000,
      status: "expired",
      signedDate: "2023-05-15",
      paymentDue: 5,
    },
  ];

  const properties = [
    { id: 1, name: "Kos Melati Residence" },
    { id: 2, name: "Kos Mawar Indah" },
    { id: 3, name: "Kos Anggrek Premium" },
  ];

  const filteredContracts = contracts.filter((contract) => {
    const matchesSearch = 
      contract.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contract.tenant.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contract.room.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "all" || contract.status === statusFilter;
    const matchesProperty = propertyFilter === "all" || contract.property === propertyFilter;
    return matchesSearch && matchesStatus && matchesProperty;
  });

  const getStatusBadge = (status: string, daysRemaining?: number) => {
    if (status === "active") {
      if (daysRemaining && daysRemaining <= 30) {
        return (
          <Badge className="bg-orange-500">
            <Clock className="h-3 w-3 mr-1" />
            Akan Berakhir
          </Badge>
        );
      }
      return (
        <Badge className="bg-green-500">
          <CheckCircle className="h-3 w-3 mr-1" />
          Aktif
        </Badge>
      );
    } else if (status === "expired") {
      return (
        <Badge className="bg-red-500">
          <XCircle className="h-3 w-3 mr-1" />
          Berakhir
        </Badge>
      );
    } else if (status === "draft") {
      return (
        <Badge className="bg-gray-500">
          <FileText className="h-3 w-3 mr-1" />
          Draft
        </Badge>
      );
    }
    return null;
  };

  const stats = [
    {
      label: "Total Kontrak",
      value: contracts.length,
      color: "text-blue-600",
    },
    {
      label: "Kontrak Aktif",
      value: contracts.filter(c => c.status === "active").length,
      color: "text-green-600",
    },
    {
      label: "Akan Berakhir (30 hari)",
      value: contracts.filter(c => c.status === "active" && c.daysRemaining && c.daysRemaining <= 30).length,
      color: "text-orange-600",
    },
    {
      label: "Berakhir",
      value: contracts.filter(c => c.status === "expired").length,
      color: "text-red-600",
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => onNavigate('/owner/dashboard')}
            className="mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Kembali ke Dashboard
          </Button>
          <div className="flex items-center justify-between">
            <div>
              <h1>Kelola Kontrak</h1>
              <p className="text-gray-600">Kelola semua kontrak sewa di properti Anda</p>
            </div>
            <Button onClick={() => onNavigate('/owner/contracts/create')}>
              <Plus className="h-4 w-4 mr-2" />
              Buat Kontrak Baru
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          {stats.map((stat) => (
            <Card key={stat.label}>
              <CardContent className="p-6">
                <p className="text-sm text-gray-600 mb-1">{stat.label}</p>
                <p className={`text-2xl ${stat.color}`}>{stat.value}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Cari kontrak, penyewa, atau kamar..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={propertyFilter} onValueChange={setPropertyFilter}>
                <SelectTrigger className="w-full md:w-[200px]">
                  <SelectValue placeholder="Properti" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Semua Properti</SelectItem>
                  {properties.map((property) => (
                    <SelectItem key={property.id} value={property.name}>
                      {property.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full md:w-[200px]">
                  <Filter className="h-4 w-4 mr-2" />
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Semua Status</SelectItem>
                  <SelectItem value="active">Aktif</SelectItem>
                  <SelectItem value="expired">Berakhir</SelectItem>
                  <SelectItem value="draft">Draft</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Contracts Table */}
        <Card>
          <CardHeader>
            <h2>Daftar Kontrak</h2>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>No. Kontrak</TableHead>
                  <TableHead>Penyewa</TableHead>
                  <TableHead>Properti</TableHead>
                  <TableHead>Periode</TableHead>
                  <TableHead>Biaya Bulanan</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Aksi</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredContracts.map((contract) => (
                  <TableRow key={contract.id}>
                    <TableCell>
                      <div>
                        <p>{contract.id}</p>
                        <p className="text-sm text-gray-500">
                          {new Date(contract.signedDate).toLocaleDateString('id-ID')}
                        </p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <p>{contract.tenant}</p>
                        <p className="text-sm text-gray-500">{contract.tenantEmail}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <p>{contract.property}</p>
                        <p className="text-sm text-gray-500">{contract.room}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <p className="text-sm">
                          {new Date(contract.startDate).toLocaleDateString('id-ID')}
                        </p>
                        <p className="text-sm">
                          s/d {new Date(contract.endDate).toLocaleDateString('id-ID')}
                        </p>
                        {contract.daysRemaining && contract.status === "active" && (
                          <p className={`text-xs ${contract.daysRemaining <= 30 ? 'text-orange-600' : 'text-gray-500'}`}>
                            {contract.daysRemaining} hari lagi
                          </p>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <p>Rp {contract.monthlyRent.toLocaleString('id-ID')}</p>
                    </TableCell>
                    <TableCell>{getStatusBadge(contract.status, contract.daysRemaining)}</TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setSelectedContract(contract)}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        {contract.status === "active" && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => alert("Edit kontrak")}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      {/* Contract Detail Dialog */}
      <Dialog open={!!selectedContract} onOpenChange={() => setSelectedContract(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Detail Kontrak</DialogTitle>
          </DialogHeader>
          {selectedContract && (
            <div className="space-y-6">
              {/* Header */}
              <div className="flex items-start justify-between">
                <div>
                  <h2>{selectedContract.property}</h2>
                  <p className="text-gray-600">{selectedContract.room}</p>
                </div>
                {getStatusBadge(selectedContract.status, selectedContract.daysRemaining)}
              </div>

              <Separator />

              {/* Contract & Tenant Info */}
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="mb-4">Informasi Kontrak</h3>
                  <div className="space-y-3">
                    <div>
                      <p className="text-sm text-gray-600">No. Kontrak</p>
                      <p>{selectedContract.id}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Tanggal Ditandatangani</p>
                      <p>{new Date(selectedContract.signedDate).toLocaleDateString('id-ID')}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Periode Kontrak</p>
                      <p>
                        {new Date(selectedContract.startDate).toLocaleDateString('id-ID')} - {new Date(selectedContract.endDate).toLocaleDateString('id-ID')}
                      </p>
                    </div>
                    {selectedContract.daysRemaining && selectedContract.status === "active" && (
                      <div>
                        <p className="text-sm text-gray-600">Sisa Waktu</p>
                        <p className={selectedContract.daysRemaining <= 30 ? "text-orange-600" : ""}>
                          {selectedContract.daysRemaining} hari
                        </p>
                      </div>
                    )}
                  </div>
                </div>

                <div>
                  <h3 className="mb-4">Informasi Penyewa</h3>
                  <div className="space-y-3">
                    <div>
                      <p className="text-sm text-gray-600">Nama Penyewa</p>
                      <p>{selectedContract.tenant}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Email</p>
                      <p>{selectedContract.tenantEmail}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Telepon</p>
                      <p>{selectedContract.tenantPhone}</p>
                    </div>
                  </div>
                </div>
              </div>

              <Separator />

              {/* Financial */}
              <div>
                <h3 className="mb-4">Informasi Keuangan</h3>
                <div className="space-y-3">
                  <div className="flex justify-between p-3 bg-gray-50 rounded-lg">
                    <span className="text-gray-600">Biaya Sewa Bulanan</span>
                    <span className="text-blue-600">
                      Rp {selectedContract.monthlyRent.toLocaleString('id-ID')}
                    </span>
                  </div>
                  <div className="flex justify-between p-3 bg-gray-50 rounded-lg">
                    <span className="text-gray-600">Deposit</span>
                    <span>Rp {selectedContract.deposit.toLocaleString('id-ID')}</span>
                  </div>
                  <div className="flex justify-between p-3 bg-gray-50 rounded-lg">
                    <span className="text-gray-600">Tanggal Jatuh Tempo</span>
                    <span>Setiap tanggal {selectedContract.paymentDue}</span>
                  </div>
                </div>
              </div>

              {/* Expiration Warning */}
              {selectedContract.daysRemaining && selectedContract.daysRemaining <= 30 && selectedContract.status === "active" && (
                <>
                  <Separator />
                  <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <AlertCircle className="h-5 w-5 text-orange-600" />
                      <p className="text-orange-800">
                        Kontrak akan berakhir dalam {selectedContract.daysRemaining} hari
                      </p>
                    </div>
                    <p className="text-sm text-orange-700 mb-3">
                      Hubungi penyewa untuk diskusi perpanjangan kontrak.
                    </p>
                    <Button size="sm" className="bg-orange-600 hover:bg-orange-700">
                      Perpanjang Kontrak
                    </Button>
                  </div>
                </>
              )}

              {/* Actions */}
              <div className="flex gap-2 pt-4 border-t">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => alert("Download PDF")}
                >
                  <Download className="h-4 w-4 mr-2" />
                  Download PDF
                </Button>
                {selectedContract.status === "active" && (
                  <Button
                    variant="outline"
                    className="flex-1"
                    onClick={() => alert("Edit kontrak")}
                  >
                    <Edit className="h-4 w-4 mr-2" />
                    Edit
                  </Button>
                )}
                <Button
                  variant="outline"
                  onClick={() => setSelectedContract(null)}
                >
                  Tutup
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
