import { CreditCard, X, AlertTriangle } from "lucide-react";
import { Button } from "./ui/button";
import { useState } from "react";

interface PaymentBannerProps {
  amount: number;
  dueDate: string;
  daysUntilDue: number;
  onPayClick: () => void;
}

export function PaymentBanner({ amount, dueDate, daysUntilDue, onPayClick }: PaymentBannerProps) {
  const [dismissed, setDismissed] = useState(false);

  if (dismissed) return null;

  const isUrgent = daysUntilDue <= 3;
  const isOverdue = daysUntilDue < 0;

  return (
    <div className={`
      relative overflow-hidden border-b-4
      ${isOverdue ? 'bg-gradient-to-r from-red-600 to-red-700 border-red-800' : 
        isUrgent ? 'bg-gradient-to-r from-orange-600 to-orange-700 border-orange-800' : 
        'bg-gradient-to-r from-blue-600 to-blue-700 border-blue-800'}
    `}>
      {/* Animated Background */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0 animate-pulse" style={{
          backgroundImage: `repeating-linear-gradient(
            45deg,
            transparent,
            transparent 10px,
            currentColor 10px,
            currentColor 20px
          )`
        }} />
      </div>

      <div className="container mx-auto px-4 relative">
        <div className="py-4 flex flex-col md:flex-row items-center justify-between gap-4">
          {/* Left: Message */}
          <div className="flex items-center gap-3 text-white">
            <div className={`
              w-12 h-12 rounded-full flex items-center justify-center
              ${isOverdue || isUrgent ? 'bg-white/20 animate-pulse' : 'bg-white/10'}
            `}>
              {isOverdue || isUrgent ? (
                <AlertTriangle className="h-6 w-6" />
              ) : (
                <CreditCard className="h-6 w-6" />
              )}
            </div>
            <div>
              <p className="text-lg mb-1">
                {isOverdue ? (
                  <>
                    <span className="font-bold">Tagihan Terlambat!</span> Segera lunasi untuk menghindari denda
                  </>
                ) : isUrgent ? (
                  <>
                    <span className="font-bold">Tagihan akan jatuh tempo!</span> {daysUntilDue} hari lagi
                  </>
                ) : (
                  <>
                    <span className="font-bold">Tagihan Pending</span> - Jatuh tempo {dueDate}
                  </>
                )}
              </p>
              <p className="text-sm opacity-90">
                Total: <span className="font-semibold">Rp {amount.toLocaleString('id-ID')}</span>
              </p>
            </div>
          </div>

          {/* Right: Actions */}
          <div className="flex items-center gap-3">
            <Button
              size="lg"
              className="bg-white hover:bg-gray-100 shadow-lg px-8"
              onClick={onPayClick}
            >
              <CreditCard className="h-5 w-5 mr-2" />
              <span className={`
                ${isOverdue ? 'text-red-700' : isUrgent ? 'text-orange-700' : 'text-blue-700'}
              `}>
                Bayar Sekarang
              </span>
            </Button>
            
            {/* Dismiss Button */}
            <Button
              variant="ghost"
              size="icon"
              className="text-white hover:bg-white/10"
              onClick={() => setDismissed(true)}
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
