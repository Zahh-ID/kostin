import { useState } from "react";
import { ArrowLeft } from "lucide-react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader } from "./ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { PaymentBanner } from "./PaymentBanner";
import { QuickPayCTA } from "./QuickPayCTA";
import { FloatingPayButton } from "./FloatingPayButton";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";

interface PaymentCTAShowcaseProps {
  onNavigate: (path: string) => void;
}

export function PaymentCTAShowcase({ onNavigate }: PaymentCTAShowcaseProps) {
  const [showDialog, setShowDialog] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => onNavigate('/')}
            className="mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Kembali
          </Button>
          <h1>Payment CTA Showcase</h1>
          <p className="text-gray-600">
            Demo dari 4 jenis CTA pembayaran Midtrans Snap
          </p>
        </div>

        <Tabs defaultValue="all" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="all">All CTAs</TabsTrigger>
            <TabsTrigger value="banner">Banner</TabsTrigger>
            <TabsTrigger value="card">Card</TabsTrigger>
            <TabsTrigger value="floating">Floating</TabsTrigger>
            <TabsTrigger value="inline">Inline</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-6">
            <Card>
              <CardHeader>
                <h2>1. Payment Banner (Sticky Top)</h2>
                <p className="text-gray-600 text-sm">
                  Sticky notification di bagian paling atas, ideal untuk urgent reminders
                </p>
              </CardHeader>
              <CardContent>
                <div className="border-2 border-dashed border-gray-300 rounded-lg overflow-hidden">
                  <PaymentBanner
                    amount={1200000}
                    dueDate="5 November 2024"
                    daysUntilDue={2}
                    onPayClick={() => setShowDialog(true)}
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <h2>2. Quick Pay CTA Card</h2>
                <p className="text-gray-600 text-sm">
                  Card besar dan prominent di dashboard untuk main action
                </p>
              </CardHeader>
              <CardContent>
                <QuickPayCTA
                  amount={1200000}
                  dueDate="5 November 2024"
                  invoiceMonth="November 2024"
                  daysUntilDue={2}
                  onPayClick={() => setShowDialog(true)}
                />
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <h2>3. Floating Pay Button</h2>
                <p className="text-gray-600 text-sm">
                  Fixed di bottom-right, muncul saat scroll lebih dari 300px
                </p>
              </CardHeader>
              <CardContent>
                <div className="bg-gray-100 rounded-lg p-12 text-center">
                  <p className="text-gray-600 mb-4">
                    Scroll ke bawah untuk melihat floating button
                  </p>
                  <p className="text-sm text-gray-500">
                    (Button akan muncul di pojok kanan bawah)
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <h2>4. Inline Pay Buttons</h2>
                <p className="text-gray-600 text-sm">
                  Button di setiap baris invoice untuk contextual action
                </p>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-4 border rounded-lg bg-white">
                    <div>
                      <p>November 2024</p>
                      <p className="text-sm text-gray-600">INV-2024-11</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="text-right">
                        <p>Rp 1.200.000</p>
                        <span className="text-xs bg-orange-100 text-orange-700 px-2 py-1 rounded">
                          Pending
                        </span>
                      </div>
                      <Button size="sm" onClick={() => setShowDialog(true)}>
                        Bayar
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <h2>Test Scroll untuk Floating Button</h2>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((i) => (
                    <div key={i} className="p-4 bg-gray-100 rounded">
                      <p>Scroll content {i + 1}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="banner">
            <Card>
              <CardHeader>
                <h2>Payment Banner Variations</h2>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <p className="text-sm text-gray-600 mb-2">Status: Terlambat (Overdue)</p>
                  <div className="border-2 border-dashed border-red-300 rounded-lg overflow-hidden">
                    <PaymentBanner
                      amount={1200000}
                      dueDate="28 Oktober 2024"
                      daysUntilDue={-3}
                      onPayClick={() => setShowDialog(true)}
                    />
                  </div>
                </div>

                <div>
                  <p className="text-sm text-gray-600 mb-2">Status: Urgent (1-3 hari)</p>
                  <div className="border-2 border-dashed border-orange-300 rounded-lg overflow-hidden">
                    <PaymentBanner
                      amount={1200000}
                      dueDate="3 November 2024"
                      daysUntilDue={2}
                      onPayClick={() => setShowDialog(true)}
                    />
                  </div>
                </div>

                <div>
                  <p className="text-sm text-gray-600 mb-2">Status: Normal (lebih dari 3 hari)</p>
                  <div className="border-2 border-dashed border-blue-300 rounded-lg overflow-hidden">
                    <PaymentBanner
                      amount={1200000}
                      dueDate="10 November 2024"
                      daysUntilDue={10}
                      onPayClick={() => setShowDialog(true)}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="card">
            <Card>
              <CardHeader>
                <h2>Quick Pay CTA Card Variations</h2>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-600 mb-2">Overdue</p>
                    <QuickPayCTA
                      amount={1200000}
                      dueDate="28 Oktober 2024"
                      invoiceMonth="Oktober 2024"
                      daysUntilDue={-3}
                      onPayClick={() => setShowDialog(true)}
                    />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 mb-2">Urgent</p>
                    <QuickPayCTA
                      amount={1500000}
                      dueDate="3 November 2024"
                      invoiceMonth="November 2024"
                      daysUntilDue={2}
                      onPayClick={() => setShowDialog(true)}
                    />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 mb-2">Normal</p>
                    <QuickPayCTA
                      amount={1800000}
                      dueDate="15 November 2024"
                      invoiceMonth="November 2024"
                      daysUntilDue={10}
                      onPayClick={() => setShowDialog(true)}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="floating">
            <Card>
              <CardHeader>
                <h2>Floating Pay Button</h2>
              </CardHeader>
              <CardContent>
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-6">
                  <p className="text-sm text-blue-800">
                    ℹ️ Floating button akan muncul di pojok kanan bawah saat Anda scroll lebih dari 300px.
                  </p>
                </div>
                
                <div className="space-y-4">
                  {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19].map((i) => (
                    <div key={i} className="p-6 bg-gray-100 rounded-lg">
                      <p className="text-lg mb-2">Content Block {i + 1}</p>
                      <p className="text-sm text-gray-600">
                        Scroll ke bawah untuk melihat floating button muncul dengan animasi.
                      </p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="inline">
            <Card>
              <CardHeader>
                <h2>Inline Pay Buttons</h2>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    { id: "INV-2024-11", month: "November 2024", amount: 1200000, status: "pending" },
                    { id: "INV-2024-10", month: "Oktober 2024", amount: 1200000, status: "paid" },
                    { id: "INV-2024-09", month: "September 2024", amount: 1200000, status: "pending" },
                    { id: "INV-2024-08", month: "Agustus 2024", amount: 1200000, status: "paid" },
                  ].map((invoice) => (
                    <div key={invoice.id} className="flex items-center justify-between p-4 border rounded-lg bg-white hover:bg-gray-50">
                      <div>
                        <p>{invoice.month}</p>
                        <p className="text-sm text-gray-600">{invoice.id}</p>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="text-right">
                          <p>Rp {invoice.amount.toLocaleString('id-ID')}</p>
                          <span className={invoice.status === 'paid' 
                              ? 'text-xs bg-green-100 text-green-700 px-2 py-1 rounded' 
                              : 'text-xs bg-orange-100 text-orange-700 px-2 py-1 rounded'}>
                            {invoice.status === 'paid' ? 'Lunas' : 'Pending'}
                          </span>
                        </div>
                        {invoice.status === 'pending' && (
                          <Button size="sm" onClick={() => setShowDialog(true)}>
                            Bayar
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      <div style={{ position: 'relative' }}>
        <FloatingPayButton
          amount={1200000}
          onPayClick={() => setShowDialog(true)}
        />
      </div>

      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Demo Payment Dialog</DialogTitle>
            <DialogDescription>
              Ini adalah demo dialog pembayaran untuk showcase CTA components.
            </DialogDescription>
          </DialogHeader>
          <div className="py-8 text-center">
            <p className="text-gray-600 mb-4">
              Ini adalah demo dialog pembayaran.
            </p>
            <p className="text-sm text-gray-500">
              Di implementasi sebenarnya, komponen MidtransPayment akan muncul di sini.
            </p>
            <Button className="mt-6" onClick={() => setShowDialog(false)}>
              Tutup
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
