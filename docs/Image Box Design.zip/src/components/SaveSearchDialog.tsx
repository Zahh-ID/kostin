import { useState } from "react";
import { Save, Bell } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Switch } from "./ui/switch";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import { toast } from "sonner@2.0.3";
import { projectId } from "../utils/supabase/info";
import { createClient } from "../utils/supabase/client";

interface SaveSearchDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  filters: any;
}

export function SaveSearchDialog({ open, onOpenChange, filters }: SaveSearchDialogProps) {
  const [name, setName] = useState("");
  const [notificationEnabled, setNotificationEnabled] = useState(true);
  const [saving, setSaving] = useState(false);
  const supabase = createClient();

  const handleSave = async () => {
    if (!name.trim()) {
      toast.error("Nama pencarian harus diisi");
      return;
    }

    setSaving(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session?.access_token) {
        toast.error("Silakan login terlebih dahulu");
        return;
      }

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-dbd6b95a/saved-searches`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${session.access_token}`,
          },
          body: JSON.stringify({
            name,
            filters,
            notificationEnabled,
          }),
        }
      );

      const data = await response.json();

      if (response.ok) {
        toast.success("Pencarian berhasil disimpan");
        setName("");
        setNotificationEnabled(true);
        onOpenChange(false);
      } else {
        throw new Error(data.error);
      }
    } catch (error: any) {
      console.error("Save search error:", error);
      toast.error(error.message || "Gagal menyimpan pencarian");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Simpan Pencarian</DialogTitle>
          <DialogDescription>
            Simpan filter pencarian ini untuk akses cepat di masa mendatang
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="search-name">Nama Pencarian</Label>
            <Input
              id="search-name"
              placeholder="Contoh: Kos di Jakarta Selatan"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>

          <div className="flex items-center justify-between space-x-2 p-4 bg-blue-50 rounded-lg">
            <div className="flex items-start gap-3">
              <Bell className="h-5 w-5 text-blue-600 mt-0.5" />
              <div>
                <Label htmlFor="notifications" className="cursor-pointer">
                  Aktifkan Notifikasi
                </Label>
                <p className="text-sm text-gray-600">
                  Dapatkan notifikasi saat ada listing baru yang cocok
                </p>
              </div>
            </div>
            <Switch
              id="notifications"
              checked={notificationEnabled}
              onCheckedChange={setNotificationEnabled}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Batal
          </Button>
          <Button onClick={handleSave} disabled={saving}>
            {saving ? "Menyimpan..." : "Simpan Pencarian"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
