import { useState, useEffect } from "react";
import { Save, Bell, BellOff, Trash2, Search, Filter } from "lucide-react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader } from "./ui/card";
import { Badge } from "./ui/badge";
import { Switch } from "./ui/switch";
import { toast } from "sonner@2.0.3";
import { projectId } from "../utils/supabase/info";
import { createClient } from "../utils/supabase/client";

interface SavedSearchesPageProps {
  onNavigate: (path: string) => void;
}

export function SavedSearchesPage({ onNavigate }: SavedSearchesPageProps) {
  const [savedSearches, setSavedSearches] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const supabase = createClient();

  useEffect(() => {
    fetchSavedSearches();
  }, []);

  const fetchSavedSearches = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session?.access_token) {
        toast.error("Silakan login terlebih dahulu");
        onNavigate("/login");
        return;
      }

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-dbd6b95a/saved-searches`,
        {
          headers: {
            Authorization: `Bearer ${session.access_token}`,
          },
        }
      );

      const data = await response.json();

      if (response.ok) {
        setSavedSearches(data.savedSearches);
      } else {
        throw new Error(data.error);
      }
    } catch (error: any) {
      console.error("Fetch saved searches error:", error);
      toast.error(error.message || "Gagal memuat pencarian tersimpan");
    } finally {
      setLoading(false);
    }
  };

  const deleteSearch = async (searchId: string) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session?.access_token) {
        toast.error("Silakan login terlebih dahulu");
        return;
      }

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-dbd6b95a/saved-searches/${searchId}`,
        {
          method: "DELETE",
          headers: {
            Authorization: `Bearer ${session.access_token}`,
          },
        }
      );

      const data = await response.json();

      if (response.ok) {
        toast.success("Pencarian berhasil dihapus");
        fetchSavedSearches();
      } else {
        throw new Error(data.error);
      }
    } catch (error: any) {
      console.error("Delete search error:", error);
      toast.error(error.message || "Gagal menghapus pencarian");
    }
  };

  const applySearch = (filters: any) => {
    // Navigate to browse page with filters
    const params = new URLSearchParams();
    if (filters.search) params.append('search', filters.search);
    if (filters.city) params.append('city', filters.city);
    if (filters.type) params.append('type', filters.type);
    if (filters.minPrice) params.append('minPrice', filters.minPrice);
    if (filters.maxPrice) params.append('maxPrice', filters.maxPrice);
    if (filters.facilities?.length) params.append('facilities', filters.facilities.join(','));
    
    onNavigate(`/browse-kost?${params.toString()}`);
  };

  const formatFilters = (filters: any) => {
    const parts = [];
    if (filters.city) parts.push(`Kota: ${filters.city}`);
    if (filters.type) parts.push(`Tipe: ${filters.type}`);
    if (filters.minPrice || filters.maxPrice) {
      parts.push(`Harga: Rp ${(filters.minPrice || 0).toLocaleString('id-ID')} - Rp ${(filters.maxPrice || '∞').toLocaleString('id-ID')}`);
    }
    if (filters.facilities?.length) {
      parts.push(`Fasilitas: ${filters.facilities.length} dipilih`);
    }
    return parts.join(' • ');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Memuat pencarian tersimpan...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="mb-2">Pencarian Tersimpan</h1>
          <p className="text-gray-600">
            Simpan filter pencarian Anda dan dapatkan notifikasi saat ada listing baru yang cocok
          </p>
        </div>

        {/* Saved Searches */}
        {savedSearches.length === 0 ? (
          <Card>
            <CardContent className="p-12 text-center">
              <Save className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="mb-2 text-gray-900">Belum ada pencarian tersimpan</h3>
              <p className="text-gray-600 mb-4">
                Simpan filter pencarian Anda untuk akses cepat di masa mendatang
              </p>
              <Button onClick={() => onNavigate("/browse-kost")}>
                <Search className="h-4 w-4 mr-2" />
                Mulai Cari Kos
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {savedSearches.map((search) => (
              <Card key={search.id}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-lg m-0">{search.name}</h3>
                        {search.notificationEnabled && (
                          <Badge className="bg-green-100 text-green-700 flex items-center gap-1">
                            <Bell className="h-3 w-3" />
                            Notifikasi Aktif
                          </Badge>
                        )}
                      </div>
                      
                      <div className="flex items-center gap-2 text-sm text-gray-600 mb-3">
                        <Filter className="h-4 w-4" />
                        <span>{formatFilters(search.filters)}</span>
                      </div>

                      <p className="text-xs text-gray-500">
                        Dibuat {new Date(search.createdAt).toLocaleDateString('id-ID', {
                          day: 'numeric',
                          month: 'long',
                          year: 'numeric'
                        })}
                      </p>
                    </div>

                    <div className="flex gap-2">
                      <Button
                        onClick={() => applySearch(search.filters)}
                      >
                        <Search className="h-4 w-4 mr-2" />
                        Terapkan
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => deleteSearch(search.id)}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
