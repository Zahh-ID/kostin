import { useState } from "react";
import { AlertCircle, CheckCircle, Clock, FileText, DollarSign, Calendar, CreditCard } from "lucide-react";
import { Card, CardContent, CardHeader } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Alert, AlertDescription } from "./ui/alert";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import { MidtransPayment } from "./MidtransPayment";
import { QuickPayCTA } from "./QuickPayCTA";
import { PaymentBanner } from "./PaymentBanner";
import { FloatingPayButton } from "./FloatingPayButton";

interface TenantDashboardProps {
  onNavigate: (path: string) => void;
}

export function TenantDashboard({ onNavigate }: TenantDashboardProps) {
  const [showPaymentDialog, setShowPaymentDialog] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState<any>(null);

  const tenant = {
    name: "Ahmad Fauzi",
    room: "Kos Melati - Kamar 101",
    contractStart: "1 Januari 2024",
    contractEnd: "31 Desember 2024",
    nextPaymentDate: "5 November 2024",
    nextPaymentAmount: 1200000,
  };

  const recentInvoices = [
    {
      id: "INV-2024-10",
      month: "Oktober 2024",
      amount: 1200000,
      status: "paid",
      paidDate: "3 Oktober 2024",
      property: "Kos Melati Residence",
    },
    {
      id: "INV-2024-11",
      month: "November 2024",
      amount: 1200000,
      status: "pending",
      dueDate: "5 November 2024",
      property: "Kos Melati Residence",
    },
    {
      id: "INV-2024-09",
      month: "September 2024",
      amount: 1200000,
      status: "paid",
      paidDate: "2 September 2024",
      property: "Kos Melati Residence",
    },
  ];

  const handlePayNow = (invoice: any) => {
    setSelectedInvoice(invoice);
    setShowPaymentDialog(true);
  };

  // Calculate days until due for banner
  const pendingInvoice = recentInvoices.find(inv => inv.status === 'pending');
  const calculateDaysUntilDue = () => {
    if (!pendingInvoice) return 0;
    const today = new Date();
    const due = new Date(tenant.nextPaymentDate);
    return Math.ceil((due.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
  };
  const daysUntilDue = calculateDaysUntilDue();

  const stats = [
    {
      title: "Tagihan Aktif",
      value: "1",
      icon: DollarSign,
      color: "text-orange-600",
      bgColor: "bg-orange-50",
    },
    {
      title: "Total Dibayar",
      value: "Rp 12.000.000",
      icon: CheckCircle,
      color: "text-green-600",
      bgColor: "bg-green-50",
    },
    {
      title: "Kontrak Aktif",
      value: "1",
      icon: FileText,
      color: "text-blue-600",
      bgColor: "bg-blue-50",
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Payment Banner - Sticky at top */}
      {pendingInvoice && (
        <div className="sticky top-0 z-50">
          <PaymentBanner
            amount={tenant.nextPaymentAmount}
            dueDate={tenant.nextPaymentDate}
            daysUntilDue={daysUntilDue}
            onPayClick={() => handlePayNow(pendingInvoice)}
          />
        </div>
      )}

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1>Dashboard Penyewa</h1>
          <p className="text-gray-600">Selamat datang kembali, {tenant.name}!</p>
        </div>

        {/* Quick Pay CTA - Card Style */}
        {pendingInvoice && (
          <div className="mb-6">
            <QuickPayCTA
              amount={tenant.nextPaymentAmount}
              dueDate={tenant.nextPaymentDate}
              invoiceMonth="November 2024"
              daysUntilDue={daysUntilDue}
              onPayClick={() => handlePayNow(pendingInvoice)}
            />
          </div>
        )}

        {/* Stats */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          {stats.map((stat) => (
            <Card key={stat.title}>
              <CardContent className="flex items-center gap-4 p-6">
                <div className={`w-12 h-12 ${stat.bgColor} rounded-lg flex items-center justify-center`}>
                  <stat.icon className={`h-6 w-6 ${stat.color}`} />
                </div>
                <div>
                  <p className="text-gray-600 text-sm">{stat.title}</p>
                  <p className={stat.color}>{stat.value}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Recent Invoices */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <h2>Tagihan Terbaru</h2>
                  <Button variant="link" onClick={() => onNavigate('/tenant/invoices')}>
                    Lihat Semua →
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentInvoices.map((invoice) => (
                    <div
                      key={invoice.id}
                      className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 cursor-pointer"
                      onClick={() => onNavigate(`/tenant/invoices/${invoice.id}`)}
                    >
                      <div className="flex items-center gap-4">
                        <div className={`w-10 h-10 ${
                          invoice.status === 'paid' ? 'bg-green-50' : 'bg-orange-50'
                        } rounded-lg flex items-center justify-center`}>
                          {invoice.status === 'paid' ? (
                            <CheckCircle className="h-5 w-5 text-green-600" />
                          ) : (
                            <Clock className="h-5 w-5 text-orange-600" />
                          )}
                        </div>
                        <div>
                          <p>{invoice.month}</p>
                          <p className="text-sm text-gray-600">{invoice.id}</p>
                        </div>
                      </div>
                      <div className="text-right flex flex-col items-end gap-2">
                        <div>
                          <p>Rp {invoice.amount.toLocaleString('id-ID')}</p>
                          {invoice.status === 'paid' ? (
                            <Badge className="bg-green-500 mt-1">Lunas</Badge>
                          ) : (
                            <Badge className="bg-orange-500 mt-1">Menunggu</Badge>
                          )}
                        </div>
                        {invoice.status === 'pending' && (
                          <Button 
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              handlePayNow(invoice);
                            }}
                          >
                            <CreditCard className="h-4 w-4 mr-2" />
                            Bayar
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Contract Info */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <h3>Informasi Kontrak</h3>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm text-gray-600">Properti</p>
                  <p>{tenant.room}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Periode Kontrak</p>
                  <p>{tenant.contractStart}</p>
                  <p className="text-sm">s/d {tenant.contractEnd}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Biaya Bulanan</p>
                  <p className="text-blue-600">
                    Rp {tenant.nextPaymentAmount.toLocaleString('id-ID')}
                  </p>
                </div>
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => onNavigate('/tenant/contracts')}
                >
                  <FileText className="h-4 w-4 mr-2" />
                  Lihat Detail Kontrak
                </Button>
              </CardContent>
            </Card>

            <Card className="mt-6">
              <CardHeader>
                <h3>Pembayaran Berikutnya</h3>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-3 mb-4">
                  <Calendar className="h-5 w-5 text-gray-400" />
                  <div>
                    <p className="text-sm text-gray-600">Jatuh Tempo</p>
                    <p>{tenant.nextPaymentDate}</p>
                  </div>
                </div>
                <div className="p-4 bg-blue-50 rounded-lg mb-4">
                  <p className="text-sm text-gray-600 mb-1">Jumlah Tagihan</p>
                  <p className="text-blue-600 text-2xl">
                    Rp {tenant.nextPaymentAmount.toLocaleString('id-ID')}
                  </p>
                </div>
                <Button 
                  className="w-full"
                  onClick={() => {
                    const pendingInvoice = recentInvoices.find(inv => inv.status === 'pending');
                    if (pendingInvoice) handlePayNow(pendingInvoice);
                  }}
                >
                  <CreditCard className="h-4 w-4 mr-2" />
                  Bayar Sekarang
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Midtrans Payment Dialog */}
      <Dialog open={showPaymentDialog} onOpenChange={setShowPaymentDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Pembayaran Tagihan</DialogTitle>
            <DialogDescription>
              Selesaikan pembayaran tagihan Anda melalui Midtrans Snap dengan berbagai metode pembayaran.
            </DialogDescription>
          </DialogHeader>
          {selectedInvoice && (
            <MidtransPayment
              invoiceId={selectedInvoice.id}
              amount={selectedInvoice.amount}
              description={`Pembayaran ${selectedInvoice.month} - ${selectedInvoice.property}`}
              onSuccess={() => {
                setShowPaymentDialog(false);
                // In production, this would refresh the invoice list
                alert("Pembayaran berhasil! Tagihan Anda akan diperbarui dalam beberapa saat.");
              }}
              onPending={() => {
                setShowPaymentDialog(false);
                alert("Pembayaran sedang diproses. Kami akan memberitahu Anda setelah pembayaran dikonfirmasi.");
              }}
              onError={(error) => {
                console.error("Payment error:", error);
              }}
              onClose={() => {
                setShowPaymentDialog(false);
              }}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* Floating Pay Button - Shows when scrolling */}
      {pendingInvoice && (
        <FloatingPayButton
          amount={tenant.nextPaymentAmount}
          onPayClick={() => handlePayNow(pendingInvoice)}
        />
      )}
    </div>
  );
}
