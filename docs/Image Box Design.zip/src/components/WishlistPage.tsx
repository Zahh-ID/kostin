import { useState, useEffect } from "react";
import { Heart, MapPin, DollarSign, Eye, Trash2, Search } from "lucide-react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader } from "./ui/card";
import { Badge } from "./ui/badge";
import { toast } from "sonner@2.0.3";
import { projectId } from "../utils/supabase/info";
import { createClient } from "../utils/supabase/client";

interface WishlistPageProps {
  onNavigate: (path: string) => void;
}

export function WishlistPage({ onNavigate }: WishlistPageProps) {
  const [wishlist, setWishlist] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const supabase = createClient();

  useEffect(() => {
    fetchWishlist();
  }, []);

  const fetchWishlist = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session?.access_token) {
        toast.error("Silakan login terlebih dahulu");
        onNavigate("/login");
        return;
      }

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-dbd6b95a/wishlist`,
        {
          headers: {
            Authorization: `Bearer ${session.access_token}`,
          },
        }
      );

      const data = await response.json();

      if (response.ok) {
        setWishlist(data.wishlist);
      } else {
        throw new Error(data.error);
      }
    } catch (error: any) {
      console.error("Fetch wishlist error:", error);
      toast.error(error.message || "Gagal memuat wishlist");
    } finally {
      setLoading(false);
    }
  };

  const removeFromWishlist = async (propertyId: string) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session?.access_token) {
        toast.error("Silakan login terlebih dahulu");
        return;
      }

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-dbd6b95a/wishlist/${propertyId}`,
        {
          method: "DELETE",
          headers: {
            Authorization: `Bearer ${session.access_token}`,
          },
        }
      );

      const data = await response.json();

      if (response.ok) {
        toast.success("Dihapus dari wishlist");
        fetchWishlist();
      } else {
        throw new Error(data.error);
      }
    } catch (error: any) {
      console.error("Remove from wishlist error:", error);
      toast.error(error.message || "Gagal menghapus dari wishlist");
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Memuat wishlist...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="mb-2">Wishlist Saya</h1>
          <p className="text-gray-600">
            Properti kos yang Anda simpan untuk perbandingan
          </p>
        </div>

        {/* Wishlist Grid */}
        {wishlist.length === 0 ? (
          <Card>
            <CardContent className="p-12 text-center">
              <Heart className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="mb-2 text-gray-900">Wishlist Anda kosong</h3>
              <p className="text-gray-600 mb-4">
                Mulai simpan properti favorit Anda untuk dibandingkan nanti
              </p>
              <Button onClick={() => onNavigate("/browse-kost")}>
                <Search className="h-4 w-4 mr-2" />
                Jelajahi Kos
              </Button>
            </CardContent>
          </Card>
        ) : (
          <>
            <div className="mb-4 text-sm text-gray-600">
              {wishlist.length} properti dalam wishlist
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {wishlist.map((property) => (
                <Card key={property.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="text-lg m-0">{property.name}</h3>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeFromWishlist(property.id)}
                        className="text-red-500 hover:text-red-700 hover:bg-red-50 -mt-2 -mr-2"
                      >
                        <Heart className="h-5 w-5 fill-current" />
                      </Button>
                    </div>
                    <div className="flex items-center text-sm text-gray-600">
                      <MapPin className="h-4 w-4 mr-1" />
                      {property.city}
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Harga</span>
                      <span className="font-semibold text-blue-600">
                        Rp {property.pricePerMonth?.toLocaleString('id-ID')}/bulan
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">Kamar Tersedia</span>
                      <span className="font-medium">
                        {property.availableRooms}/{property.totalRooms}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">Tipe</span>
                      <Badge variant="outline">
                        {property.type === 'putra' ? 'Putra' : property.type === 'putri' ? 'Putri' : 'Campur'}
                      </Badge>
                    </div>

                    <div className="flex gap-2 pt-3 border-t">
                      <Button
                        className="flex-1"
                        onClick={() => onNavigate(`/property/${property.id}`)}
                      >
                        <Eye className="h-4 w-4 mr-2" />
                        Lihat Detail
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => removeFromWishlist(property.id)}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
