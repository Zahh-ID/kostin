import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "jsr:@supabase/supabase-js@2";
import * as kv from "./kv_store.tsx";
import { createMidtransTransaction, verifyMidtransTransaction } from "./payment.tsx";

const app = new Hono();

// Create Supabase client with service role key
const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
);

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-dbd6b95a/health", (c) => {
  return c.json({ status: "ok" });
});

// Sign up endpoint with role assignment
app.post("/make-server-dbd6b95a/auth/signup", async (c) => {
  try {
    const { email, password, name, role } = await c.req.json();

    if (!email || !password || !name || !role) {
      return c.json({ error: "Missing required fields" }, 400);
    }

    // Create user with admin privileges to set custom metadata
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: {
        name,
        role,
      },
      // Automatically confirm the user's email since an email server hasn't been configured.
      // In production, you should remove this and properly configure email confirmation.
      email_confirm: true,
    });

    if (error) {
      console.error("Sign up error:", error);
      return c.json({ error: error.message }, 400);
    }

    return c.json({
      success: true,
      message: "User created successfully",
      user: {
        id: data.user.id,
        email: data.user.email,
        name: data.user.user_metadata?.name,
        role: data.user.user_metadata?.role,
      },
    });
  } catch (error: any) {
    console.error("Sign up error:", error);
    return c.json({ error: error.message || "Internal server error" }, 500);
  }
});

// Get user profile
app.get("/make-server-dbd6b95a/auth/profile", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Missing authorization token" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);

    if (error || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    return c.json({
      id: user.id,
      email: user.email,
      name: user.user_metadata?.name,
      role: user.user_metadata?.role,
    });
  } catch (error: any) {
    console.error("Get profile error:", error);
    return c.json({ error: error.message || "Internal server error" }, 500);
  }
});

// Upgrade user to owner
app.post("/make-server-dbd6b95a/auth/upgrade-to-owner", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Missing authorization token" }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    // Check if user is already an owner or admin
    const currentRole = user.user_metadata?.role;
    if (currentRole === "owner") {
      return c.json({ error: "Anda sudah terdaftar sebagai Owner" }, 400);
    }
    if (currentRole === "admin") {
      return c.json({ error: "Admin tidak dapat upgrade ke Owner" }, 400);
    }

    // Update user role to owner
    const { error: updateError } = await supabase.auth.admin.updateUserById(user.id, {
      user_metadata: {
        ...user.user_metadata,
        role: "owner",
      },
    });

    if (updateError) {
      console.error("Upgrade to owner error:", updateError);
      return c.json({ error: updateError.message }, 400);
    }

    // Store upgrade information in KV
    await kv.set(`owner-upgrade:${user.id}`, {
      userId: user.id,
      email: user.email,
      name: user.user_metadata?.name,
      previousRole: currentRole,
      newRole: "owner",
      upgradedAt: new Date().toISOString(),
    });

    return c.json({
      success: true,
      message: "Berhasil upgrade ke Owner",
      user: {
        id: user.id,
        email: user.email,
        name: user.user_metadata?.name,
        role: "owner",
      },
    });
  } catch (error: any) {
    console.error("Upgrade to owner error:", error);
    return c.json({ error: error.message || "Internal server error" }, 500);
  }
});

// Initialize demo users endpoint
app.post("/make-server-dbd6b95a/auth/init-demo-users", async (c) => {
  try {
    const demoUsers = [
      {
        email: "tenant@demo.com",
        password: "demo123",
        name: "Demo Tenant",
        role: "tenant",
      },
      {
        email: "owner@demo.com",
        password: "demo123",
        name: "Demo Owner",
        role: "owner",
      },
      {
        email: "admin@demo.com",
        password: "demo123",
        name: "Demo Admin",
        role: "admin",
      },
    ];

    const results = [];

    for (const demoUser of demoUsers) {
      // Check if user already exists
      const { data: existingUsers } = await supabase.auth.admin.listUsers();
      const userExists = existingUsers?.users?.some(u => u.email === demoUser.email);

      if (userExists) {
        results.push({
          email: demoUser.email,
          status: "already_exists",
        });
        continue;
      }

      // Create demo user
      const { data, error } = await supabase.auth.admin.createUser({
        email: demoUser.email,
        password: demoUser.password,
        user_metadata: {
          name: demoUser.name,
          role: demoUser.role,
        },
        email_confirm: true,
      });

      if (error) {
        console.error(`Error creating demo user ${demoUser.email}:`, error);
        results.push({
          email: demoUser.email,
          status: "error",
          error: error.message,
        });
      } else {
        results.push({
          email: demoUser.email,
          status: "created",
          userId: data.user.id,
        });
      }
    }

    return c.json({
      success: true,
      message: "Demo users initialization completed",
      results,
    });
  } catch (error: any) {
    console.error("Init demo users error:", error);
    return c.json({ error: error.message || "Internal server error" }, 500);
  }
});

// ===== PROFILE ENDPOINTS =====

// Get user profile
app.get("/make-server-dbd6b95a/profile", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Missing authorization token" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);

    if (error || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    // Try to get additional profile info from KV store
    const profileData = await kv.get(`profile:${user.id}`) || {};

    return c.json({
      profile: {
        id: user.id,
        email: user.email,
        name: user.user_metadata?.name || profileData.name || "",
        role: user.user_metadata?.role || profileData.role || "",
        phone: profileData.phone || "",
        address: profileData.address || "",
      },
    });
  } catch (error: any) {
    console.error("Get profile error:", error);
    return c.json({ error: error.message || "Internal server error" }, 500);
  }
});

// Update user profile
app.put("/make-server-dbd6b95a/profile", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Missing authorization token" }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { name, phone, address } = await c.req.json();

    // Update user metadata if name is changed
    if (name && name !== user.user_metadata?.name) {
      await supabase.auth.admin.updateUserById(user.id, {
        user_metadata: {
          ...user.user_metadata,
          name,
        },
      });
    }

    // Store additional profile data in KV
    const existingProfile = await kv.get(`profile:${user.id}`) || {};
    const updatedProfile = {
      ...existingProfile,
      name,
      phone,
      address,
      updatedAt: new Date().toISOString(),
    };

    await kv.set(`profile:${user.id}`, updatedProfile);

    return c.json({
      success: true,
      profile: {
        id: user.id,
        email: user.email,
        name,
        role: user.user_metadata?.role,
        phone,
        address,
      },
    });
  } catch (error: any) {
    console.error("Update profile error:", error);
    return c.json({ error: error.message || "Internal server error" }, 500);
  }
});

// Change password
app.post("/make-server-dbd6b95a/profile/change-password", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Missing authorization token" }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { newPassword } = await c.req.json();

    if (!newPassword || newPassword.length < 6) {
      return c.json({ error: "Password minimal 6 karakter" }, 400);
    }

    // Update user password
    const { error: updateError } = await supabase.auth.admin.updateUserById(user.id, {
      password: newPassword,
    });

    if (updateError) {
      console.error("Change password error:", updateError);
      return c.json({ error: updateError.message }, 400);
    }

    return c.json({
      success: true,
      message: "Password berhasil diubah",
    });
  } catch (error: any) {
    console.error("Change password error:", error);
    return c.json({ error: error.message || "Internal server error" }, 500);
  }
});

// ===== PAYMENT ENDPOINTS =====

// Create payment transaction (generate Midtrans Snap token)
app.post("/make-server-dbd6b95a/payment/create", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Missing authorization token" }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { invoiceId, amount, description } = await c.req.json();

    if (!invoiceId || !amount) {
      return c.json({ error: "Missing required fields" }, 400);
    }

    // Generate unique order ID
    const orderId = `INV-${invoiceId}-${Date.now()}`;

    // Create Midtrans QRIS transaction
    const qrisData = await createMidtransTransaction({
      orderId,
      amount,
      customerDetails: {
        first_name: user.user_metadata?.name || user.email?.split('@')[0] || 'Customer',
        email: user.email || '',
      },
      itemDetails: [
        {
          id: invoiceId,
          price: amount,
          quantity: 1,
          name: description || `Pembayaran ${invoiceId}`,
        },
      ],
    });

    // Store payment info in KV
    await kv.set(`payment:${orderId}`, {
      orderId,
      invoiceId,
      userId: user.id,
      amount,
      status: qrisData.transaction_status,
      transactionId: qrisData.transaction_id,
      qrisString: qrisData.qris_string,
      acquirer: qrisData.acquirer,
      createdAt: new Date().toISOString(),
    });

    return c.json({
      success: true,
      orderId,
      transactionId: qrisData.transaction_id,
      qrisString: qrisData.qris_string,
      transactionStatus: qrisData.transaction_status,
      acquirer: qrisData.acquirer,
    });
  } catch (error: any) {
    console.error("Create payment error:", error);
    return c.json({ error: error.message || "Internal server error" }, 500);
  }
});

// Verify payment status
app.get("/make-server-dbd6b95a/payment/verify/:orderId", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Missing authorization token" }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const orderId = c.req.param('orderId');

    if (!orderId) {
      return c.json({ error: "Missing order ID" }, 400);
    }

    // Get payment info from KV
    const paymentInfo = await kv.get(`payment:${orderId}`);

    if (!paymentInfo) {
      return c.json({ error: "Payment not found" }, 404);
    }

    // Verify with Midtrans
    const status = await verifyMidtransTransaction(orderId);

    // Update payment status in KV
    const updatedPayment = {
      ...paymentInfo,
      status: status.transaction_status,
      paymentType: status.payment_type,
      transactionTime: status.transaction_time,
      settlementTime: status.settlement_time,
      verifiedAt: new Date().toISOString(),
    };

    await kv.set(`payment:${orderId}`, updatedPayment);

    return c.json({
      success: true,
      payment: updatedPayment,
      midtransStatus: status,
    });
  } catch (error: any) {
    console.error("Verify payment error:", error);
    return c.json({ error: error.message || "Internal server error" }, 500);
  }
});

// Midtrans notification/webhook handler
app.post("/make-server-dbd6b95a/payment/notification", async (c) => {
  try {
    const notification = await c.req.json();
    
    console.log('Midtrans notification received:', notification);

    const orderId = notification.order_id;
    const transactionStatus = notification.transaction_status;

    // Get payment info from KV
    const paymentInfo = await kv.get(`payment:${orderId}`);

    if (!paymentInfo) {
      console.error('Payment not found for order:', orderId);
      return c.json({ error: "Payment not found" }, 404);
    }

    // Update payment status
    const updatedPayment = {
      ...paymentInfo,
      status: transactionStatus,
      fraudStatus: notification.fraud_status,
      paymentType: notification.payment_type,
      transactionTime: notification.transaction_time,
      settlementTime: notification.settlement_time,
      notifiedAt: new Date().toISOString(),
    };

    await kv.set(`payment:${orderId}`, updatedPayment);

    console.log('Payment status updated:', updatedPayment);

    return c.json({ success: true });
  } catch (error: any) {
    console.error("Payment notification error:", error);
    return c.json({ error: error.message || "Internal server error" }, 500);
  }
});

// Manual payment submission
app.post("/make-server-dbd6b95a/payment/manual", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Missing authorization token" }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { invoiceId, amount, description, paymentMethod, proofFile, fileName, notes } = await c.req.json();

    if (!invoiceId || !amount || !paymentMethod || !proofFile) {
      return c.json({ error: "Missing required fields" }, 400);
    }

    // Generate unique payment ID
    const paymentId = `MAN-${invoiceId}-${Date.now()}`;

    // Store payment proof in KV (in production, you should use Supabase Storage)
    const manualPayment = {
      paymentId,
      invoiceId,
      userId: user.id,
      userName: user.user_metadata?.name || user.email,
      amount,
      description,
      paymentMethod,
      proofFile,
      fileName,
      notes,
      status: 'pending_verification',
      submittedAt: new Date().toISOString(),
    };

    await kv.set(`manual-payment:${paymentId}`, manualPayment);

    // Also store in a list for admin to review
    const pendingPayments = await kv.get('manual-payments:pending') || [];
    pendingPayments.push(paymentId);
    await kv.set('manual-payments:pending', pendingPayments);

    return c.json({
      success: true,
      paymentId,
      message: "Bukti pembayaran berhasil dikirim dan menunggu verifikasi",
    });
  } catch (error: any) {
    console.error("Manual payment submission error:", error);
    return c.json({ error: error.message || "Internal server error" }, 500);
  }
});

// Get manual payments for admin/owner verification
app.get("/make-server-dbd6b95a/payment/manual/pending", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Missing authorization token" }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    // Check if user is admin or owner
    const userRole = user.user_metadata?.role;
    if (userRole !== 'admin' && userRole !== 'owner') {
      return c.json({ error: "Unauthorized - Admin or Owner access required" }, 403);
    }

    const pendingPaymentIds = await kv.get('manual-payments:pending') || [];
    const payments = [];

    for (const paymentId of pendingPaymentIds) {
      const payment = await kv.get(`manual-payment:${paymentId}`);
      if (payment && payment.status === 'pending_verification') {
        payments.push(payment);
      }
    }

    return c.json({
      success: true,
      payments,
    });
  } catch (error: any) {
    console.error("Get pending manual payments error:", error);
    return c.json({ error: error.message || "Internal server error" }, 500);
  }
});

// Verify/reject manual payment
app.post("/make-server-dbd6b95a/payment/manual/verify", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Missing authorization token" }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    // Check if user is admin or owner
    const userRole = user.user_metadata?.role;
    if (userRole !== 'admin' && userRole !== 'owner') {
      return c.json({ error: "Unauthorized - Admin or Owner access required" }, 403);
    }

    const { paymentId, action, rejectionReason } = await c.req.json();

    if (!paymentId || !action || (action !== 'approve' && action !== 'reject')) {
      return c.json({ error: "Invalid request" }, 400);
    }

    const payment = await kv.get(`manual-payment:${paymentId}`);

    if (!payment) {
      return c.json({ error: "Payment not found" }, 404);
    }

    // Update payment status
    const updatedPayment = {
      ...payment,
      status: action === 'approve' ? 'approved' : 'rejected',
      verifiedBy: user.id,
      verifiedByName: user.user_metadata?.name || user.email,
      verifiedAt: new Date().toISOString(),
      rejectionReason: action === 'reject' ? rejectionReason : undefined,
    };

    await kv.set(`manual-payment:${paymentId}`, updatedPayment);

    // Remove from pending list
    const pendingPayments = await kv.get('manual-payments:pending') || [];
    const updatedPending = pendingPayments.filter((id: string) => id !== paymentId);
    await kv.set('manual-payments:pending', updatedPending);

    return c.json({
      success: true,
      payment: updatedPayment,
    });
  } catch (error: any) {
    console.error("Verify manual payment error:", error);
    return c.json({ error: error.message || "Internal server error" }, 500);
  }
});

// ===== PROPERTY MANAGEMENT ENDPOINTS =====

// Get all properties (with filters)
app.get("/make-server-dbd6b95a/properties", async (c) => {
  try {
    const { search, city, type, minPrice, maxPrice, facilities } = c.req.query();
    
    // Get all properties from KV
    const allProperties = await kv.getByPrefix('property:') || [];
    
    let filteredProperties = allProperties;
    
    // Apply filters
    if (search) {
      const searchLower = search.toLowerCase();
      filteredProperties = filteredProperties.filter((p: any) => 
        p.name?.toLowerCase().includes(searchLower) || 
        p.description?.toLowerCase().includes(searchLower)
      );
    }
    
    if (city) {
      filteredProperties = filteredProperties.filter((p: any) => 
        p.city?.toLowerCase() === city.toLowerCase()
      );
    }
    
    if (type) {
      filteredProperties = filteredProperties.filter((p: any) => 
        p.type === type
      );
    }
    
    if (minPrice) {
      filteredProperties = filteredProperties.filter((p: any) => 
        p.pricePerMonth >= parseInt(minPrice)
      );
    }
    
    if (maxPrice) {
      filteredProperties = filteredProperties.filter((p: any) => 
        p.pricePerMonth <= parseInt(maxPrice)
      );
    }
    
    if (facilities) {
      const facilitiesArray = facilities.split(',');
      filteredProperties = filteredProperties.filter((p: any) => 
        facilitiesArray.every((f: string) => p.facilities?.includes(f))
      );
    }
    
    return c.json({
      success: true,
      properties: filteredProperties,
      total: filteredProperties.length,
    });
  } catch (error: any) {
    console.error("Get properties error:", error);
    return c.json({ error: error.message || "Internal server error" }, 500);
  }
});

// Get single property by ID
app.get("/make-server-dbd6b95a/properties/:id", async (c) => {
  try {
    const propertyId = c.req.param('id');
    const property = await kv.get(`property:${propertyId}`);
    
    if (!property) {
      return c.json({ error: "Property not found" }, 404);
    }
    
    return c.json({
      success: true,
      property,
    });
  } catch (error: any) {
    console.error("Get property error:", error);
    return c.json({ error: error.message || "Internal server error" }, 500);
  }
});

// Create new property (Owner only)
app.post("/make-server-dbd6b95a/properties", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Missing authorization token" }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const userRole = user.user_metadata?.role;
    if (userRole !== 'owner' && userRole !== 'admin') {
      return c.json({ error: "Only owners can create properties" }, 403);
    }

    const propertyData = await c.req.json();
    const propertyId = `prop-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    const property = {
      id: propertyId,
      ownerId: user.id,
      ownerName: user.user_metadata?.name || user.email,
      ...propertyData,
      status: 'pending_approval', // Needs admin approval
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await kv.set(`property:${propertyId}`, property);
    
    // Add to pending moderation list
    const pendingProperties = await kv.get('properties:pending') || [];
    pendingProperties.push(propertyId);
    await kv.set('properties:pending', pendingProperties);

    return c.json({
      success: true,
      property,
    });
  } catch (error: any) {
    console.error("Create property error:", error);
    return c.json({ error: error.message || "Internal server error" }, 500);
  }
});

// Update property (Owner only)
app.put("/make-server-dbd6b95a/properties/:id", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Missing authorization token" }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const propertyId = c.req.param('id');
    const property = await kv.get(`property:${propertyId}`);
    
    if (!property) {
      return c.json({ error: "Property not found" }, 404);
    }

    // Check ownership
    if (property.ownerId !== user.id && user.user_metadata?.role !== 'admin') {
      return c.json({ error: "Unauthorized to edit this property" }, 403);
    }

    const updates = await c.req.json();
    const updatedProperty = {
      ...property,
      ...updates,
      updatedAt: new Date().toISOString(),
    };

    await kv.set(`property:${propertyId}`, updatedProperty);

    return c.json({
      success: true,
      property: updatedProperty,
    });
  } catch (error: any) {
    console.error("Update property error:", error);
    return c.json({ error: error.message || "Internal server error" }, 500);
  }
});

// Delete property
app.delete("/make-server-dbd6b95a/properties/:id", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Missing authorization token" }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const propertyId = c.req.param('id');
    const property = await kv.get(`property:${propertyId}`);
    
    if (!property) {
      return c.json({ error: "Property not found" }, 404);
    }

    // Check ownership
    if (property.ownerId !== user.id && user.user_metadata?.role !== 'admin') {
      return c.json({ error: "Unauthorized to delete this property" }, 403);
    }

    await kv.del(`property:${propertyId}`);

    return c.json({
      success: true,
      message: "Property deleted successfully",
    });
  } catch (error: any) {
    console.error("Delete property error:", error);
    return c.json({ error: error.message || "Internal server error" }, 500);
  }
});

// ===== WISHLIST ENDPOINTS =====

// Get user's wishlist
app.get("/make-server-dbd6b95a/wishlist", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Missing authorization token" }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const wishlist = await kv.get(`wishlist:${user.id}`) || [];
    
    // Get property details for each wishlist item
    const properties = [];
    for (const propertyId of wishlist) {
      const property = await kv.get(`property:${propertyId}`);
      if (property) {
        properties.push(property);
      }
    }

    return c.json({
      success: true,
      wishlist: properties,
    });
  } catch (error: any) {
    console.error("Get wishlist error:", error);
    return c.json({ error: error.message || "Internal server error" }, 500);
  }
});

// Add to wishlist
app.post("/make-server-dbd6b95a/wishlist/:propertyId", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Missing authorization token" }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const propertyId = c.req.param('propertyId');
    const wishlist = await kv.get(`wishlist:${user.id}`) || [];
    
    if (!wishlist.includes(propertyId)) {
      wishlist.push(propertyId);
      await kv.set(`wishlist:${user.id}`, wishlist);
    }

    return c.json({
      success: true,
      message: "Added to wishlist",
    });
  } catch (error: any) {
    console.error("Add to wishlist error:", error);
    return c.json({ error: error.message || "Internal server error" }, 500);
  }
});

// Remove from wishlist
app.delete("/make-server-dbd6b95a/wishlist/:propertyId", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Missing authorization token" }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const propertyId = c.req.param('propertyId');
    const wishlist = await kv.get(`wishlist:${user.id}`) || [];
    
    const updatedWishlist = wishlist.filter((id: string) => id !== propertyId);
    await kv.set(`wishlist:${user.id}`, updatedWishlist);

    return c.json({
      success: true,
      message: "Removed from wishlist",
    });
  } catch (error: any) {
    console.error("Remove from wishlist error:", error);
    return c.json({ error: error.message || "Internal server error" }, 500);
  }
});

// ===== SAVED SEARCH ENDPOINTS =====

// Get saved searches
app.get("/make-server-dbd6b95a/saved-searches", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Missing authorization token" }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const savedSearches = await kv.getByPrefix(`saved-search:${user.id}:`) || [];

    return c.json({
      success: true,
      savedSearches,
    });
  } catch (error: any) {
    console.error("Get saved searches error:", error);
    return c.json({ error: error.message || "Internal server error" }, 500);
  }
});

// Save search
app.post("/make-server-dbd6b95a/saved-searches", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Missing authorization token" }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { name, filters, notificationEnabled } = await c.req.json();
    const searchId = `search-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    const savedSearch = {
      id: searchId,
      userId: user.id,
      name,
      filters,
      notificationEnabled: notificationEnabled || false,
      createdAt: new Date().toISOString(),
    };

    await kv.set(`saved-search:${user.id}:${searchId}`, savedSearch);

    return c.json({
      success: true,
      savedSearch,
    });
  } catch (error: any) {
    console.error("Save search error:", error);
    return c.json({ error: error.message || "Internal server error" }, 500);
  }
});

// Delete saved search
app.delete("/make-server-dbd6b95a/saved-searches/:searchId", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Missing authorization token" }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const searchId = c.req.param('searchId');
    await kv.del(`saved-search:${user.id}:${searchId}`);

    return c.json({
      success: true,
      message: "Saved search deleted",
    });
  } catch (error: any) {
    console.error("Delete saved search error:", error);
    return c.json({ error: error.message || "Internal server error" }, 500);
  }
});

// ===== LIVE CHAT ENDPOINTS =====

// Get conversations for user
app.get("/make-server-dbd6b95a/chat/conversations", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Missing authorization token" }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const allConversations = await kv.getByPrefix('conversation:') || [];
    
    // Filter conversations where user is participant
    const userConversations = allConversations.filter((conv: any) => 
      conv.participants?.includes(user.id)
    );

    return c.json({
      success: true,
      conversations: userConversations,
    });
  } catch (error: any) {
    console.error("Get conversations error:", error);
    return c.json({ error: error.message || "Internal server error" }, 500);
  }
});

// Create or get conversation
app.post("/make-server-dbd6b95a/chat/conversations", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Missing authorization token" }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { otherUserId, propertyId } = await c.req.json();
    
    // Check if conversation already exists
    const allConversations = await kv.getByPrefix('conversation:') || [];
    const existing = allConversations.find((conv: any) => 
      conv.participants?.includes(user.id) && 
      conv.participants?.includes(otherUserId) &&
      conv.propertyId === propertyId
    );
    
    if (existing) {
      return c.json({
        success: true,
        conversation: existing,
      });
    }
    
    // Create new conversation
    const conversationId = `conv-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const conversation = {
      id: conversationId,
      participants: [user.id, otherUserId],
      propertyId,
      createdAt: new Date().toISOString(),
      lastMessageAt: new Date().toISOString(),
    };
    
    await kv.set(`conversation:${conversationId}`, conversation);

    return c.json({
      success: true,
      conversation,
    });
  } catch (error: any) {
    console.error("Create conversation error:", error);
    return c.json({ error: error.message || "Internal server error" }, 500);
  }
});

// Get messages in conversation
app.get("/make-server-dbd6b95a/chat/conversations/:conversationId/messages", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Missing authorization token" }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const conversationId = c.req.param('conversationId');
    const conversation = await kv.get(`conversation:${conversationId}`);
    
    if (!conversation || !conversation.participants?.includes(user.id)) {
      return c.json({ error: "Unauthorized" }, 403);
    }
    
    const messages = await kv.getByPrefix(`message:${conversationId}:`) || [];
    
    // Sort by timestamp
    messages.sort((a: any, b: any) => 
      new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
    );

    return c.json({
      success: true,
      messages,
    });
  } catch (error: any) {
    console.error("Get messages error:", error);
    return c.json({ error: error.message || "Internal server error" }, 500);
  }
});

// Send message
app.post("/make-server-dbd6b95a/chat/conversations/:conversationId/messages", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Missing authorization token" }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const conversationId = c.req.param('conversationId');
    const conversation = await kv.get(`conversation:${conversationId}`);
    
    if (!conversation || !conversation.participants?.includes(user.id)) {
      return c.json({ error: "Unauthorized" }, 403);
    }
    
    const { content, type, attachmentUrl } = await c.req.json();
    
    const messageId = `msg-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const message = {
      id: messageId,
      conversationId,
      senderId: user.id,
      senderName: user.user_metadata?.name || user.email,
      content,
      type: type || 'text', // text, image, file
      attachmentUrl,
      timestamp: new Date().toISOString(),
      read: false,
    };
    
    await kv.set(`message:${conversationId}:${messageId}`, message);
    
    // Update conversation last message time
    await kv.set(`conversation:${conversationId}`, {
      ...conversation,
      lastMessageAt: new Date().toISOString(),
      lastMessage: content,
    });

    return c.json({
      success: true,
      message,
    });
  } catch (error: any) {
    console.error("Send message error:", error);
    return c.json({ error: error.message || "Internal server error" }, 500);
  }
});

// ===== TICKETING/MODERATION ENDPOINTS =====

// Get all tickets (with filters)
app.get("/make-server-dbd6b95a/tickets", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Missing authorization token" }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { status, category } = c.req.query();
    const userRole = user.user_metadata?.role;
    
    let tickets = await kv.getByPrefix('ticket:') || [];
    
    // Filter based on role
    if (userRole === 'tenant') {
      tickets = tickets.filter((t: any) => t.reporterId === user.id);
    } else if (userRole === 'owner') {
      tickets = tickets.filter((t: any) => 
        t.reporterId === user.id || t.assigneeId === user.id
      );
    }
    // Admin sees all tickets
    
    // Apply filters
    if (status) {
      tickets = tickets.filter((t: any) => t.status === status);
    }
    
    if (category) {
      tickets = tickets.filter((t: any) => t.category === category);
    }

    return c.json({
      success: true,
      tickets,
    });
  } catch (error: any) {
    console.error("Get tickets error:", error);
    return c.json({ error: error.message || "Internal server error" }, 500);
  }
});

// Create ticket
app.post("/make-server-dbd6b95a/tickets", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Missing authorization token" }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { category, subject, description, relatedId, relatedType, priority } = await c.req.json();
    
    const ticketId = `ticket-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const ticket = {
      id: ticketId,
      reporterId: user.id,
      reporterName: user.user_metadata?.name || user.email,
      category, // abuse, payment, content, technical
      subject,
      description,
      relatedId, // propertyId, invoiceId, conversationId, etc.
      relatedType, // property, invoice, chat, etc.
      priority: priority || 'medium', // low, medium, high, urgent
      status: 'open', // open, in_review, escalated, resolved, rejected
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      events: [{
        type: 'created',
        userId: user.id,
        userName: user.user_metadata?.name || user.email,
        timestamp: new Date().toISOString(),
      }],
    };
    
    await kv.set(`ticket:${ticketId}`, ticket);

    return c.json({
      success: true,
      ticket,
    });
  } catch (error: any) {
    console.error("Create ticket error:", error);
    return c.json({ error: error.message || "Internal server error" }, 500);
  }
});

// Update ticket status
app.put("/make-server-dbd6b95a/tickets/:ticketId", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Missing authorization token" }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const ticketId = c.req.param('ticketId');
    const ticket = await kv.get(`ticket:${ticketId}`);
    
    if (!ticket) {
      return c.json({ error: "Ticket not found" }, 404);
    }

    const { status, assigneeId, comment } = await c.req.json();
    
    const updatedTicket = {
      ...ticket,
      status: status || ticket.status,
      assigneeId: assigneeId || ticket.assigneeId,
      updatedAt: new Date().toISOString(),
      events: [
        ...ticket.events,
        {
          type: status ? 'status_changed' : 'updated',
          userId: user.id,
          userName: user.user_metadata?.name || user.email,
          newStatus: status,
          comment,
          timestamp: new Date().toISOString(),
        },
      ],
    };
    
    await kv.set(`ticket:${ticketId}`, updatedTicket);

    return c.json({
      success: true,
      ticket: updatedTicket,
    });
  } catch (error: any) {
    console.error("Update ticket error:", error);
    return c.json({ error: error.message || "Internal server error" }, 500);
  }
});

// Add comment to ticket
app.post("/make-server-dbd6b95a/tickets/:ticketId/comments", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Missing authorization token" }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const ticketId = c.req.param('ticketId');
    const ticket = await kv.get(`ticket:${ticketId}`);
    
    if (!ticket) {
      return c.json({ error: "Ticket not found" }, 404);
    }

    const { comment } = await c.req.json();
    
    const updatedTicket = {
      ...ticket,
      updatedAt: new Date().toISOString(),
      events: [
        ...ticket.events,
        {
          type: 'comment',
          userId: user.id,
          userName: user.user_metadata?.name || user.email,
          comment,
          timestamp: new Date().toISOString(),
        },
      ],
    };
    
    await kv.set(`ticket:${ticketId}`, updatedTicket);

    return c.json({
      success: true,
      ticket: updatedTicket,
    });
  } catch (error: any) {
    console.error("Add comment error:", error);
    return c.json({ error: error.message || "Internal server error" }, 500);
  }
});

Deno.serve(app.fetch);