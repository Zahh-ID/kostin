import { createClient } from "jsr:@supabase/supabase-js@2";

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
);

interface CreateTransactionParams {
  orderId: string;
  amount: number;
  customerDetails: {
    first_name: string;
    email: string;
    phone?: string;
  };
  itemDetails: Array<{
    id: string;
    price: number;
    quantity: number;
    name: string;
  }>;
}

/**
 * Create Midtrans QRIS transaction using Core API
 */
export async function createMidtransTransaction(params: CreateTransactionParams) {
  const serverKey = Deno.env.get('MIDTRANS_SERVER_KEY');
  
  if (!serverKey) {
    throw new Error('MIDTRANS_SERVER_KEY is not configured');
  }

  // Base64 encode the server key
  const authString = btoa(serverKey + ':');

  const midtransUrl = Deno.env.get('MIDTRANS_ENV') === 'production'
    ? 'https://api.midtrans.com/v2/charge'
    : 'https://api.sandbox.midtrans.com/v2/charge';

  const payload = {
    payment_type: "qris",
    transaction_details: {
      order_id: params.orderId,
      gross_amount: params.amount,
    },
    customer_details: params.customerDetails,
    item_details: params.itemDetails,
  };

  try {
    const response = await fetch(midtransUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': `Basic ${authString}`,
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      const errorData = await response.json();
      console.error('Midtrans API error:', errorData);
      throw new Error(`Midtrans API error: ${errorData.error_messages?.join(', ') || 'Unknown error'}`);
    }

    const data = await response.json();
    
    // Core API response structure for QRIS
    return {
      transaction_id: data.transaction_id,
      order_id: data.order_id,
      qris_string: data.actions?.find((action: any) => action.name === 'generate-qr-code')?.url || '',
      transaction_status: data.transaction_status,
      acquirer: data.acquirer,
    };
  } catch (error: any) {
    console.error('Error creating Midtrans QRIS transaction:', error);
    throw error;
  }
}

/**
 * Verify Midtrans transaction status
 */
export async function verifyMidtransTransaction(orderId: string) {
  const serverKey = Deno.env.get('MIDTRANS_SERVER_KEY');
  
  if (!serverKey) {
    throw new Error('MIDTRANS_SERVER_KEY is not configured');
  }

  const authString = btoa(serverKey + ':');

  const midtransUrl = Deno.env.get('MIDTRANS_ENV') === 'production'
    ? `https://api.midtrans.com/v2/${orderId}/status`
    : `https://api.sandbox.midtrans.com/v2/${orderId}/status`;

  try {
    const response = await fetch(midtransUrl, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': `Basic ${authString}`,
      },
    });

    if (!response.ok) {
      const errorData = await response.json();
      console.error('Midtrans verification error:', errorData);
      throw new Error(`Midtrans verification error: ${errorData.error_messages?.join(', ') || 'Unknown error'}`);
    }

    const data = await response.json();
    return {
      transaction_status: data.transaction_status,
      payment_type: data.payment_type,
      transaction_time: data.transaction_time,
      settlement_time: data.settlement_time,
      gross_amount: data.gross_amount,
    };
  } catch (error: any) {
    console.error('Error verifying Midtrans transaction:', error);
    throw error;
  }
}
