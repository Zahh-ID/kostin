import { Building2, Users, AlertCircle, CheckCircle, Clock, TrendingUp } from "lucide-react";
import { Card, CardContent, CardHeader } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";

interface AdminDashboardProps {
  onNavigate: (path: string) => void;
}

export function AdminDashboard({ onNavigate }: AdminDashboardProps) {
  const stats = [
    {
      title: "Total Properti",
      value: "156",
      icon: Building2,
      color: "text-blue-600",
      bgColor: "bg-blue-50",
      change: "+8 bulan ini",
    },
    {
      title: "Total Pengguna",
      value: "1,234",
      icon: Users,
      color: "text-purple-600",
      bgColor: "bg-purple-50",
      change: "+42 bulan ini",
    },
    {
      title: "Menunggu Moderasi",
      value: "12",
      icon: Clock,
      color: "text-orange-600",
      bgColor: "bg-orange-50",
      change: "Butuh review",
    },
    {
      title: "Total Transaksi",
      value: "Rp 450jt",
      icon: TrendingUp,
      color: "text-green-600",
      bgColor: "bg-green-50",
      change: "Bulan ini",
    },
  ];

  const pendingProperties = [
    {
      id: 1,
      name: "Kos Bougenville Residence",
      owner: "Ibu Susi Rahayu",
      location: "Bogor Selatan",
      submittedDate: "29 Okt 2024",
      rooms: 15,
    },
    {
      id: 2,
      name: "Kos Kenanga Modern",
      owner: "Bapak Andi Wijaya",
      location: "Bogor Barat",
      submittedDate: "28 Okt 2024",
      rooms: 20,
    },
    {
      id: 3,
      name: "Kos Dahlia Syariah",
      owner: "Ibu Fatimah",
      location: "Bogor Timur",
      submittedDate: "27 Okt 2024",
      rooms: 12,
    },
  ];

  const recentUsers = [
    { id: 1, name: "Ahmad Fauzi", email: "ahmad@email.com", role: "tenant", joinDate: "30 Okt 2024" },
    { id: 2, name: "Siti Nurhaliza", email: "siti@email.com", role: "tenant", joinDate: "30 Okt 2024" },
    { id: 3, name: "Budi Santoso", email: "budi@email.com", role: "owner", joinDate: "29 Okt 2024" },
  ];

  const systemActivity = [
    { action: "Properti disetujui", detail: "Kos Melati Residence", time: "2 jam lalu", type: "success" },
    { action: "User baru terdaftar", detail: "Ahmad Fauzi (Tenant)", time: "3 jam lalu", type: "info" },
    { action: "Pembayaran berhasil", detail: "INV-2024-1234", time: "5 jam lalu", type: "success" },
    { action: "Properti ditolak", detail: "Kos Tanpa Izin", time: "1 hari lalu", type: "error" },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1>Dashboard Admin</h1>
          <p className="text-gray-600">Kelola dan moderasi platform KosKita</p>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat) => (
            <Card key={stat.title}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className={`w-12 h-12 ${stat.bgColor} rounded-lg flex items-center justify-center`}>
                    <stat.icon className={`h-6 w-6 ${stat.color}`} />
                  </div>
                </div>
                <p className="text-gray-600 text-sm mb-1">{stat.title}</p>
                <p className={`text-2xl mb-2 ${stat.color}`}>{stat.value}</p>
                <p className="text-xs text-gray-500">{stat.change}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Pending Moderation */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <h2>Menunggu Moderasi</h2>
                    <Badge className="bg-orange-500">{pendingProperties.length}</Badge>
                  </div>
                  <Button variant="link" onClick={() => onNavigate('/admin/moderations')}>
                    Lihat Semua →
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {pendingProperties.map((property) => (
                  <div key={property.id} className="p-4 border rounded-lg">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3>{property.name}</h3>
                        <p className="text-sm text-gray-600">{property.location}</p>
                        <p className="text-sm text-gray-500 mt-1">
                          oleh {property.owner} • {property.rooms} kamar
                        </p>
                      </div>
                      <Badge variant="outline" className="border-orange-500 text-orange-600">
                        Pending
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <p className="text-xs text-gray-500">Diajukan {property.submittedDate}</p>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          className="text-red-600 hover:bg-red-50"
                          onClick={() => {}}
                        >
                          Tolak
                        </Button>
                        <Button
                          size="sm"
                          className="bg-green-600 hover:bg-green-700"
                          onClick={() => {}}
                        >
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Setujui
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Recent Users */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <h2>Pengguna Terbaru</h2>
                  <Button variant="link" onClick={() => onNavigate('/admin/users')}>
                    Lihat Semua →
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {recentUsers.map((user) => (
                    <div key={user.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                          <Users className="h-5 w-5 text-gray-600" />
                        </div>
                        <div>
                          <p>{user.name}</p>
                          <p className="text-sm text-gray-600">{user.email}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <Badge variant="outline" className={
                          user.role === 'owner' ? 'border-blue-500 text-blue-600' : 'border-purple-500 text-purple-600'
                        }>
                          {user.role === 'owner' ? 'Pemilik' : 'Penyewa'}
                        </Badge>
                        <p className="text-xs text-gray-500 mt-1">{user.joinDate}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <h3>Aksi Cepat</h3>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => onNavigate('/admin/moderations')}
                >
                  <Clock className="h-4 w-4 mr-2" />
                  Review Moderasi
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => onNavigate('/admin/users')}
                >
                  <Users className="h-4 w-4 mr-2" />
                  Kelola Pengguna
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => onNavigate('/admin/settings')}
                >
                  <AlertCircle className="h-4 w-4 mr-2" />
                  Pengaturan Sistem
                </Button>
              </CardContent>
            </Card>

            {/* System Activity */}
            <Card>
              <CardHeader>
                <h3>Aktivitas Sistem</h3>
              </CardHeader>
              <CardContent className="space-y-3">
                {systemActivity.map((activity, index) => (
                  <div key={index} className="pb-3 border-b last:border-0">
                    <div className="flex items-start gap-2">
                      {activity.type === 'success' ? (
                        <CheckCircle className="h-4 w-4 text-green-500 flex-shrink-0 mt-0.5" />
                      ) : activity.type === 'error' ? (
                        <AlertCircle className="h-4 w-4 text-red-500 flex-shrink-0 mt-0.5" />
                      ) : (
                        <Clock className="h-4 w-4 text-blue-500 flex-shrink-0 mt-0.5" />
                      )}
                      <div className="flex-1 min-w-0">
                        <p className="text-sm">{activity.action}</p>
                        <p className="text-xs text-gray-600 truncate">{activity.detail}</p>
                        <p className="text-xs text-gray-500 mt-1">{activity.time}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
