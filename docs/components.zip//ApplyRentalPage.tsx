import { useState } from "react";
import { Calendar, User, FileText, CheckCircle, ArrowLeft, Home, AlertCircle } from "lucide-react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardDescription } from "./ui/card";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { RadioGroup, RadioGroupItem } from "./ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Badge } from "./ui/badge";
import { Separator } from "./ui/separator";
import { Alert, AlertDescription } from "./ui/alert";

interface ApplyRentalPageProps {
  propertyId: string;
  onNavigate: (path: string) => void;
  userRole?: 'guest' | 'tenant' | 'owner' | 'admin';
}

interface RoomType {
  id: number;
  name: string;
  price: number;
  deposit: number;
  available: number;
  size: string;
}

export function ApplyRentalPage({ propertyId, onNavigate, userRole = 'guest' }: ApplyRentalPageProps) {
  const [step, setStep] = useState(1);
  const [selectedRoom, setSelectedRoom] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    idNumber: '',
    occupation: '',
    emergencyContact: '',
    emergencyPhone: '',
    moveInDate: '',
    duration: '12',
    notes: '',
    agreedToTerms: false,
  });

  // Mock property data
  const property = {
    id: propertyId,
    name: "Kos Melati Residence",
    address: "Jl. Raya Dramaga No. 45, Bogor Barat",
    roomTypes: [
      {
        id: 1,
        name: "Single AC - Kamar Mandi Dalam",
        size: "3x4 m",
        price: 1200000,
        deposit: 1200000,
        available: 5,
      },
      {
        id: 2,
        name: "Single AC - Kamar Mandi Luar",
        size: "3x3 m",
        price: 1000000,
        deposit: 1000000,
        available: 3,
      },
      {
        id: 3,
        name: "Single Non-AC",
        size: "3x3 m",
        price: 800000,
        deposit: 800000,
        available: 0,
      },
    ] as RoomType[],
  };

  const selectedRoomData = property.roomTypes.find(r => r.id === selectedRoom);
  const monthlyRent = selectedRoomData?.price || 0;
  const depositAmount = selectedRoomData?.deposit || 0;
  const totalFirstPayment = monthlyRent + depositAmount;

  const handleSubmit = () => {
    console.log('Rental Application Submitted:', {
      propertyId,
      roomId: selectedRoom,
      formData,
    });
    
    setStep(4);
    setTimeout(() => {
      if (userRole === 'guest') {
        onNavigate('/login');
      } else {
        onNavigate('/tenant/contracts');
      }
    }, 3000);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Header */}
        <div className="mb-8">
          <Button variant="ghost" onClick={() => onNavigate(`/property/${propertyId}`)} className="mb-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Kembali ke Detail Properti
          </Button>
          
          <div className="flex items-center gap-3 mb-2">
            <Home className="h-6 w-6 text-blue-600" />
            <h1>Ajukan Sewa</h1>
          </div>
          <p className="text-gray-600">{property.name} - {property.address}</p>
        </div>

        {/* Progress Steps */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            {[
              { num: 1, label: 'Pilih Kamar' },
              { num: 2, label: 'Data Diri' },
              { num: 3, label: 'Konfirmasi' },
              { num: 4, label: 'Selesai' },
            ].map((s, idx) => (
              <div key={s.num} className="flex items-center flex-1">
                <div className="flex flex-col items-center flex-1">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${
                      step >= s.num
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-200 text-gray-600'
                    }`}
                  >
                    {step > s.num ? <CheckCircle className="h-5 w-5" /> : s.num}
                  </div>
                  <span className="text-xs mt-2 text-center hidden sm:block">{s.label}</span>
                </div>
                {idx < 3 && (
                  <div
                    className={`h-1 flex-1 mx-2 transition-colors ${
                      step > s.num ? 'bg-blue-600' : 'bg-gray-200'
                    }`}
                  />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Guest Warning */}
        {userRole === 'guest' && step < 4 && (
          <Alert className="mb-6 border-blue-200 bg-blue-50">
            <AlertCircle className="h-4 w-4 text-blue-600" />
            <AlertDescription className="text-blue-800">
              Anda belum login. Setelah mengisi formulir, Anda akan diminta untuk login atau mendaftar.
            </AlertDescription>
          </Alert>
        )}

        {/* Step 1: Select Room */}
        {step === 1 && (
          <Card>
            <CardHeader>
              <h2>Pilih Tipe Kamar</h2>
              <CardDescription>Pilih tipe kamar yang sesuai dengan kebutuhan Anda</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <RadioGroup value={selectedRoom?.toString()} onValueChange={(val) => setSelectedRoom(parseInt(val))}>
                {property.roomTypes.map((room) => (
                  <div
                    key={room.id}
                    className={`border rounded-lg p-4 transition-all ${
                      selectedRoom === room.id
                        ? 'border-blue-600 bg-blue-50'
                        : 'border-gray-200 hover:border-gray-300'
                    } ${room.available === 0 ? 'opacity-50' : ''}`}
                  >
                    <div className="flex items-start gap-4">
                      <RadioGroupItem 
                        value={room.id.toString()} 
                        id={`room-${room.id}`}
                        disabled={room.available === 0}
                        className="mt-1"
                      />
                      <div className="flex-1">
                        <label
                          htmlFor={`room-${room.id}`}
                          className="flex items-start justify-between cursor-pointer"
                        >
                          <div>
                            <div className="font-semibold text-gray-900">{room.name}</div>
                            <div className="text-sm text-gray-600 mt-1">Ukuran: {room.size}</div>
                            {room.available > 0 ? (
                              <Badge className="bg-green-500 mt-2">
                                {room.available} kamar tersedia
                              </Badge>
                            ) : (
                              <Badge variant="secondary" className="mt-2">
                                Penuh
                              </Badge>
                            )}
                          </div>
                          <div className="text-right">
                            <div className="text-blue-600 font-semibold text-lg">
                              Rp {room.price.toLocaleString('id-ID')}
                            </div>
                            <div className="text-sm text-gray-500">per bulan</div>
                            <div className="text-xs text-gray-500 mt-1">
                              Deposit: Rp {room.deposit.toLocaleString('id-ID')}
                            </div>
                          </div>
                        </label>
                      </div>
                    </div>
                  </div>
                ))}
              </RadioGroup>

              <div className="flex justify-end pt-4">
                <Button
                  onClick={() => setStep(2)}
                  disabled={!selectedRoom}
                  size="lg"
                >
                  Lanjutkan
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Step 2: Personal Information */}
        {step === 2 && (
          <Card>
            <CardHeader>
              <h2>Data Diri Penyewa</h2>
              <CardDescription>Lengkapi informasi pribadi Anda</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="text-sm font-semibold text-gray-700 mb-4">Informasi Pribadi</h3>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="fullName">Nama Lengkap *</Label>
                    <Input
                      id="fullName"
                      placeholder="Nama sesuai KTP"
                      value={formData.fullName}
                      onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="idNumber">No. KTP *</Label>
                    <Input
                      id="idNumber"
                      placeholder="3201234567890123"
                      value={formData.idNumber}
                      onChange={(e) => setFormData({ ...formData, idNumber: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email *</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="email@example.com"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">No. Telepon *</Label>
                    <Input
                      id="phone"
                      placeholder="08123456789"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="occupation">Pekerjaan/Status *</Label>
                    <Input
                      id="occupation"
                      placeholder="Mahasiswa / Karyawan"
                      value={formData.occupation}
                      onChange={(e) => setFormData({ ...formData, occupation: e.target.value })}
                    />
                  </div>
                </div>
              </div>

              <Separator />

              <div>
                <h3 className="text-sm font-semibold text-gray-700 mb-4">Kontak Darurat</h3>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="emergencyContact">Nama Kontak Darurat *</Label>
                    <Input
                      id="emergencyContact"
                      placeholder="Nama orang tua/saudara"
                      value={formData.emergencyContact}
                      onChange={(e) => setFormData({ ...formData, emergencyContact: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="emergencyPhone">No. Telepon Darurat *</Label>
                    <Input
                      id="emergencyPhone"
                      placeholder="08123456789"
                      value={formData.emergencyPhone}
                      onChange={(e) => setFormData({ ...formData, emergencyPhone: e.target.value })}
                    />
                  </div>
                </div>
              </div>

              <Separator />

              <div>
                <h3 className="text-sm font-semibold text-gray-700 mb-4">Detail Sewa</h3>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="moveInDate">Tanggal Masuk *</Label>
                    <Input
                      id="moveInDate"
                      type="date"
                      value={formData.moveInDate}
                      onChange={(e) => setFormData({ ...formData, moveInDate: e.target.value })}
                      min={new Date().toISOString().split('T')[0]}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="duration">Durasi Sewa *</Label>
                    <Select value={formData.duration} onValueChange={(val) => setFormData({ ...formData, duration: val })}>
                      <SelectTrigger id="duration">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 Bulan</SelectItem>
                        <SelectItem value="3">3 Bulan</SelectItem>
                        <SelectItem value="6">6 Bulan</SelectItem>
                        <SelectItem value="12">12 Bulan (Rekomendasi)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label htmlFor="notes">Catatan Tambahan (Opsional)</Label>
                <Textarea
                  id="notes"
                  placeholder="Ada pertanyaan atau permintaan khusus?"
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  rows={4}
                />
              </div>

              <div className="flex justify-between pt-4">
                <Button variant="outline" onClick={() => setStep(1)}>
                  Kembali
                </Button>
                <Button
                  onClick={() => setStep(3)}
                  disabled={
                    !formData.fullName ||
                    !formData.email ||
                    !formData.phone ||
                    !formData.idNumber ||
                    !formData.occupation ||
                    !formData.emergencyContact ||
                    !formData.emergencyPhone ||
                    !formData.moveInDate
                  }
                  size="lg"
                >
                  Lanjutkan
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Step 3: Confirmation */}
        {step === 3 && selectedRoomData && (
          <Card>
            <CardHeader>
              <h2>Konfirmasi Pengajuan</h2>
              <CardDescription>Pastikan semua data sudah benar sebelum mengirim</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="text-sm font-semibold text-gray-700 mb-3">Tipe Kamar</h3>
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="font-semibold text-gray-900">{selectedRoomData.name}</div>
                      <div className="text-sm text-gray-600 mt-1">Ukuran: {selectedRoomData.size}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-blue-600 font-semibold">
                        Rp {selectedRoomData.price.toLocaleString('id-ID')}
                      </div>
                      <div className="text-xs text-gray-500">per bulan</div>
                    </div>
                  </div>
                </div>
              </div>

              <Separator />

              <div>
                <h3 className="text-sm font-semibold text-gray-700 mb-3">Data Penyewa</h3>
                <div className="grid md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <div className="text-gray-600">Nama Lengkap</div>
                    <div className="font-medium">{formData.fullName}</div>
                  </div>
                  <div>
                    <div className="text-gray-600">No. KTP</div>
                    <div className="font-medium">{formData.idNumber}</div>
                  </div>
                  <div>
                    <div className="text-gray-600">Email</div>
                    <div className="font-medium">{formData.email}</div>
                  </div>
                  <div>
                    <div className="text-gray-600">No. Telepon</div>
                    <div className="font-medium">{formData.phone}</div>
                  </div>
                  <div>
                    <div className="text-gray-600">Pekerjaan</div>
                    <div className="font-medium">{formData.occupation}</div>
                  </div>
                  <div>
                    <div className="text-gray-600">Tanggal Masuk</div>
                    <div className="font-medium">
                      {new Date(formData.moveInDate).toLocaleDateString('id-ID', {
                        day: 'numeric',
                        month: 'long',
                        year: 'numeric'
                      })}
                    </div>
                  </div>
                </div>
              </div>

              <Separator />

              <div>
                <h3 className="text-sm font-semibold text-gray-700 mb-3">Rincian Pembayaran</h3>
                <div className="bg-gray-50 rounded-lg p-4 space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Sewa Bulan Pertama</span>
                    <span className="font-medium">Rp {monthlyRent.toLocaleString('id-ID')}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Deposit (1x sewa)</span>
                    <span className="font-medium">Rp {depositAmount.toLocaleString('id-ID')}</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between text-base">
                    <span className="font-semibold">Total Pembayaran Awal</span>
                    <span className="font-semibold text-blue-600">
                      Rp {totalFirstPayment.toLocaleString('id-ID')}
                    </span>
                  </div>
                </div>
                <p className="text-xs text-gray-500 mt-2">
                  * Deposit akan dikembalikan pada akhir masa sewa jika tidak ada kerusakan
                </p>
              </div>

              <Separator />

              <div className="flex items-start gap-3 p-4 bg-amber-50 border border-amber-200 rounded-lg">
                <input
                  type="checkbox"
                  id="terms"
                  checked={formData.agreedToTerms}
                  onChange={(e) => setFormData({ ...formData, agreedToTerms: e.target.checked })}
                  className="mt-1"
                />
                <label htmlFor="terms" className="text-sm text-gray-700 cursor-pointer">
                  Saya menyetujui <span className="font-semibold">syarat dan ketentuan</span> yang berlaku, 
                  serta menyatakan bahwa semua data yang saya berikan adalah benar dan dapat dipertanggungjawabkan.
                </label>
              </div>

              <div className="flex justify-between pt-4">
                <Button variant="outline" onClick={() => setStep(2)}>
                  Kembali
                </Button>
                <Button
                  onClick={handleSubmit}
                  disabled={!formData.agreedToTerms}
                  size="lg"
                  className="min-w-[200px]"
                >
                  <FileText className="h-5 w-5 mr-2" />
                  Kirim Pengajuan
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Step 4: Success */}
        {step === 4 && (
          <Card className="text-center">
            <CardContent className="py-12">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="h-10 w-10 text-green-600" />
              </div>
              <h2 className="mb-4">Pengajuan Berhasil Dikirim!</h2>
              <p className="text-gray-600 mb-6">
                Pengajuan sewa Anda telah diterima. Pemilik kos akan menghubungi Anda dalam 1x24 jam.
              </p>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6 max-w-md mx-auto">
                <div className="text-sm text-gray-700">
                  <div className="font-semibold mb-2">Detail Pengajuan:</div>
                  <div className="space-y-1 text-left">
                    <div className="flex justify-between">
                      <span>Properti:</span>
                      <span className="font-medium">{property.name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Kamar:</span>
                      <span className="font-medium">{selectedRoomData?.name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Email:</span>
                      <span className="font-medium">{formData.email}</span>
                    </div>
                  </div>
                </div>
              </div>
              <p className="text-sm text-gray-500">
                {userRole === 'guest' 
                  ? 'Anda akan dialihkan ke halaman login...'
                  : 'Anda akan dialihkan ke halaman kontrak...'}
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
