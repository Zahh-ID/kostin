import { useEffect, useState, useRef } from "react";
import { Button } from "./ui/button";
import { Loader2, CheckCircle2, XCircle, Clock, QrCode } from "lucide-react";
import { createClient } from "../utils/supabase/client";
import { projectId } from "../utils/supabase/info";
import { toast } from "sonner@2.0.3";
import { QRCodeSVG } from "qrcode.react";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";

interface MidtransPaymentProps {
  invoiceId: string;
  amount: number;
  description: string;
  onSuccess?: () => void;
  onPending?: () => void;
  onError?: (error: string) => void;
  onClose?: () => void;
}

export function MidtransPayment({
  invoiceId,
  amount,
  description,
  onSuccess,
  onPending,
  onError,
  onClose,
}: MidtransPaymentProps) {
  const [loading, setLoading] = useState(false);
  const [qrisString, setQrisString] = useState<string>("");
  const [orderId, setOrderId] = useState<string>("");
  const [transactionStatus, setTransactionStatus] = useState<string>("");
  const [countdown, setCountdown] = useState(300); // 5 minutes
  const [checking, setChecking] = useState(false);
  const [supabase] = useState(() => createClient());
  const pollingIntervalRef = useRef<any>(null);
  const countdownIntervalRef = useRef<any>(null);

  useEffect(() => {
    return () => {
      // Cleanup intervals on unmount
      if (pollingIntervalRef.current) {
        clearInterval(pollingIntervalRef.current);
      }
      if (countdownIntervalRef.current) {
        clearInterval(countdownIntervalRef.current);
      }
    };
  }, []);

  const startCountdown = () => {
    if (countdownIntervalRef.current) {
      clearInterval(countdownIntervalRef.current);
    }
    
    countdownIntervalRef.current = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(countdownIntervalRef.current);
          handleTimeout();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const handleTimeout = () => {
    toast.error("Waktu pembayaran habis. Silakan buat transaksi baru.");
    setTransactionStatus("expired");
    stopPolling();
    if (onError) onError("Payment timeout");
  };

  const checkPaymentStatus = async (currentOrderId: string) => {
    try {
      setChecking(true);
      
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session?.access_token) {
        return;
      }

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-dbd6b95a/payment/verify/${currentOrderId}`,
        {
          method: "GET",
          headers: {
            "Authorization": `Bearer ${session.access_token}`,
          },
        }
      );

      const result = await response.json();

      if (response.ok && result.midtransStatus) {
        const status = result.midtransStatus.transaction_status;
        setTransactionStatus(status);

        if (status === "settlement" || status === "capture") {
          // Payment successful
          toast.success("Pembayaran berhasil!");
          stopPolling();
          if (onSuccess) onSuccess();
        } else if (status === "deny" || status === "cancel" || status === "expire") {
          // Payment failed
          toast.error(`Pembayaran gagal: ${status}`);
          stopPolling();
          if (onError) onError(`Payment ${status}`);
        } else if (status === "pending") {
          // Still pending, continue polling
          console.log("Payment still pending...");
        }
      }
    } catch (error: any) {
      console.error("Error checking payment status:", error);
    } finally {
      setChecking(false);
    }
  };

  const startPolling = (currentOrderId: string) => {
    // Check immediately
    checkPaymentStatus(currentOrderId);
    
    // Then check every 3 seconds
    if (pollingIntervalRef.current) {
      clearInterval(pollingIntervalRef.current);
    }
    
    pollingIntervalRef.current = setInterval(() => {
      checkPaymentStatus(currentOrderId);
    }, 3000);
  };

  const stopPolling = () => {
    if (pollingIntervalRef.current) {
      clearInterval(pollingIntervalRef.current);
      pollingIntervalRef.current = null;
    }
    if (countdownIntervalRef.current) {
      clearInterval(countdownIntervalRef.current);
      countdownIntervalRef.current = null;
    }
  };

  const handleGenerateQris = async () => {
    setLoading(true);

    try {
      // Get session token
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session?.access_token) {
        throw new Error("Silakan login terlebih dahulu");
      }

      // Create QRIS payment transaction
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-dbd6b95a/payment/create`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${session.access_token}`,
          },
          body: JSON.stringify({
            invoiceId,
            amount,
            description,
          }),
        }
      );

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || "Gagal membuat transaksi pembayaran");
      }

      const { qrisString: qris, orderId: newOrderId, transactionStatus: status } = result;

      if (!qris) {
        throw new Error("QRIS string tidak ditemukan dalam response");
      }

      setQrisString(qris);
      setOrderId(newOrderId);
      setTransactionStatus(status);
      
      toast.success("QR Code berhasil dibuat! Scan untuk membayar.");
      
      // Start countdown and polling
      startCountdown();
      startPolling(newOrderId);

    } catch (error: any) {
      console.error("Payment error:", error);
      toast.error(error.message || "Gagal memproses pembayaran");
      if (onError) onError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getStatusBadge = () => {
    switch (transactionStatus) {
      case "pending":
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-300">
          <Clock className="h-3 w-3 mr-1" />
          Menunggu Pembayaran
        </Badge>;
      case "settlement":
      case "capture":
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-300">
          <CheckCircle2 className="h-3 w-3 mr-1" />
          Pembayaran Berhasil
        </Badge>;
      case "deny":
      case "cancel":
      case "expire":
      case "expired":
        return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-300">
          <XCircle className="h-3 w-3 mr-1" />
          Pembayaran Gagal
        </Badge>;
      default:
        return null;
    }
  };

  if (!qrisString) {
    return (
      <div className="space-y-4">
        <Card className="p-4 bg-gray-50 space-y-2">
          <div className="flex justify-between">
            <span className="text-sm text-gray-600">Invoice</span>
            <span>{invoiceId}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-sm text-gray-600">Deskripsi</span>
            <span className="text-sm text-right max-w-[200px]">{description}</span>
          </div>
          <div className="flex justify-between pt-2 border-t">
            <span className="text-sm text-gray-600">Total Pembayaran</span>
            <span className="text-blue-600">
              Rp {amount.toLocaleString('id-ID')}
            </span>
          </div>
        </Card>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <QrCode className="h-5 w-5 text-blue-600 mt-0.5" />
            <div>
              <p className="text-blue-800">
                Klik tombol di bawah untuk generate QRIS code
              </p>
              <p className="text-sm text-blue-600 mt-1">
                Pembayaran akan terdeteksi otomatis setelah Anda scan QR code
              </p>
            </div>
          </div>
        </div>

        <Button
          className="w-full"
          onClick={handleGenerateQris}
          disabled={loading}
          size="lg"
        >
          {loading ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Membuat QR Code...
            </>
          ) : (
            <>
              <QrCode className="h-4 w-4 mr-2" />
              Generate QRIS
            </>
          )}
        </Button>

        <p className="text-xs text-gray-500 text-center">
          Metode pembayaran: QRIS (semua e-wallet dan mobile banking)
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Status Badge */}
      <div className="flex justify-center">
        {getStatusBadge()}
      </div>

      {/* QR Code Display */}
      <Card className="p-6 bg-white">
        <div className="flex flex-col items-center space-y-4">
          <h3 className="text-center">Scan QR Code untuk Membayar</h3>
          
          <div className="bg-white p-4 rounded-lg border-2 border-gray-200">
            <QRCodeSVG 
              value={qrisString} 
              size={240}
              level="H"
              includeMargin={true}
            />
          </div>

          {transactionStatus === "pending" && (
            <>
              <div className="text-center space-y-2">
                <p className="text-sm text-gray-600">
                  Waktu tersisa
                </p>
                <p className={`text-2xl ${countdown < 60 ? 'text-red-600' : 'text-gray-900'}`}>
                  {formatTime(countdown)}
                </p>
                {checking && (
                  <div className="flex items-center justify-center gap-2 text-xs text-gray-500">
                    <Loader2 className="h-3 w-3 animate-spin" />
                    Mengecek status pembayaran...
                  </div>
                )}
              </div>

              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 w-full">
                <p className="text-xs text-yellow-800 text-center">
                  Buka aplikasi e-wallet atau mobile banking Anda, scan QR code di atas, dan selesaikan pembayaran.
                </p>
              </div>
            </>
          )}

          {(transactionStatus === "settlement" || transactionStatus === "capture") && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-4 w-full">
              <div className="flex items-center justify-center gap-2 text-green-700">
                <CheckCircle2 className="h-5 w-5" />
                <p>Pembayaran berhasil dikonfirmasi!</p>
              </div>
            </div>
          )}

          {(transactionStatus === "deny" || transactionStatus === "cancel" || transactionStatus === "expire" || transactionStatus === "expired") && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 w-full">
              <div className="flex items-center justify-center gap-2 text-red-700">
                <XCircle className="h-5 w-5" />
                <p>Pembayaran gagal atau dibatalkan</p>
              </div>
            </div>
          )}
        </div>
      </Card>

      {/* Payment Details */}
      <Card className="p-4 bg-gray-50 space-y-2">
        <div className="flex justify-between text-sm">
          <span className="text-gray-600">Order ID</span>
          <span className="text-xs">{orderId}</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-gray-600">Invoice</span>
          <span>{invoiceId}</span>
        </div>
        <div className="flex justify-between pt-2 border-t">
          <span className="text-sm text-gray-600">Total</span>
          <span className="text-blue-600">
            Rp {amount.toLocaleString('id-ID')}
          </span>
        </div>
      </Card>

      {/* Manual Check Button */}
      {transactionStatus === "pending" && (
        <Button
          variant="outline"
          className="w-full"
          onClick={() => checkPaymentStatus(orderId)}
          disabled={checking}
        >
          {checking ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Mengecek...
            </>
          ) : (
            "Cek Status Pembayaran"
          )}
        </Button>
      )}

      {/* Close Button */}
      {(transactionStatus === "settlement" || transactionStatus === "capture" || transactionStatus === "deny" || transactionStatus === "cancel" || transactionStatus === "expire" || transactionStatus === "expired") && onClose && (
        <Button
          variant="outline"
          className="w-full"
          onClick={onClose}
        >
          Tutup
        </Button>
      )}
    </div>
  );
}
