import { Card, CardContent, CardHeader } from "./ui/card";
import { Alert, AlertDescription } from "./ui/alert";
import { AlertCircle, ExternalLink } from "lucide-react";
import { Button } from "./ui/button";

export function MidtransSetupInstructions() {
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto">
          <h1 className="mb-6">Panduan Setup Midtrans Payment</h1>
          
          <Alert className="mb-6">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Untuk menggunakan fitur pembayaran Midtrans, Anda perlu menambahkan kredensial Midtrans ke environment variables.
            </AlertDescription>
          </Alert>

          <Card className="mb-6">
            <CardHeader>
              <h2>Langkah 1: Daftar Akun Midtrans</h2>
            </CardHeader>
            <CardContent className="space-y-4">
              <ol className="list-decimal list-inside space-y-3 text-gray-700">
                <li>
                  Kunjungi{" "}
                  <a
                    href="https://dashboard.midtrans.com/register"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-600 hover:underline inline-flex items-center gap-1"
                  >
                    Midtrans Dashboard
                    <ExternalLink className="h-3 w-3" />
                  </a>
                </li>
                <li>Daftar akun baru atau login jika sudah punya akun</li>
                <li>Verifikasi email Anda</li>
                <li>Lengkapi profil bisnis Anda</li>
              </ol>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <h2>Langkah 2: Dapatkan API Keys</h2>
            </CardHeader>
            <CardContent className="space-y-4">
              <ol className="list-decimal list-inside space-y-3 text-gray-700">
                <li>Login ke Midtrans Dashboard</li>
                <li>Pilih environment <strong>Sandbox</strong> untuk testing</li>
                <li>
                  Buka menu <strong>Settings → Access Keys</strong>
                </li>
                <li>
                  Salin <strong>Server Key</strong> dan <strong>Client Key</strong>
                </li>
              </ol>
              
              <div className="bg-gray-50 p-4 rounded-lg mt-4">
                <p className="text-sm text-gray-600 mb-2">
                  Anda akan mendapatkan dua keys:
                </p>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li>
                    <strong>Server Key:</strong> Digunakan untuk backend API (contoh: SB-Mid-server-xxx)
                  </li>
                  <li>
                    <strong>Client Key:</strong> Digunakan untuk frontend Snap (contoh: SB-Mid-client-xxx)
                  </li>
                </ul>
              </div>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <h2>Langkah 3: Tambahkan ke Supabase Secrets</h2>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-700">
                Server Key sudah ditambahkan ke Supabase secrets. Untuk Client Key, tambahkan ke file <code className="bg-gray-100 px-2 py-1 rounded">.env</code>:
              </p>
              
              <div className="bg-gray-900 text-gray-100 p-4 rounded-lg font-mono text-sm">
                <div>VITE_MIDTRANS_CLIENT_KEY=SB-Mid-client-xxxxxxxxxx</div>
                <div>VITE_MIDTRANS_ENV=sandbox</div>
              </div>

              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription className="text-sm">
                  Untuk production, gunakan Production Keys dan ubah <code>VITE_MIDTRANS_ENV</code> menjadi <code>production</code>
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <h2>Langkah 4: Konfigurasi Notification URL (Opsional)</h2>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-700">
                Untuk menerima notifikasi pembayaran otomatis:
              </p>
              
              <ol className="list-decimal list-inside space-y-3 text-gray-700">
                <li>
                  Buka <strong>Settings → Configuration</strong> di Midtrans Dashboard
                </li>
                <li>
                  Tambahkan Notification URL:
                  <div className="bg-gray-50 p-3 rounded mt-2 font-mono text-sm break-all">
                    https://[PROJECT_ID].supabase.co/functions/v1/make-server-dbd6b95a/payment/notification
                  </div>
                </li>
                <li>Simpan konfigurasi</li>
              </ol>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <h2>Testing Pembayaran</h2>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-700">
                Untuk testing di Sandbox environment, gunakan nomor kartu kredit test:
              </p>
              
              <div className="bg-gray-50 p-4 rounded-lg space-y-2">
                <div>
                  <p className="text-sm">
                    <strong>Kartu Kredit (Success):</strong>
                  </p>
                  <p className="font-mono text-sm">4811 1111 1111 1114</p>
                </div>
                <div>
                  <p className="text-sm">
                    <strong>CVV:</strong> 123
                  </p>
                  <p className="text-sm">
                    <strong>Exp:</strong> 01/25 (atau bulan/tahun yang akan datang)
                  </p>
                </div>
              </div>

              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription className="text-sm">
                  Dokumentasi lengkap: {" "}
                  <a
                    href="https://docs.midtrans.com/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-600 hover:underline inline-flex items-center gap-1"
                  >
                    docs.midtrans.com
                    <ExternalLink className="h-3 w-3" />
                  </a>
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>

          <div className="mt-8 flex justify-center">
            <Button onClick={() => window.location.href = '/'}>
              Kembali ke Beranda
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
