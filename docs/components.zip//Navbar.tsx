import { useState, useEffect, useRef } from "react";
import { 
  Home, Search, HelpCircle, LogIn, User, Building2, FileText, 
  DollarSign, ClipboardList, Users, Settings, CheckSquare, Heart, 
  MessageSquare, AlertCircle, Bookmark, ChevronDown, Bell, Wallet,
  LayoutDashboard, FolderKanban, Menu, X
} from "lucide-react";
import { Button } from "./ui/button";

interface NavbarProps {
  role?: 'guest' | 'tenant' | 'owner' | 'admin';
  userName?: string;
  onNavigate: (path: string) => void;
  onLogout?: () => void;
}

interface DropdownState {
  properties: boolean;
  finance: boolean;
  support: boolean;
  user: boolean;
  mobile: boolean;
}

export function Navbar({ role = 'guest', userName, onNavigate, onLogout }: NavbarProps) {
  const [dropdowns, setDropdowns] = useState<DropdownState>({
    properties: false,
    finance: false,
    support: false,
    user: false,
    mobile: false,
  });

  const propertiesRef = useRef<HTMLDivElement>(null);
  const financeRef = useRef<HTMLDivElement>(null);
  const supportRef = useRef<HTMLDivElement>(null);
  const userRef = useRef<HTMLDivElement>(null);
  const mobileRef = useRef<HTMLDivElement>(null);

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (propertiesRef.current && !propertiesRef.current.contains(event.target as Node)) {
        setDropdowns(prev => ({ ...prev, properties: false }));
      }
      if (financeRef.current && !financeRef.current.contains(event.target as Node)) {
        setDropdowns(prev => ({ ...prev, finance: false }));
      }
      if (supportRef.current && !supportRef.current.contains(event.target as Node)) {
        setDropdowns(prev => ({ ...prev, support: false }));
      }
      if (userRef.current && !userRef.current.contains(event.target as Node)) {
        setDropdowns(prev => ({ ...prev, user: false }));
      }
      if (mobileRef.current && !mobileRef.current.contains(event.target as Node)) {
        setDropdowns(prev => ({ ...prev, mobile: false }));
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const toggleDropdown = (key: keyof DropdownState) => {
    setDropdowns(prev => ({
      properties: false,
      finance: false,
      support: false,
      user: false,
      mobile: false,
      [key]: !prev[key]
    }));
  };

  const closeAllDropdowns = () => {
    setDropdowns({
      properties: false,
      finance: false,
      support: false,
      user: false,
      mobile: false,
    });
  };

  const handleNavigation = (path: string) => {
    closeAllDropdowns();
    onNavigate(path);
  };

  // Guest Navbar
  if (role === 'guest') {
    return (
      <nav className="bg-white border-b border-gray-200 sticky top-0 z-50 shadow-sm">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-8">
              <button onClick={() => handleNavigation('/')} className="flex items-center gap-2 hover:opacity-80 transition-opacity">
                <Building2 className="h-6 w-6 text-blue-600" />
                <span className="text-xl font-semibold">KostIn</span>
              </button>
              <div className="hidden md:flex items-center gap-6">
                <button onClick={() => handleNavigation('/')} className="flex items-center gap-2 text-gray-700 hover:text-blue-600 transition-colors">
                  <Home className="h-4 w-4" />
                  Beranda
                </button>
                <button onClick={() => handleNavigation('/browse-kost')} className="flex items-center gap-2 text-gray-700 hover:text-blue-600 transition-colors">
                  <Search className="h-4 w-4" />
                  Cari Kos
                </button>
                <button onClick={() => handleNavigation('/faq')} className="flex items-center gap-2 text-gray-700 hover:text-blue-600 transition-colors">
                  <HelpCircle className="h-4 w-4" />
                  FAQ
                </button>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Button variant="ghost" onClick={() => handleNavigation('/login')}>
                <LogIn className="h-4 w-4 mr-2" />
                Masuk
              </Button>
              <Button onClick={() => handleNavigation('/register')}>
                Daftar
              </Button>
            </div>
          </div>
        </div>
      </nav>
    );
  }

  // Authenticated Navbar with role-based menus
  return (
    <nav className="bg-white border-b border-gray-200 sticky top-0 z-50 shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Brand */}
          <div className="flex items-center gap-6">
            <button onClick={() => handleNavigation('/')} className="flex items-center gap-2 hover:opacity-80 transition-opacity">
              <Building2 className="h-6 w-6 text-blue-600" />
              <span className="text-xl font-semibold">KostIn</span>
            </button>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center gap-4">
              {/* Dashboard - Always visible */}
              <button
                onClick={() => handleNavigation(`/${role}`)}
                className="flex items-center gap-2 px-3 py-2 text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-md transition-colors"
              >
                <LayoutDashboard className="h-4 w-4" />
                Dashboard
              </button>

              {/* Properties Dropdown - Owner only */}
              {role === 'owner' && (
                <div className="relative" ref={propertiesRef}>
                  <button
                    onClick={() => toggleDropdown('properties')}
                    className="flex items-center gap-2 px-3 py-2 text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-md transition-colors"
                  >
                    <Building2 className="h-4 w-4" />
                    Properti
                    <ChevronDown className={`h-3 w-3 transition-transform ${dropdowns.properties ? 'rotate-180' : ''}`} />
                  </button>
                  {dropdowns.properties && (
                    <div className="absolute left-0 mt-2 w-56 bg-white rounded-lg shadow-lg border border-gray-200 py-2 z-50">
                      <button
                        onClick={() => handleNavigation('/owner/properties')}
                        className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                      >
                        <Building2 className="h-4 w-4" />
                        <div className="text-left">
                          <div className="font-medium">Kelola Properti</div>
                          <div className="text-xs text-gray-500">Daftar & edit kos</div>
                        </div>
                      </button>
                      <button
                        onClick={() => handleNavigation('/owner/tasks')}
                        className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                      >
                        <ClipboardList className="h-4 w-4" />
                        <div className="text-left">
                          <div className="font-medium">Tugas Fasilitas</div>
                          <div className="text-xs text-gray-500">Maintenance & perbaikan</div>
                        </div>
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* Finance Dropdown - Tenant, Owner, Admin */}
              <div className="relative" ref={financeRef}>
                <button
                  onClick={() => toggleDropdown('finance')}
                  className="flex items-center gap-2 px-3 py-2 text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-md transition-colors"
                >
                  <Wallet className="h-4 w-4" />
                  Keuangan
                  <ChevronDown className={`h-3 w-3 transition-transform ${dropdowns.finance ? 'rotate-180' : ''}`} />
                </button>
                {dropdowns.finance && (
                  <div className="absolute left-0 mt-2 w-56 bg-white rounded-lg shadow-lg border border-gray-200 py-2 z-50">
                    {/* Tenant Finance Menu */}
                    {role === 'tenant' && (
                      <>
                        <button
                          onClick={() => handleNavigation('/tenant/invoices')}
                          className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                        >
                          <DollarSign className="h-4 w-4" />
                          <div className="text-left">
                            <div className="font-medium">Tagihan Saya</div>
                            <div className="text-xs text-gray-500">Lihat & bayar tagihan</div>
                          </div>
                        </button>
                        <button
                          onClick={() => handleNavigation('/tenant/contracts')}
                          className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                        >
                          <FileText className="h-4 w-4" />
                          <div className="text-left">
                            <div className="font-medium">Kontrak Sewa</div>
                            <div className="text-xs text-gray-500">Detail kontrak aktif</div>
                          </div>
                        </button>
                      </>
                    )}

                    {/* Owner Finance Menu */}
                    {role === 'owner' && (
                      <>
                        <button
                          onClick={() => handleNavigation('/owner/invoices')}
                          className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                        >
                          <DollarSign className="h-4 w-4" />
                          <div className="text-left">
                            <div className="font-medium">Tagihan</div>
                            <div className="text-xs text-gray-500">Kelola tagihan penyewa</div>
                          </div>
                        </button>
                        <button
                          onClick={() => handleNavigation('/owner/contracts')}
                          className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                        >
                          <FileText className="h-4 w-4" />
                          <div className="text-left">
                            <div className="font-medium">Kontrak</div>
                            <div className="text-xs text-gray-500">Kontrak aktif & history</div>
                          </div>
                        </button>
                        <div className="border-t border-gray-100 my-1"></div>
                        <button
                          onClick={() => handleNavigation('/owner/manual-payments')}
                          className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                        >
                          <CheckSquare className="h-4 w-4" />
                          <div className="text-left">
                            <div className="font-medium">Verifikasi Pembayaran</div>
                            <div className="text-xs text-gray-500">Approve bukti transfer</div>
                          </div>
                        </button>
                      </>
                    )}

                    {/* Admin Finance Menu */}
                    {role === 'admin' && (
                      <>
                        <button
                          onClick={() => handleNavigation('/admin/invoices')}
                          className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                        >
                          <DollarSign className="h-4 w-4" />
                          <div className="text-left">
                            <div className="font-medium">Semua Tagihan</div>
                            <div className="text-xs text-gray-500">Monitor seluruh tagihan</div>
                          </div>
                        </button>
                        <button
                          onClick={() => handleNavigation('/admin/manual-payments')}
                          className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                        >
                          <CheckSquare className="h-4 w-4" />
                          <div className="text-left">
                            <div className="font-medium">Verifikasi Global</div>
                            <div className="text-xs text-gray-500">Review semua pembayaran</div>
                          </div>
                        </button>
                      </>
                    )}
                  </div>
                )}
              </div>

              {/* Browse/Search - All authenticated users */}
              <button
                onClick={() => handleNavigation('/browse-kost')}
                className="flex items-center gap-2 px-3 py-2 text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-md transition-colors"
              >
                <Search className="h-4 w-4" />
                Cari Kos
              </button>

              {/* Support Dropdown - All authenticated users */}
              <div className="relative" ref={supportRef}>
                <button
                  onClick={() => toggleDropdown('support')}
                  className="flex items-center gap-2 px-3 py-2 text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-md transition-colors"
                >
                  <MessageSquare className="h-4 w-4" />
                  Bantuan
                  <ChevronDown className={`h-3 w-3 transition-transform ${dropdowns.support ? 'rotate-180' : ''}`} />
                </button>
                {dropdowns.support && (
                  <div className="absolute left-0 mt-2 w-56 bg-white rounded-lg shadow-lg border border-gray-200 py-2 z-50">
                    <button
                      onClick={() => handleNavigation('/chat')}
                      className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                    >
                      <MessageSquare className="h-4 w-4" />
                      <div className="text-left">
                        <div className="font-medium">Live Chat</div>
                        <div className="text-xs text-gray-500">Chat dengan pemilik/admin</div>
                      </div>
                    </button>
                    <button
                      onClick={() => handleNavigation('/tickets')}
                      className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                    >
                      <AlertCircle className="h-4 w-4" />
                      <div className="text-left">
                        <div className="font-medium">Tiket Support</div>
                        <div className="text-xs text-gray-500">Buat & kelola tiket</div>
                      </div>
                    </button>
                    <div className="border-t border-gray-100 my-1"></div>
                    <button
                      onClick={() => handleNavigation('/faq')}
                      className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                    >
                      <HelpCircle className="h-4 w-4" />
                      <div className="text-left">
                        <div className="font-medium">FAQ</div>
                        <div className="text-xs text-gray-500">Pertanyaan umum</div>
                      </div>
                    </button>
                  </div>
                )}
              </div>

              {/* Admin specific - Users & Settings */}
              {role === 'admin' && (
                <>
                  <button
                    onClick={() => handleNavigation('/admin/users')}
                    className="flex items-center gap-2 px-3 py-2 text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-md transition-colors"
                  >
                    <Users className="h-4 w-4" />
                    Pengguna
                  </button>
                  <button
                    onClick={() => handleNavigation('/admin/settings')}
                    className="flex items-center gap-2 px-3 py-2 text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-md transition-colors"
                  >
                    <Settings className="h-4 w-4" />
                    Pengaturan
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Right side - User menu & Mobile toggle */}
          <div className="flex items-center gap-3">
            {/* Notifications - Desktop only */}
            <button
              className="hidden lg:flex items-center justify-center w-10 h-10 text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-full transition-colors relative"
              onClick={() => handleNavigation('/settings/notifications')}
            >
              <Bell className="h-5 w-5" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
            </button>

            {/* User Dropdown */}
            <div className="relative" ref={userRef}>
              <button
                onClick={() => toggleDropdown('user')}
                className="flex items-center gap-2 px-3 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white">
                  <User className="h-4 w-4" />
                </div>
                <span className="hidden md:inline text-sm font-medium">{userName || 'User'}</span>
                <ChevronDown className={`h-3 w-3 hidden md:inline transition-transform ${dropdowns.user ? 'rotate-180' : ''}`} />
              </button>

              {dropdowns.user && (
                <div className="absolute right-0 mt-2 w-64 bg-white rounded-lg shadow-xl border border-gray-200 py-2 z-50">
                  <div className="px-4 py-3 border-b border-gray-100">
                    <p className="text-sm font-semibold text-gray-900">{userName || 'User'}</p>
                    <p className="text-xs text-gray-500 capitalize">{role} Account</p>
                  </div>
                  
                  <div className="py-1">
                    <button
                      onClick={() => handleNavigation('/profile')}
                      className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                    >
                      <User className="h-4 w-4" />
                      <div className="text-left">
                        <div className="font-medium">Profil Saya</div>
                        <div className="text-xs text-gray-500">Kelola akun & info</div>
                      </div>
                    </button>

                    {(role === 'tenant' || role === 'owner') && (
                      <>
                        <button
                          onClick={() => handleNavigation('/wishlist')}
                          className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                        >
                          <Heart className="h-4 w-4" />
                          <div className="text-left">
                            <div className="font-medium">Wishlist</div>
                            <div className="text-xs text-gray-500">Kos favorit saya</div>
                          </div>
                        </button>
                        <button
                          onClick={() => handleNavigation('/saved-searches')}
                          className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                        >
                          <Bookmark className="h-4 w-4" />
                          <div className="text-left">
                            <div className="font-medium">Pencarian Tersimpan</div>
                            <div className="text-xs text-gray-500">Filter & notifikasi</div>
                          </div>
                        </button>
                      </>
                    )}
                  </div>

                  <div className="border-t border-gray-100 my-1"></div>

                  <button
                    onClick={() => handleNavigation('/settings/notifications')}
                    className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                  >
                    <Settings className="h-4 w-4" />
                    Pengaturan
                  </button>

                  <div className="border-t border-gray-100 my-1"></div>

                  <button
                    onClick={() => {
                      closeAllDropdowns();
                      if (onLogout) onLogout();
                    }}
                    className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-red-600 hover:bg-red-50 transition-colors"
                  >
                    <LogIn className="h-4 w-4" />
                    Keluar
                  </button>
                </div>
              )}
            </div>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => toggleDropdown('mobile')}
              className="lg:hidden flex items-center justify-center w-10 h-10 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
            >
              {dropdowns.mobile ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {dropdowns.mobile && (
          <div className="lg:hidden border-t border-gray-200 py-4" ref={mobileRef}>
            <div className="flex flex-col space-y-1">
              {/* Dashboard */}
              <button
                onClick={() => handleNavigation(`/${role}`)}
                className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
              >
                <LayoutDashboard className="h-5 w-5" />
                <span className="font-medium">Dashboard</span>
              </button>

              {/* Tenant Mobile Menu */}
              {role === 'tenant' && (
                <>
                  <button
                    onClick={() => handleNavigation('/tenant/contracts')}
                    className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                  >
                    <FileText className="h-5 w-5" />
                    <span className="font-medium">Kontrak Saya</span>
                  </button>
                  <button
                    onClick={() => handleNavigation('/tenant/invoices')}
                    className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                  >
                    <DollarSign className="h-5 w-5" />
                    <span className="font-medium">Tagihan</span>
                  </button>
                </>
              )}

              {/* Owner Mobile Menu */}
              {role === 'owner' && (
                <>
                  <button
                    onClick={() => handleNavigation('/owner/properties')}
                    className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                  >
                    <Building2 className="h-5 w-5" />
                    <span className="font-medium">Kelola Properti</span>
                  </button>
                  <button
                    onClick={() => handleNavigation('/owner/contracts')}
                    className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                  >
                    <FileText className="h-5 w-5" />
                    <span className="font-medium">Kontrak</span>
                  </button>
                  <button
                    onClick={() => handleNavigation('/owner/invoices')}
                    className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                  >
                    <DollarSign className="h-5 w-5" />
                    <span className="font-medium">Tagihan</span>
                  </button>
                  <button
                    onClick={() => handleNavigation('/owner/manual-payments')}
                    className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                  >
                    <CheckSquare className="h-5 w-5" />
                    <span className="font-medium">Verifikasi Pembayaran</span>
                  </button>
                  <button
                    onClick={() => handleNavigation('/owner/tasks')}
                    className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                  >
                    <ClipboardList className="h-5 w-5" />
                    <span className="font-medium">Tugas Fasilitas</span>
                  </button>
                </>
              )}

              {/* Admin Mobile Menu */}
              {role === 'admin' && (
                <>
                  <button
                    onClick={() => handleNavigation('/admin/invoices')}
                    className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                  >
                    <DollarSign className="h-5 w-5" />
                    <span className="font-medium">Semua Tagihan</span>
                  </button>
                  <button
                    onClick={() => handleNavigation('/admin/manual-payments')}
                    className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                  >
                    <CheckSquare className="h-5 w-5" />
                    <span className="font-medium">Verifikasi Global</span>
                  </button>
                  <button
                    onClick={() => handleNavigation('/admin/users')}
                    className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                  >
                    <Users className="h-5 w-5" />
                    <span className="font-medium">Kelola Pengguna</span>
                  </button>
                  <button
                    onClick={() => handleNavigation('/admin/settings')}
                    className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                  >
                    <Settings className="h-5 w-5" />
                    <span className="font-medium">Pengaturan Sistem</span>
                  </button>
                </>
              )}

              {/* Common Mobile Menu Items */}
              <div className="border-t border-gray-200 my-2"></div>
              
              <button
                onClick={() => handleNavigation('/browse-kost')}
                className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
              >
                <Search className="h-5 w-5" />
                <span className="font-medium">Cari Kos</span>
              </button>

              {(role === 'tenant' || role === 'owner') && (
                <>
                  <button
                    onClick={() => handleNavigation('/wishlist')}
                    className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                  >
                    <Heart className="h-5 w-5" />
                    <span className="font-medium">Wishlist</span>
                  </button>
                  <button
                    onClick={() => handleNavigation('/saved-searches')}
                    className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                  >
                    <Bookmark className="h-5 w-5" />
                    <span className="font-medium">Pencarian Tersimpan</span>
                  </button>
                </>
              )}

              <button
                onClick={() => handleNavigation('/chat')}
                className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
              >
                <MessageSquare className="h-5 w-5" />
                <span className="font-medium">Live Chat</span>
              </button>

              <button
                onClick={() => handleNavigation('/tickets')}
                className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
              >
                <AlertCircle className="h-5 w-5" />
                <span className="font-medium">Tiket Support</span>
              </button>

              <button
                onClick={() => handleNavigation('/faq')}
                className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
              >
                <HelpCircle className="h-5 w-5" />
                <span className="font-medium">FAQ</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
