import { Building2, Users, DollarSign, TrendingUp, AlertTriangle, CheckCircle, Plus } from "lucide-react";
import { Card, CardContent, CardHeader } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";

interface OwnerDashboardProps {
  onNavigate: (path: string) => void;
}

export function OwnerDashboard({ onNavigate }: OwnerDashboardProps) {
  const stats = [
    {
      title: "Total Properti",
      value: "3",
      icon: Building2,
      color: "text-blue-600",
      bgColor: "bg-blue-50",
      change: "+1 bulan ini",
    },
    {
      title: "Total Penyewa Aktif",
      value: "24",
      icon: Users,
      color: "text-green-600",
      bgColor: "bg-green-50",
      change: "+3 dari bulan lalu",
    },
    {
      title: "Pendapatan Bulan Ini",
      value: "Rp 28.800.000",
      icon: DollarSign,
      color: "text-emerald-600",
      bgColor: "bg-emerald-50",
      change: "+12% dari bulan lalu",
    },
    {
      title: "Tingkat Okupansi",
      value: "82%",
      icon: TrendingUp,
      color: "text-purple-600",
      bgColor: "bg-purple-50",
      change: "24/30 kamar terisi",
    },
  ];

  const properties = [
    {
      id: 1,
      name: "Kos Melati Residence",
      location: "Dramaga, Bogor",
      totalRooms: 12,
      occupiedRooms: 10,
      revenue: 12000000,
    },
    {
      id: 2,
      name: "Kos Mawar Indah",
      location: "Pajajaran, Bogor",
      totalRooms: 10,
      occupiedRooms: 8,
      revenue: 10500000,
    },
    {
      id: 3,
      name: "Kos Anggrek Premium",
      location: "Merdeka, Bogor",
      totalRooms: 8,
      occupiedRooms: 6,
      revenue: 6300000,
    },
  ];

  const upcomingPayments = [
    { tenant: "Ahmad Fauzi", room: "Melati - 101", amount: 1200000, dueDate: "5 Nov 2024", status: "pending" },
    { tenant: "Siti Nurhaliza", room: "Mawar - 201", amount: 1500000, dueDate: "5 Nov 2024", status: "pending" },
    { tenant: "Budi Santoso", room: "Anggrek - 301", amount: 1800000, dueDate: "3 Nov 2024", status: "overdue" },
  ];

  const tasks = [
    { title: "Isi ulang sabun dapur", property: "Kos Melati", priority: "high", dueDate: "Hari ini" },
    { title: "Ganti tabung gas", property: "Kos Mawar", priority: "medium", dueDate: "Besok" },
    { title: "Bersihkan taman depan", property: "Kos Anggrek", priority: "low", dueDate: "3 hari lagi" },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1>Dashboard Pemilik</h1>
            <p className="text-gray-600">Kelola properti dan penyewa Anda</p>
          </div>
          <Button onClick={() => onNavigate('/owner/properties/create')}>
            <Plus className="h-4 w-4 mr-2" />
            Tambah Properti
          </Button>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat) => (
            <Card key={stat.title}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className={`w-12 h-12 ${stat.bgColor} rounded-lg flex items-center justify-center`}>
                    <stat.icon className={`h-6 w-6 ${stat.color}`} />
                  </div>
                </div>
                <p className="text-gray-600 text-sm mb-1">{stat.title}</p>
                <p className={`text-2xl mb-2 ${stat.color}`}>{stat.value}</p>
                <p className="text-xs text-gray-500">{stat.change}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Properties Overview */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <h2>Properti Saya</h2>
                  <Button variant="link" onClick={() => onNavigate('/owner/properties')}>
                    Lihat Semua →
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {properties.map((property) => {
                  const occupancyRate = (property.occupiedRooms / property.totalRooms) * 100;
                  return (
                    <div
                      key={property.id}
                      className="p-4 border rounded-lg hover:bg-gray-50 cursor-pointer"
                      onClick={() => onNavigate(`/owner/properties/${property.id}`)}
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h3>{property.name}</h3>
                          <p className="text-sm text-gray-600">{property.location}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-green-600">
                            Rp {property.revenue.toLocaleString('id-ID')}
                          </p>
                          <p className="text-xs text-gray-500">pendapatan/bulan</p>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-gray-600">Okupansi</span>
                          <span>{property.occupiedRooms}/{property.totalRooms} kamar ({occupancyRate.toFixed(0)}%)</span>
                        </div>
                        <Progress value={occupancyRate} className="h-2" />
                      </div>
                    </div>
                  );
                })}
              </CardContent>
            </Card>

            {/* Upcoming Payments */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <h2>Tagihan Akan Datang</h2>
                  <Button variant="link" onClick={() => onNavigate('/owner/invoices')}>
                    Lihat Semua →
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {upcomingPayments.map((payment, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-3">
                        {payment.status === 'overdue' ? (
                          <AlertTriangle className="h-5 w-5 text-red-500" />
                        ) : (
                          <DollarSign className="h-5 w-5 text-orange-500" />
                        )}
                        <div>
                          <p>{payment.tenant}</p>
                          <p className="text-sm text-gray-600">{payment.room}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p>Rp {payment.amount.toLocaleString('id-ID')}</p>
                        <Badge
                          className={payment.status === 'overdue' ? 'bg-red-500' : 'bg-orange-500'}
                        >
                          {payment.status === 'overdue' ? 'Terlambat' : payment.dueDate}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <h3>Aksi Cepat</h3>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => onNavigate('/owner/contracts/create')}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Buat Kontrak Baru
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => onNavigate('/owner/properties/create')}
                >
                  <Building2 className="h-4 w-4 mr-2" />
                  Tambah Properti
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => onNavigate('/owner/tasks/create')}
                >
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Buat Tugas Baru
                </Button>
              </CardContent>
            </Card>

            {/* Tasks */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <h3>Tugas Fasilitas</h3>
                  <Button variant="link" onClick={() => onNavigate('/owner/tasks')}>
                    Lihat Semua →
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {tasks.map((task, index) => (
                  <div key={index} className="p-3 border rounded-lg">
                    <div className="flex items-start justify-between mb-2">
                      <p className="text-sm">{task.title}</p>
                      <Badge
                        variant="outline"
                        className={
                          task.priority === 'high'
                            ? 'border-red-500 text-red-600'
                            : task.priority === 'medium'
                            ? 'border-orange-500 text-orange-600'
                            : 'border-gray-500 text-gray-600'
                        }
                      >
                        {task.priority === 'high' ? 'Tinggi' : task.priority === 'medium' ? 'Sedang' : 'Rendah'}
                      </Badge>
                    </div>
                    <p className="text-xs text-gray-600">{task.property}</p>
                    <p className="text-xs text-gray-500 mt-1">{task.dueDate}</p>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
