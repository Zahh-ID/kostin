import { useState } from "react";
import { 
  Search, 
  Filter, 
  Download, 
  Eye, 
  CheckCircle, 
  Clock, 
  XCircle,
  Calendar,
  Plus,
  ArrowLeft,
  Send
} from "lucide-react";
import { Card, CardContent, CardHeader } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "./ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";

interface OwnerInvoicesPageProps {
  onNavigate: (path: string) => void;
}

export function OwnerInvoicesPage({ onNavigate }: OwnerInvoicesPageProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [propertyFilter, setPropertyFilter] = useState("all");
  const [selectedInvoice, setSelectedInvoice] = useState<any>(null);

  const invoices = [
    {
      id: "INV-2024-001",
      tenant: "Ahmad Fauzi",
      tenantEmail: "ahmad@email.com",
      property: "Kos Melati Residence",
      room: "Kamar 101",
      month: "November 2024",
      issueDate: "2024-11-01",
      dueDate: "2024-11-05",
      amount: 1200000,
      status: "pending",
    },
    {
      id: "INV-2024-002",
      tenant: "Siti Nurhaliza",
      tenantEmail: "siti@email.com",
      property: "Kos Mawar Indah",
      room: "Kamar 201",
      month: "November 2024",
      issueDate: "2024-11-01",
      dueDate: "2024-11-05",
      amount: 1500000,
      status: "pending",
    },
    {
      id: "INV-2024-003",
      tenant: "Budi Santoso",
      tenantEmail: "budi@email.com",
      property: "Kos Anggrek Premium",
      room: "Kamar 301",
      month: "November 2024",
      issueDate: "2024-11-01",
      dueDate: "2024-11-03",
      amount: 1800000,
      status: "overdue",
    },
    {
      id: "INV-2024-004",
      tenant: "Ahmad Fauzi",
      tenantEmail: "ahmad@email.com",
      property: "Kos Melati Residence",
      room: "Kamar 101",
      month: "Oktober 2024",
      issueDate: "2024-10-01",
      dueDate: "2024-10-05",
      paidDate: "2024-10-03",
      amount: 1200000,
      status: "paid",
      paymentMethod: "QRIS",
    },
    {
      id: "INV-2024-005",
      tenant: "Siti Nurhaliza",
      tenantEmail: "siti@email.com",
      property: "Kos Mawar Indah",
      room: "Kamar 201",
      month: "Oktober 2024",
      issueDate: "2024-10-01",
      dueDate: "2024-10-05",
      paidDate: "2024-10-04",
      amount: 1500000,
      status: "paid",
      paymentMethod: "Transfer Bank",
    },
  ];

  const properties = [
    { id: 1, name: "Kos Melati Residence" },
    { id: 2, name: "Kos Mawar Indah" },
    { id: 3, name: "Kos Anggrek Premium" },
  ];

  const filteredInvoices = invoices.filter((invoice) => {
    const matchesSearch = 
      invoice.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      invoice.tenant.toLowerCase().includes(searchTerm.toLowerCase()) ||
      invoice.room.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "all" || invoice.status === statusFilter;
    const matchesProperty = propertyFilter === "all" || invoice.property === propertyFilter;
    return matchesSearch && matchesStatus && matchesProperty;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "paid":
        return <Badge className="bg-green-500"><CheckCircle className="h-3 w-3 mr-1" />Lunas</Badge>;
      case "pending":
        return <Badge className="bg-orange-500"><Clock className="h-3 w-3 mr-1" />Menunggu</Badge>;
      case "overdue":
        return <Badge className="bg-red-500"><XCircle className="h-3 w-3 mr-1" />Terlambat</Badge>;
      default:
        return null;
    }
  };

  const stats = [
    {
      label: "Total Tagihan",
      value: invoices.length,
      color: "text-blue-600",
    },
    {
      label: "Belum Dibayar",
      value: invoices.filter(inv => inv.status === "pending").length,
      color: "text-orange-600",
    },
    {
      label: "Terlambat",
      value: invoices.filter(inv => inv.status === "overdue").length,
      color: "text-red-600",
    },
    {
      label: "Total Pendapatan",
      value: `Rp ${invoices.filter(inv => inv.status === "paid").reduce((sum, inv) => sum + inv.amount, 0).toLocaleString('id-ID')}`,
      color: "text-green-600",
    },
  ];

  const handleSendReminder = (invoice: any) => {
    alert(`Pengingat pembayaran dikirim ke ${invoice.tenantEmail}`);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => onNavigate('/owner/dashboard')}
            className="mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Kembali ke Dashboard
          </Button>
          <div className="flex items-center justify-between">
            <div>
              <h1>Daftar Tagihan</h1>
              <p className="text-gray-600">Kelola tagihan penyewa di semua properti Anda</p>
            </div>
            <Button onClick={() => onNavigate('/owner/invoices/create')}>
              <Plus className="h-4 w-4 mr-2" />
              Buat Tagihan Baru
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          {stats.map((stat) => (
            <Card key={stat.label}>
              <CardContent className="p-6">
                <p className="text-sm text-gray-600 mb-1">{stat.label}</p>
                <p className={`text-2xl ${stat.color}`}>{stat.value}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Cari invoice, penyewa, atau kamar..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={propertyFilter} onValueChange={setPropertyFilter}>
                <SelectTrigger className="w-full md:w-[200px]">
                  <SelectValue placeholder="Properti" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Semua Properti</SelectItem>
                  {properties.map((property) => (
                    <SelectItem key={property.id} value={property.name}>
                      {property.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full md:w-[200px]">
                  <Filter className="h-4 w-4 mr-2" />
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Semua Status</SelectItem>
                  <SelectItem value="pending">Menunggu</SelectItem>
                  <SelectItem value="paid">Lunas</SelectItem>
                  <SelectItem value="overdue">Terlambat</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Invoices Table */}
        <Card>
          <CardHeader>
            <h2>Semua Tagihan</h2>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>No. Invoice</TableHead>
                  <TableHead>Penyewa</TableHead>
                  <TableHead>Properti</TableHead>
                  <TableHead>Periode</TableHead>
                  <TableHead>Jatuh Tempo</TableHead>
                  <TableHead>Jumlah</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Aksi</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredInvoices.map((invoice) => (
                  <TableRow key={invoice.id}>
                    <TableCell>
                      <div>
                        <p>{invoice.id}</p>
                        <p className="text-sm text-gray-500">
                          {new Date(invoice.issueDate).toLocaleDateString('id-ID')}
                        </p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <p>{invoice.tenant}</p>
                        <p className="text-sm text-gray-500">{invoice.tenantEmail}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <p>{invoice.property}</p>
                        <p className="text-sm text-gray-500">{invoice.room}</p>
                      </div>
                    </TableCell>
                    <TableCell>{invoice.month}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-gray-400" />
                        {new Date(invoice.dueDate).toLocaleDateString('id-ID')}
                      </div>
                    </TableCell>
                    <TableCell>
                      <p>Rp {invoice.amount.toLocaleString('id-ID')}</p>
                    </TableCell>
                    <TableCell>{getStatusBadge(invoice.status)}</TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setSelectedInvoice(invoice)}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        {invoice.status === "pending" || invoice.status === "overdue" ? (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleSendReminder(invoice)}
                          >
                            <Send className="h-4 w-4" />
                          </Button>
                        ) : null}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      {/* Invoice Detail Dialog */}
      <Dialog open={!!selectedInvoice} onOpenChange={() => setSelectedInvoice(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Detail Tagihan</DialogTitle>
          </DialogHeader>
          {selectedInvoice && (
            <div className="space-y-4">
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">No. Invoice</span>
                  <span>{selectedInvoice.id}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Penyewa</span>
                  <div className="text-right">
                    <p>{selectedInvoice.tenant}</p>
                    <p className="text-sm text-gray-500">{selectedInvoice.tenantEmail}</p>
                  </div>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Properti</span>
                  <div className="text-right">
                    <p>{selectedInvoice.property}</p>
                    <p className="text-sm text-gray-500">{selectedInvoice.room}</p>
                  </div>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Periode</span>
                  <span>{selectedInvoice.month}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Tanggal Terbit</span>
                  <span>{new Date(selectedInvoice.issueDate).toLocaleDateString('id-ID')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Jatuh Tempo</span>
                  <span>{new Date(selectedInvoice.dueDate).toLocaleDateString('id-ID')}</span>
                </div>
                {selectedInvoice.paidDate && (
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Tanggal Bayar</span>
                    <span>{new Date(selectedInvoice.paidDate).toLocaleDateString('id-ID')}</span>
                  </div>
                )}
                {selectedInvoice.paymentMethod && (
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Metode Pembayaran</span>
                    <span>{selectedInvoice.paymentMethod}</span>
                  </div>
                )}
              </div>

              <div className="border-t pt-4">
                <div className="flex justify-between mb-2">
                  <span className="text-sm text-gray-600">Biaya Sewa</span>
                  <span>Rp {selectedInvoice.amount.toLocaleString('id-ID')}</span>
                </div>
                <div className="flex justify-between pt-2 border-t">
                  <span>Total</span>
                  <span className="text-blue-600">
                    Rp {selectedInvoice.amount.toLocaleString('id-ID')}
                  </span>
                </div>
              </div>

              <div className="flex justify-between items-center pt-4 border-t">
                <span>Status</span>
                {getStatusBadge(selectedInvoice.status)}
              </div>

              <div className="flex gap-2">
                {selectedInvoice.status === "pending" || selectedInvoice.status === "overdue" ? (
                  <Button
                    className="flex-1"
                    onClick={() => handleSendReminder(selectedInvoice)}
                  >
                    <Send className="h-4 w-4 mr-2" />
                    Kirim Pengingat
                  </Button>
                ) : null}
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => setSelectedInvoice(null)}
                >
                  Tutup
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
