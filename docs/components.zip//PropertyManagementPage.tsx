import { useState, useEffect } from "react";
import { Plus, Search, Edit, Trash2, Eye, MapPin, Building2, BedDouble, DollarSign } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Card, CardContent, CardHeader } from "./ui/card";
import { Badge } from "./ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "./ui/dialog";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { toast } from "sonner@2.0.3";
import { projectId } from "../utils/supabase/info";
import { createClient } from "../utils/supabase/client";

interface PropertyManagementPageProps {
  onNavigate: (path: string) => void;
}

export function PropertyManagementPage({ onNavigate }: PropertyManagementPageProps) {
  const [properties, setProperties] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editingProperty, setEditingProperty] = useState<any>(null);
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    address: "",
    city: "",
    type: "putra",
    pricePerMonth: "",
    availableRooms: "",
    totalRooms: "",
    facilities: [] as string[],
    images: [] as string[],
  });
  const supabase = createClient();

  useEffect(() => {
    fetchProperties();
  }, []);

  const fetchProperties = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session?.access_token) {
        toast.error("Silakan login terlebih dahulu");
        return;
      }

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-dbd6b95a/properties`,
        {
          headers: {
            Authorization: `Bearer ${session.access_token}`,
          },
        }
      );

      const data = await response.json();

      if (response.ok) {
        // Filter to show only user's properties
        const userProperties = data.properties.filter(
          (p: any) => p.ownerId === session.user.id
        );
        setProperties(userProperties);
      } else {
        throw new Error(data.error);
      }
    } catch (error: any) {
      console.error("Fetch properties error:", error);
      toast.error(error.message || "Gagal memuat properti");
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session?.access_token) {
        toast.error("Silakan login terlebih dahulu");
        return;
      }

      const url = editingProperty
        ? `https://${projectId}.supabase.co/functions/v1/make-server-dbd6b95a/properties/${editingProperty.id}`
        : `https://${projectId}.supabase.co/functions/v1/make-server-dbd6b95a/properties`;

      const response = await fetch(url, {
        method: editingProperty ? "PUT" : "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({
          ...formData,
          pricePerMonth: parseInt(formData.pricePerMonth),
          availableRooms: parseInt(formData.availableRooms),
          totalRooms: parseInt(formData.totalRooms),
        }),
      });

      const data = await response.json();

      if (response.ok) {
        toast.success(editingProperty ? "Properti berhasil diupdate" : "Properti berhasil ditambahkan");
        setShowAddDialog(false);
        setEditingProperty(null);
        resetForm();
        fetchProperties();
      } else {
        throw new Error(data.error);
      }
    } catch (error: any) {
      console.error("Submit property error:", error);
      toast.error(error.message || "Gagal menyimpan properti");
    }
  };

  const handleDelete = async (propertyId: string) => {
    if (!confirm("Apakah Anda yakin ingin menghapus properti ini?")) return;

    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session?.access_token) {
        toast.error("Silakan login terlebih dahulu");
        return;
      }

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-dbd6b95a/properties/${propertyId}`,
        {
          method: "DELETE",
          headers: {
            Authorization: `Bearer ${session.access_token}`,
          },
        }
      );

      const data = await response.json();

      if (response.ok) {
        toast.success("Properti berhasil dihapus");
        fetchProperties();
      } else {
        throw new Error(data.error);
      }
    } catch (error: any) {
      console.error("Delete property error:", error);
      toast.error(error.message || "Gagal menghapus properti");
    }
  };

  const resetForm = () => {
    setFormData({
      name: "",
      description: "",
      address: "",
      city: "",
      type: "putra",
      pricePerMonth: "",
      availableRooms: "",
      totalRooms: "",
      facilities: [],
      images: [],
    });
  };

  const openEditDialog = (property: any) => {
    setEditingProperty(property);
    setFormData({
      name: property.name || "",
      description: property.description || "",
      address: property.address || "",
      city: property.city || "",
      type: property.type || "putra",
      pricePerMonth: property.pricePerMonth?.toString() || "",
      availableRooms: property.availableRooms?.toString() || "",
      totalRooms: property.totalRooms?.toString() || "",
      facilities: property.facilities || [],
      images: property.images || [],
    });
    setShowAddDialog(true);
  };

  const filteredProperties = properties.filter((property) =>
    property.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    property.city?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      active: { label: "Aktif", className: "bg-green-100 text-green-700" },
      pending_approval: { label: "Menunggu Verifikasi", className: "bg-yellow-100 text-yellow-700" },
      rejected: { label: "Ditolak", className: "bg-red-100 text-red-700" },
    };

    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.pending_approval;
    return <Badge className={config.className}>{config.label}</Badge>;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Memuat properti...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="mb-2">Kelola Properti</h1>
          <p className="text-gray-600">Tambah dan kelola properti kos Anda</p>
        </div>

        {/* Actions */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Cari properti..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Button onClick={() => { resetForm(); setShowAddDialog(true); }}>
            <Plus className="h-4 w-4 mr-2" />
            Tambah Properti
          </Button>
        </div>

        {/* Properties Grid */}
        {filteredProperties.length === 0 ? (
          <Card>
            <CardContent className="p-12 text-center">
              <Building2 className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="mb-2 text-gray-900">Belum ada properti</h3>
              <p className="text-gray-600 mb-4">
                Mulai tambahkan properti kos Anda untuk ditampilkan ke penyewa
              </p>
              <Button onClick={() => { resetForm(); setShowAddDialog(true); }}>
                <Plus className="h-4 w-4 mr-2" />
                Tambah Properti Pertama
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProperties.map((property) => (
              <Card key={property.id} className="hover:shadow-lg transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-lg m-0">{property.name}</h3>
                    {getStatusBadge(property.status)}
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <MapPin className="h-4 w-4 mr-1" />
                    {property.city}
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">Harga</span>
                    <span className="font-semibold text-blue-600">
                      Rp {property.pricePerMonth?.toLocaleString('id-ID')}/bulan
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">Kamar Tersedia</span>
                    <span className="font-medium">
                      {property.availableRooms}/{property.totalRooms}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">Tipe</span>
                    <Badge variant="outline">
                      {property.type === 'putra' ? 'Putra' : property.type === 'putri' ? 'Putri' : 'Campur'}
                    </Badge>
                  </div>

                  <div className="flex gap-2 pt-3 border-t">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1"
                      onClick={() => onNavigate(`/property/${property.id}`)}
                    >
                      <Eye className="h-4 w-4 mr-1" />
                      Lihat
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1"
                      onClick={() => openEditDialog(property)}
                    >
                      <Edit className="h-4 w-4 mr-1" />
                      Edit
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDelete(property.id)}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Add/Edit Dialog */}
        <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingProperty ? "Edit Properti" : "Tambah Properti Baru"}</DialogTitle>
              <DialogDescription>
                {editingProperty 
                  ? "Update informasi properti kos Anda"
                  : "Isi informasi properti kos yang akan ditambahkan"
                }
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name">Nama Properti *</Label>
                <Input
                  id="name"
                  placeholder="Contoh: Kos Melati Indah"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Deskripsi</Label>
                <Textarea
                  id="description"
                  placeholder="Deskripsikan properti kos Anda..."
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="city">Kota *</Label>
                  <Input
                    id="city"
                    placeholder="Contoh: Jakarta"
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="type">Tipe *</Label>
                  <Select value={formData.type} onValueChange={(value) => setFormData({ ...formData, type: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih tipe" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="putra">Putra</SelectItem>
                      <SelectItem value="putri">Putri</SelectItem>
                      <SelectItem value="campur">Campur</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="address">Alamat Lengkap *</Label>
                <Textarea
                  id="address"
                  placeholder="Jl. Contoh No. 123, Kelurahan, Kecamatan"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  rows={2}
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="pricePerMonth">Harga/Bulan *</Label>
                  <Input
                    id="pricePerMonth"
                    type="number"
                    placeholder="1000000"
                    value={formData.pricePerMonth}
                    onChange={(e) => setFormData({ ...formData, pricePerMonth: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="availableRooms">Kamar Tersedia *</Label>
                  <Input
                    id="availableRooms"
                    type="number"
                    placeholder="5"
                    value={formData.availableRooms}
                    onChange={(e) => setFormData({ ...formData, availableRooms: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="totalRooms">Total Kamar *</Label>
                  <Input
                    id="totalRooms"
                    type="number"
                    placeholder="10"
                    value={formData.totalRooms}
                    onChange={(e) => setFormData({ ...formData, totalRooms: e.target.value })}
                  />
                </div>
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => { setShowAddDialog(false); setEditingProperty(null); }}>
                Batal
              </Button>
              <Button onClick={handleSubmit}>
                {editingProperty ? "Update Properti" : "Tambah Properti"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
