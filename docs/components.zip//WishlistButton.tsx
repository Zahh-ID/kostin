import { useState, useEffect } from "react";
import { Heart } from "lucide-react";
import { Button } from "./ui/button";
import { toast } from "sonner@2.0.3";
import { projectId } from "../utils/supabase/info";
import { createClient } from "../utils/supabase/client";

interface WishlistButtonProps {
  propertyId: string;
  size?: "sm" | "default" | "lg";
  variant?: "default" | "ghost" | "outline";
  className?: string;
}

export function WishlistButton({ propertyId, size = "default", variant = "ghost", className = "" }: WishlistButtonProps) {
  const [isInWishlist, setIsInWishlist] = useState(false);
  const [loading, setLoading] = useState(false);
  const supabase = createClient();

  useEffect(() => {
    checkWishlistStatus();
  }, [propertyId]);

  const checkWishlistStatus = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.access_token) return;

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-dbd6b95a/wishlist`,
        {
          headers: {
            Authorization: `Bearer ${session.access_token}`,
          },
        }
      );

      const data = await response.json();
      if (response.ok) {
        const inWishlist = data.wishlist.some((p: any) => p.id === propertyId);
        setIsInWishlist(inWishlist);
      }
    } catch (error) {
      console.error("Check wishlist error:", error);
    }
  };

  const toggleWishlist = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    setLoading(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session?.access_token) {
        toast.error("Silakan login terlebih dahulu");
        return;
      }

      const url = `https://${projectId}.supabase.co/functions/v1/make-server-dbd6b95a/wishlist/${propertyId}`;
      const method = isInWishlist ? "DELETE" : "POST";

      const response = await fetch(url, {
        method,
        headers: {
          Authorization: `Bearer ${session.access_token}`,
        },
      });

      const data = await response.json();

      if (response.ok) {
        setIsInWishlist(!isInWishlist);
        toast.success(isInWishlist ? "Dihapus dari wishlist" : "Ditambahkan ke wishlist");
      } else {
        throw new Error(data.error);
      }
    } catch (error: any) {
      console.error("Toggle wishlist error:", error);
      toast.error(error.message || "Gagal mengupdate wishlist");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Button
      variant={variant}
      size={size}
      onClick={toggleWishlist}
      disabled={loading}
      className={`${isInWishlist ? 'text-red-500' : 'text-gray-500'} hover:text-red-600 ${className}`}
    >
      <Heart className={`h-4 w-4 ${isInWishlist ? 'fill-current' : ''}`} />
    </Button>
  );
}
