import { useState } from "react";
import { 
  Search, 
  Filter, 
  Download, 
  Eye, 
  CheckCircle, 
  Clock, 
  XCircle,
  Calendar,
  ArrowLeft,
  TrendingUp,
  TrendingDown
} from "lucide-react";
import { Card, CardContent, CardHeader } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "./ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";

interface AdminInvoicesPageProps {
  onNavigate: (path: string) => void;
}

export function AdminInvoicesPage({ onNavigate }: AdminInvoicesPageProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedInvoice, setSelectedInvoice] = useState<any>(null);

  const invoices = [
    {
      id: "INV-2024-001",
      tenant: "Ahmad Fauzi",
      tenantEmail: "ahmad@email.com",
      owner: "Ibu Susi",
      ownerEmail: "susi@email.com",
      property: "Kos Melati Residence",
      room: "Kamar 101",
      month: "November 2024",
      issueDate: "2024-11-01",
      dueDate: "2024-11-05",
      amount: 1200000,
      status: "pending",
    },
    {
      id: "INV-2024-002",
      tenant: "Siti Nurhaliza",
      tenantEmail: "siti@email.com",
      owner: "Bapak Andi",
      ownerEmail: "andi@email.com",
      property: "Kos Mawar Indah",
      room: "Kamar 201",
      month: "November 2024",
      issueDate: "2024-11-01",
      dueDate: "2024-11-05",
      amount: 1500000,
      status: "pending",
    },
    {
      id: "INV-2024-003",
      tenant: "Budi Santoso",
      tenantEmail: "budi@email.com",
      owner: "Ibu Fatimah",
      ownerEmail: "fatimah@email.com",
      property: "Kos Anggrek Premium",
      room: "Kamar 301",
      month: "November 2024",
      issueDate: "2024-11-01",
      dueDate: "2024-11-03",
      amount: 1800000,
      status: "overdue",
    },
    {
      id: "INV-2024-004",
      tenant: "Ahmad Fauzi",
      tenantEmail: "ahmad@email.com",
      owner: "Ibu Susi",
      ownerEmail: "susi@email.com",
      property: "Kos Melati Residence",
      room: "Kamar 101",
      month: "Oktober 2024",
      issueDate: "2024-10-01",
      dueDate: "2024-10-05",
      paidDate: "2024-10-03",
      amount: 1200000,
      status: "paid",
      paymentMethod: "QRIS",
      platformFee: 12000,
    },
    {
      id: "INV-2024-005",
      tenant: "Siti Nurhaliza",
      tenantEmail: "siti@email.com",
      owner: "Bapak Andi",
      ownerEmail: "andi@email.com",
      property: "Kos Mawar Indah",
      room: "Kamar 201",
      month: "Oktober 2024",
      issueDate: "2024-10-01",
      dueDate: "2024-10-05",
      paidDate: "2024-10-04",
      amount: 1500000,
      status: "paid",
      paymentMethod: "Transfer Bank",
      platformFee: 15000,
    },
    {
      id: "INV-2024-006",
      tenant: "Rahmat Hidayat",
      tenantEmail: "rahmat@email.com",
      owner: "Ibu Susi",
      ownerEmail: "susi@email.com",
      property: "Kos Melati Residence",
      room: "Kamar 102",
      month: "Oktober 2024",
      issueDate: "2024-10-01",
      dueDate: "2024-10-05",
      paidDate: "2024-10-02",
      amount: 1200000,
      status: "paid",
      paymentMethod: "QRIS",
      platformFee: 12000,
    },
  ];

  const filteredInvoices = invoices.filter((invoice) => {
    const matchesSearch = 
      invoice.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      invoice.tenant.toLowerCase().includes(searchTerm.toLowerCase()) ||
      invoice.owner.toLowerCase().includes(searchTerm.toLowerCase()) ||
      invoice.property.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "all" || invoice.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "paid":
        return <Badge className="bg-green-500"><CheckCircle className="h-3 w-3 mr-1" />Lunas</Badge>;
      case "pending":
        return <Badge className="bg-orange-500"><Clock className="h-3 w-3 mr-1" />Menunggu</Badge>;
      case "overdue":
        return <Badge className="bg-red-500"><XCircle className="h-3 w-3 mr-1" />Terlambat</Badge>;
      default:
        return null;
    }
  };

  const totalRevenue = invoices.filter(inv => inv.status === "paid").reduce((sum, inv) => sum + inv.amount, 0);
  const totalPlatformFee = invoices.filter(inv => inv.status === "paid").reduce((sum, inv) => sum + (inv.platformFee || 0), 0);
  const totalPending = invoices.filter(inv => inv.status === "pending").reduce((sum, inv) => sum + inv.amount, 0);

  const stats = [
    {
      label: "Total Transaksi",
      value: `Rp ${totalRevenue.toLocaleString('id-ID')}`,
      color: "text-green-600",
      bgColor: "bg-green-50",
      icon: TrendingUp,
      change: "+12% dari bulan lalu",
    },
    {
      label: "Pendapatan Platform",
      value: `Rp ${totalPlatformFee.toLocaleString('id-ID')}`,
      color: "text-blue-600",
      bgColor: "bg-blue-50",
      icon: TrendingUp,
      change: "1% dari total transaksi",
    },
    {
      label: "Menunggu Pembayaran",
      value: `Rp ${totalPending.toLocaleString('id-ID')}`,
      color: "text-orange-600",
      bgColor: "bg-orange-50",
      icon: Clock,
      change: `${invoices.filter(inv => inv.status === "pending").length} tagihan`,
    },
    {
      label: "Terlambat",
      value: invoices.filter(inv => inv.status === "overdue").length,
      color: "text-red-600",
      bgColor: "bg-red-50",
      icon: XCircle,
      change: "Perlu tindak lanjut",
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => onNavigate('/admin/dashboard')}
            className="mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Kembali ke Dashboard
          </Button>
          <div>
            <h1>Semua Tagihan</h1>
            <p className="text-gray-600">Monitor semua transaksi pembayaran di platform</p>
          </div>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          {stats.map((stat) => (
            <Card key={stat.label}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className={`w-12 h-12 ${stat.bgColor} rounded-lg flex items-center justify-center`}>
                    <stat.icon className={`h-6 w-6 ${stat.color}`} />
                  </div>
                </div>
                <p className="text-sm text-gray-600 mb-1">{stat.label}</p>
                <p className={`text-2xl mb-2 ${stat.color}`}>{stat.value}</p>
                <p className="text-xs text-gray-500">{stat.change}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Cari invoice, penyewa, pemilik, atau properti..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full md:w-[200px]">
                  <Filter className="h-4 w-4 mr-2" />
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Semua Status</SelectItem>
                  <SelectItem value="pending">Menunggu</SelectItem>
                  <SelectItem value="paid">Lunas</SelectItem>
                  <SelectItem value="overdue">Terlambat</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Export Laporan
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Invoices Table */}
        <Card>
          <CardHeader>
            <h2>Daftar Semua Tagihan</h2>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>No. Invoice</TableHead>
                  <TableHead>Penyewa</TableHead>
                  <TableHead>Pemilik</TableHead>
                  <TableHead>Properti</TableHead>
                  <TableHead>Periode</TableHead>
                  <TableHead>Jatuh Tempo</TableHead>
                  <TableHead>Jumlah</TableHead>
                  <TableHead>Fee Platform</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Aksi</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredInvoices.map((invoice) => (
                  <TableRow key={invoice.id}>
                    <TableCell>
                      <div>
                        <p>{invoice.id}</p>
                        <p className="text-sm text-gray-500">
                          {new Date(invoice.issueDate).toLocaleDateString('id-ID')}
                        </p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <p>{invoice.tenant}</p>
                        <p className="text-sm text-gray-500">{invoice.tenantEmail}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <p>{invoice.owner}</p>
                        <p className="text-sm text-gray-500">{invoice.ownerEmail}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <p className="text-sm">{invoice.property}</p>
                        <p className="text-sm text-gray-500">{invoice.room}</p>
                      </div>
                    </TableCell>
                    <TableCell>{invoice.month}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-gray-400" />
                        <span className="text-sm">
                          {new Date(invoice.dueDate).toLocaleDateString('id-ID')}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <p>Rp {invoice.amount.toLocaleString('id-ID')}</p>
                    </TableCell>
                    <TableCell>
                      {invoice.platformFee ? (
                        <p className="text-sm text-green-600">
                          Rp {invoice.platformFee.toLocaleString('id-ID')}
                        </p>
                      ) : (
                        <p className="text-sm text-gray-400">-</p>
                      )}
                    </TableCell>
                    <TableCell>{getStatusBadge(invoice.status)}</TableCell>
                    <TableCell>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setSelectedInvoice(invoice)}
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      {/* Invoice Detail Dialog */}
      <Dialog open={!!selectedInvoice} onOpenChange={() => setSelectedInvoice(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Detail Tagihan</DialogTitle>
          </DialogHeader>
          {selectedInvoice && (
            <div className="space-y-4">
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">No. Invoice</span>
                  <span>{selectedInvoice.id}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Penyewa</span>
                  <div className="text-right">
                    <p>{selectedInvoice.tenant}</p>
                    <p className="text-sm text-gray-500">{selectedInvoice.tenantEmail}</p>
                  </div>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Pemilik</span>
                  <div className="text-right">
                    <p>{selectedInvoice.owner}</p>
                    <p className="text-sm text-gray-500">{selectedInvoice.ownerEmail}</p>
                  </div>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Properti</span>
                  <div className="text-right">
                    <p>{selectedInvoice.property}</p>
                    <p className="text-sm text-gray-500">{selectedInvoice.room}</p>
                  </div>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Periode</span>
                  <span>{selectedInvoice.month}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Tanggal Terbit</span>
                  <span>{new Date(selectedInvoice.issueDate).toLocaleDateString('id-ID')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Jatuh Tempo</span>
                  <span>{new Date(selectedInvoice.dueDate).toLocaleDateString('id-ID')}</span>
                </div>
                {selectedInvoice.paidDate && (
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Tanggal Bayar</span>
                    <span>{new Date(selectedInvoice.paidDate).toLocaleDateString('id-ID')}</span>
                  </div>
                )}
                {selectedInvoice.paymentMethod && (
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Metode Pembayaran</span>
                    <span>{selectedInvoice.paymentMethod}</span>
                  </div>
                )}
              </div>

              <div className="border-t pt-4">
                <div className="flex justify-between mb-2">
                  <span className="text-sm text-gray-600">Biaya Sewa</span>
                  <span>Rp {selectedInvoice.amount.toLocaleString('id-ID')}</span>
                </div>
                {selectedInvoice.platformFee && (
                  <div className="flex justify-between mb-2">
                    <span className="text-sm text-green-600">Fee Platform (1%)</span>
                    <span className="text-green-600">
                      Rp {selectedInvoice.platformFee.toLocaleString('id-ID')}
                    </span>
                  </div>
                )}
                <div className="flex justify-between pt-2 border-t">
                  <span>Total Transaksi</span>
                  <span className="text-blue-600">
                    Rp {selectedInvoice.amount.toLocaleString('id-ID')}
                  </span>
                </div>
              </div>

              <div className="flex justify-between items-center pt-4 border-t">
                <span>Status</span>
                {getStatusBadge(selectedInvoice.status)}
              </div>

              <Button
                variant="outline"
                className="w-full"
                onClick={() => setSelectedInvoice(null)}
              >
                Tutup
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
