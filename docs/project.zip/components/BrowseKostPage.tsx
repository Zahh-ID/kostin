import { useState } from "react";
import { 
  Search, 
  MapPin, 
  Sliders, 
  SlidersHorizontal,
  Home,
  Wifi,
  Droplet,
  Zap,
  Car,
  Refrigerator,
  X,
  Star,
  ChevronDown,
} from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Card, CardContent, CardFooter, CardHeader } from "./ui/card";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "./ui/sheet";
import { Checkbox } from "./ui/checkbox";
import { Label } from "./ui/label";
import { Slider } from "./ui/slider";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";

interface BrowseKostPageProps {
  onNavigate: (path: string) => void;
}

const mockProperties = [
  {
    id: 1,
    name: "Kos Melati Residence",
    address: "Jl. Raya Dramaga, Bogor",
    city: "Bogor",
    district: "Dramaga",
    price: 1200000,
    image: "https://images.unsplash.com/photo-1623334663819-1bb79f9f03f8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBib2FyZGluZyUyMGhvdXNlfGVufDF8fHx8MTc2MTg5MjA4OXww&ixlib=rb-4.1.0&q=80&w=1080",
    facilities: ["AC", "Wi-Fi", "Kamar Mandi Dalam", "Parkir"],
    available: 5,
    rating: 4.5,
    type: "Campur",
    roomSize: 3,
  },
  {
    id: 2,
    name: "Kos Mawar Indah Putri",
    address: "Jl. Pajajaran, Bogor Tengah",
    city: "Bogor",
    district: "Bogor Tengah",
    price: 1500000,
    image: "https://images.unsplash.com/photo-1616418928117-4e6d19be2df1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3p5JTIwYmVkcm9vbSUyMGludGVyaW9yfGVufDF8fHx8MTc2MTgyNDY2Nnww&ixlib=rb-4.1.0&q=80&w=1080",
    facilities: ["AC", "Wi-Fi", "Laundry", "Parkir", "Dapur"],
    available: 3,
    rating: 4.8,
    type: "Putri",
    roomSize: 4,
  },
  {
    id: 3,
    name: "Kos Anggrek Premium",
    address: "Jl. Merdeka, Bogor Utara",
    city: "Bogor",
    district: "Bogor Utara",
    price: 1800000,
    image: "https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbWFsaXN0JTIwcm9vbXxlbnwxfHx8fDE3NjE4MTY4MTV8MA&ixlib=rb-4.1.0&q=80&w=1080",
    facilities: ["AC", "Wi-Fi", "Kamar Mandi Dalam", "Dapur", "Kulkas"],
    available: 2,
    rating: 4.9,
    type: "Campur",
    roomSize: 4,
  },
  {
    id: 4,
    name: "Kos Teratai Strategis Putra",
    address: "Jl. Sudirman, Bogor",
    city: "Bogor",
    district: "Bogor Tengah",
    price: 1000000,
    image: "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHVkZW50JTIwYXBhcnRtZW50fGVufDF8fHx8MTc2MTkwMjEzOXww&ixlib=rb-4.1.0&q=80&w=1080",
    facilities: ["Wi-Fi", "Kamar Mandi Luar", "Parkir"],
    available: 8,
    rating: 4.3,
    type: "Putra",
    roomSize: 3,
  },
  {
    id: 5,
    name: "Kos Kenanga Modern",
    address: "Jl. RE Martadinata, Bogor",
    city: "Bogor",
    district: "Bogor Barat",
    price: 1350000,
    image: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBob3VzZSUyMGV4dGVyaW9yfGVufDF8fHx8MTc2MTg5OTk5NHww&ixlib=rb-4.1.0&q=80&w=1080",
    facilities: ["AC", "Wi-Fi", "Kamar Mandi Dalam", "Laundry"],
    available: 4,
    rating: 4.6,
    type: "Campur",
    roomSize: 3,
  },
  {
    id: 6,
    name: "Kos Dahlia Executive",
    address: "Jl. Siliwangi, Bogor",
    city: "Bogor",
    district: "Bogor Timur",
    price: 2000000,
    image: "https://images.unsplash.com/photo-1736007917095-88dd6bc641e5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1cmJhbiUyMGFwYXJ0bWVudHxlbnwxfHx8fDE3NjE5MDIxNDB8MA&ixlib=rb-4.1.0&q=80&w=1080",
    facilities: ["AC", "Wi-Fi", "Kamar Mandi Dalam", "Dapur", "Kulkas", "Parkir"],
    available: 1,
    rating: 5.0,
    type: "Putri",
    roomSize: 5,
  },
];

export function BrowseKostPage({ onNavigate }: BrowseKostPageProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCity, setSelectedCity] = useState("");
  const [priceRange, setPriceRange] = useState([0, 5000000]);
  const [selectedType, setSelectedType] = useState<string[]>([]);
  const [selectedFacilities, setSelectedFacilities] = useState<string[]>([]);
  const [sortBy, setSortBy] = useState("relevant");
  const [showFilters, setShowFilters] = useState(false);

  const facilities = [
    { id: "ac", label: "AC", icon: Zap },
    { id: "wifi", label: "Wi-Fi", icon: Wifi },
    { id: "bathroom", label: "Kamar Mandi Dalam", icon: Droplet },
    { id: "parking", label: "Parkir", icon: Car },
    { id: "kitchen", label: "Dapur", icon: Home },
    { id: "fridge", label: "Kulkas", icon: Refrigerator },
  ];

  const types = ["Putra", "Putri", "Campur"];

  const handleFacilityToggle = (facilityId: string) => {
    setSelectedFacilities((prev) =>
      prev.includes(facilityId)
        ? prev.filter((f) => f !== facilityId)
        : [...prev, facilityId]
    );
  };

  const handleTypeToggle = (type: string) => {
    setSelectedType((prev) =>
      prev.includes(type) ? prev.filter((t) => t !== type) : [...prev, type]
    );
  };

  const clearFilters = () => {
    setSearchQuery("");
    setSelectedCity("");
    setPriceRange([0, 5000000]);
    setSelectedType([]);
    setSelectedFacilities([]);
    setSortBy("relevant");
  };

  const filteredProperties = mockProperties.filter((property) => {
    // Search filter
    if (searchQuery && !property.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
        !property.address.toLowerCase().includes(searchQuery.toLowerCase()) &&
        !property.district.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }

    // City filter
    if (selectedCity && property.city !== selectedCity) {
      return false;
    }

    // Price filter
    if (property.price < priceRange[0] || property.price > priceRange[1]) {
      return false;
    }

    // Type filter
    if (selectedType.length > 0 && !selectedType.includes(property.type)) {
      return false;
    }

    return true;
  });

  const sortedProperties = [...filteredProperties].sort((a, b) => {
    switch (sortBy) {
      case "price-low":
        return a.price - b.price;
      case "price-high":
        return b.price - a.price;
      case "rating":
        return b.rating - a.rating;
      case "available":
        return b.available - a.available;
      default:
        return 0;
    }
  });

  const activeFiltersCount =
    (searchQuery ? 1 : 0) +
    (selectedCity ? 1 : 0) +
    (priceRange[0] !== 0 || priceRange[1] !== 5000000 ? 1 : 0) +
    selectedType.length +
    selectedFacilities.length;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header Section */}
      <div className="bg-white border-b sticky top-16 z-40">
        <div className="container mx-auto px-4 py-6">
          <div className="mb-6">
            <h1 className="mb-2">Cari Kos</h1>
            <p className="text-gray-600">
              Temukan kos yang sesuai dengan kebutuhan Anda
            </p>
          </div>

          {/* Search Bar */}
          <div className="grid md:grid-cols-12 gap-4 mb-4">
            <div className="md:col-span-5">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <Input
                  placeholder="Cari nama kos atau lokasi..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="md:col-span-4">
              <Select value={selectedCity} onValueChange={setSelectedCity}>
                <SelectTrigger>
                  <SelectValue placeholder="Pilih Kota" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Semua Kota</SelectItem>
                  <SelectItem value="Bogor">Bogor</SelectItem>
                  <SelectItem value="Jakarta">Jakarta</SelectItem>
                  <SelectItem value="Depok">Depok</SelectItem>
                  <SelectItem value="Bandung">Bandung</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="md:col-span-3">
              <Sheet open={showFilters} onOpenChange={setShowFilters}>
                <SheetTrigger className="w-full">
                  <Button variant="outline" className="w-full">
                    <SlidersHorizontal className="h-4 w-4 mr-2" />
                    Filter
                    {activeFiltersCount > 0 && (
                      <Badge className="ml-2 bg-blue-600">{activeFiltersCount}</Badge>
                    )}
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="w-full sm:max-w-md overflow-y-auto">
                  <SheetHeader>
                    <SheetTitle>Filter Pencarian</SheetTitle>
                    <SheetDescription>
                      Sesuaikan pencarian dengan kebutuhan Anda
                    </SheetDescription>
                  </SheetHeader>

                  <div className="space-y-6 py-6">
                    {/* Price Range */}
                    <div>
                      <Label className="mb-3 block">Range Harga</Label>
                      <div className="space-y-4">
                        <Slider
                          value={priceRange}
                          onValueChange={setPriceRange}
                          max={5000000}
                          step={100000}
                          className="mt-2"
                        />
                        <div className="flex items-center justify-between text-sm text-gray-600">
                          <span>Rp {priceRange[0].toLocaleString('id-ID')}</span>
                          <span>Rp {priceRange[1].toLocaleString('id-ID')}</span>
                        </div>
                      </div>
                    </div>

                    {/* Type Filter */}
                    <div>
                      <Label className="mb-3 block">Tipe Kos</Label>
                      <div className="space-y-2">
                        {types.map((type) => (
                          <div key={type} className="flex items-center space-x-2">
                            <Checkbox
                              id={type}
                              checked={selectedType.includes(type)}
                              onCheckedChange={() => handleTypeToggle(type)}
                            />
                            <Label htmlFor={type} className="cursor-pointer">
                              {type}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Facilities Filter */}
                    <div>
                      <Label className="mb-3 block">Fasilitas</Label>
                      <div className="space-y-2">
                        {facilities.map((facility) => (
                          <div key={facility.id} className="flex items-center space-x-2">
                            <Checkbox
                              id={facility.id}
                              checked={selectedFacilities.includes(facility.id)}
                              onCheckedChange={() => handleFacilityToggle(facility.id)}
                            />
                            <Label htmlFor={facility.id} className="cursor-pointer flex items-center">
                              <facility.icon className="h-4 w-4 mr-2 text-gray-500" />
                              {facility.label}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Clear Filters */}
                    <div className="pt-4 border-t">
                      <Button
                        variant="outline"
                        className="w-full"
                        onClick={clearFilters}
                      >
                        <X className="h-4 w-4 mr-2" />
                        Hapus Semua Filter
                      </Button>
                    </div>
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>

          {/* Active Filters & Sort */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 flex-wrap">
              {searchQuery && (
                <Badge variant="secondary" className="gap-1">
                  Pencarian: {searchQuery}
                  <X
                    className="h-3 w-3 cursor-pointer"
                    onClick={() => setSearchQuery("")}
                  />
                </Badge>
              )}
              {selectedCity && (
                <Badge variant="secondary" className="gap-1">
                  {selectedCity}
                  <X
                    className="h-3 w-3 cursor-pointer"
                    onClick={() => setSelectedCity("")}
                  />
                </Badge>
              )}
              {selectedType.map((type) => (
                <Badge key={type} variant="secondary" className="gap-1">
                  {type}
                  <X
                    className="h-3 w-3 cursor-pointer"
                    onClick={() => handleTypeToggle(type)}
                  />
                </Badge>
              ))}
            </div>

            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-600 hidden sm:inline">Urutkan:</span>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="relevant">Paling Relevan</SelectItem>
                  <SelectItem value="price-low">Harga Terendah</SelectItem>
                  <SelectItem value="price-high">Harga Tertinggi</SelectItem>
                  <SelectItem value="rating">Rating Tertinggi</SelectItem>
                  <SelectItem value="available">Paling Banyak Tersedia</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </div>

      {/* Results */}
      <div className="container mx-auto px-4 py-8">
        <div className="mb-6 flex items-center justify-between">
          <p className="text-gray-600">
            Menampilkan <span className="font-semibold">{sortedProperties.length}</span> kos
          </p>
          {activeFiltersCount > 0 && (
            <Button variant="ghost" size="sm" onClick={clearFilters}>
              <X className="h-4 w-4 mr-2" />
              Hapus Filter ({activeFiltersCount})
            </Button>
          )}
        </div>

        {sortedProperties.length === 0 ? (
          <div className="bg-white rounded-lg shadow p-12 text-center">
            <Home className="h-16 w-16 text-gray-300 mx-auto mb-4" />
            <h3 className="mb-2">Tidak ada kos yang sesuai</h3>
            <p className="text-gray-600 mb-4">
              Coba ubah filter pencarian Anda untuk hasil yang lebih luas
            </p>
            <Button onClick={clearFilters}>
              Hapus Semua Filter
            </Button>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {sortedProperties.map((property) => (
              <Card
                key={property.id}
                className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer group"
                onClick={() => onNavigate(`/property/${property.id}`)}
              >
                <div className="relative h-56 overflow-hidden">
                  <ImageWithFallback
                    src={property.image}
                    alt={property.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  {property.available > 0 && (
                    <Badge className="absolute top-3 right-3 bg-green-500">
                      {property.available} tersedia
                    </Badge>
                  )}
                  <div className="absolute top-3 left-3">
                    <Badge variant="secondary" className="bg-white/90 backdrop-blur">
                      {property.type}
                    </Badge>
                  </div>
                </div>

                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="line-clamp-1 m-0">{property.name}</h3>
                    <div className="flex items-center gap-1 text-yellow-500 shrink-0">
                      <Star className="h-4 w-4 fill-current" />
                      <span className="text-sm">{property.rating}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-gray-600 text-sm mt-1">
                    <MapPin className="h-4 w-4 shrink-0" />
                    <span className="line-clamp-1">{property.address}</span>
                  </div>
                </CardHeader>

                <CardContent className="space-y-3">
                  <div className="flex flex-wrap gap-1">
                    {property.facilities.slice(0, 4).map((facility) => (
                      <Badge key={facility} variant="secondary" className="text-xs">
                        {facility}
                      </Badge>
                    ))}
                    {property.facilities.length > 4 && (
                      <Badge variant="secondary" className="text-xs">
                        +{property.facilities.length - 4}
                      </Badge>
                    )}
                  </div>

                  <div className="flex items-baseline gap-2">
                    <span className="text-blue-600">
                      Rp {property.price.toLocaleString('id-ID')}
                    </span>
                    <span className="text-sm text-gray-500">/ bulan</span>
                  </div>
                </CardContent>

                <CardFooter>
                  <Button className="w-full" variant="outline">
                    Lihat Detail
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
