import { AlertCircle } from "lucide-react";
import { Alert, AlertDescription } from "./ui/alert";

export function GoogleOAuthInfo() {
  return (
    <Alert className="mb-6 border-blue-200 bg-blue-50">
      <AlertCircle className="h-4 w-4 text-blue-600" />
      <AlertDescription className="text-sm">
        <strong>Catatan:</strong> Untuk menggunakan Google OAuth, pastikan Anda telah mengonfigurasi Google sebagai provider di{' '}
        <a
          href="https://supabase.com/docs/guides/auth/social-login/auth-google"
          target="_blank"
          rel="noopener noreferrer"
          className="text-blue-600 hover:underline"
        >
          Supabase Dashboard
        </a>
        . Ikuti panduan lengkap di dokumentasi Supabase.
      </AlertDescription>
    </Alert>
  );
}
