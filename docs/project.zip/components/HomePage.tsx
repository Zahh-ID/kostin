import { Search, MapPin, Sliders, ChevronRight } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Card, CardContent, CardFooter, CardHeader } from "./ui/card";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface HomePageProps {
  onNavigate: (path: string) => void;
}

const mockProperties = [
  {
    id: 1,
    name: "Kos Melati Residence",
    address: "Jl. Raya Dramaga, Bogor",
    price: 1200000,
    image: "https://images.unsplash.com/photo-1623334663819-1bb79f9f03f8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBib2FyZGluZyUyMGhvdXNlfGVufDF8fHx8MTc2MTg5MjA4OXww&ixlib=rb-4.1.0&q=80&w=1080",
    facilities: ["AC", "Wi-Fi", "Kamar Mandi Dalam"],
    available: 5,
  },
  {
    id: 2,
    name: "Kos Mawar Indah",
    address: "Jl. Pajajaran, Bogor Tengah",
    price: 1500000,
    image: "https://images.unsplash.com/photo-1605191353027-d21e534a419a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3p5JTIwcm9vbSUyMGludGVyaW9yfGVufDF8fHx8MTc2MTg5MjA5MHww&ixlib=rb-4.1.0&q=80&w=1080",
    facilities: ["AC", "Wi-Fi", "Laundry", "Parkir"],
    available: 3,
  },
  {
    id: 3,
    name: "Kos Anggrek Premium",
    address: "Jl. Merdeka, Bogor Utara",
    price: 1800000,
    image: "https://images.unsplash.com/photo-1617325247661-675ab4b64ae2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbWFsaXN0JTIwYmVkcm9vbXxlbnwxfHx8fDE3NjE4NTU3Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080",
    facilities: ["AC", "Wi-Fi", "Kamar Mandi Dalam", "Dapur"],
    available: 2,
  },
  {
    id: 4,
    name: "Kos Teratai Strategis",
    address: "Jl. Sudirman, Bogor",
    price: 1000000,
    image: "https://images.unsplash.com/photo-1623334663819-1bb79f9f03f8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBib2FyZGluZyUyMGhvdXNlfGVufDF8fHx8MTc2MTg5MjA4OXww&ixlib=rb-4.1.0&q=80&w=1080",
    facilities: ["Wi-Fi", "Kamar Mandi Luar", "Parkir"],
    available: 8,
  },
];

export function HomePage({ onNavigate }: HomePageProps) {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center mb-8">
            <h1 className="mb-4">Temukan Kos Impian Anda</h1>
            <p className="text-blue-100 mb-8">
              Ribuan pilihan kos-kosan berkualitas dengan sistem pembayaran mudah dan aman
            </p>
          </div>
          
          {/* Search Bar */}
          <div className="max-w-4xl mx-auto">
            <Card className="border-0 shadow-xl">
              <CardContent className="p-6">
                <div className="grid md:grid-cols-12 gap-4">
                  <div className="md:col-span-5">
                    <div className="relative">
                      <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                      <Input
                        placeholder="Cari lokasi (kota, kecamatan)..."
                        className="pl-10"
                      />
                    </div>
                  </div>
                  <div className="md:col-span-4">
                    <div className="relative">
                      <Input
                        type="number"
                        placeholder="Harga maksimal..."
                        className="pl-10"
                      />
                      <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">Rp</span>
                    </div>
                  </div>
                  <div className="md:col-span-3 flex gap-2">
                    <Button className="flex-1" onClick={() => onNavigate('/browse-kost')}>
                      <Search className="h-4 w-4 mr-2" />
                      Cari Kos
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Property Listings */}
      <div className="container mx-auto px-4 py-12">
        <div className="flex items-center justify-between mb-6">
          <h2>Kos Terbaru</h2>
          <Button variant="link" className="gap-1" onClick={() => onNavigate('/browse-kost')}>
            Lihat Semua
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {mockProperties.map((property) => (
            <Card
              key={property.id}
              className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer"
              onClick={() => onNavigate(`/property/${property.id}`)}
            >
              <div className="relative h-48 overflow-hidden">
                <ImageWithFallback
                  src={property.image}
                  alt={property.name}
                  className="w-full h-full object-cover"
                />
                {property.available > 0 && (
                  <Badge className="absolute top-3 right-3 bg-green-500">
                    {property.available} tersedia
                  </Badge>
                )}
              </div>
              <CardHeader>
                <h3 className="line-clamp-1">{property.name}</h3>
                <div className="flex items-center gap-2 text-gray-600 text-sm mt-1">
                  <MapPin className="h-4 w-4" />
                  <span className="line-clamp-1">{property.address}</span>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-1 mb-3">
                  {property.facilities.slice(0, 3).map((facility) => (
                    <Badge key={facility} variant="secondary" className="text-xs">
                      {facility}
                    </Badge>
                  ))}
                </div>
                <div className="text-blue-600">
                  Rp {property.price.toLocaleString('id-ID')} / bulan
                </div>
              </CardContent>
              <CardFooter>
                <Button className="w-full" variant="outline">
                  Lihat Detail
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>

      {/* Features Section */}
      <div className="bg-white py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-center mb-12">Mengapa KosKita?</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Search className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="mb-2">Pencarian Mudah</h3>
              <p className="text-gray-600">
                Filter lengkap berdasarkan lokasi, harga, dan fasilitas yang Anda butuhkan
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <MapPin className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="mb-2">Lokasi Strategis</h3>
              <p className="text-gray-600">
                Ratusan pilihan kos di lokasi strategis dekat kampus dan perkantoran
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Badge className="h-8 w-8 bg-blue-600" />
              </div>
              <h3 className="mb-2">Pembayaran Aman</h3>
              <p className="text-gray-600">
                Sistem pembayaran digital QRIS yang aman dan mudah digunakan
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
