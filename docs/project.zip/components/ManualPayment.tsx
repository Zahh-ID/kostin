import { useState } from "react";
import { Upload, FileText, CheckCircle, AlertCircle } from "lucide-react";
import { Button } from "./ui/button";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import { Card, CardContent } from "./ui/card";
import { projectId, publicAnonKey } from "../utils/supabase/info";

interface ManualPaymentProps {
  invoiceId: string;
  amount: number;
  description: string;
  onSuccess: () => void;
  onClose: () => void;
}

export function ManualPayment({
  invoiceId,
  amount,
  description,
  onSuccess,
  onClose,
}: ManualPaymentProps) {
  const [paymentMethod, setPaymentMethod] = useState("");
  const [proofFile, setProofFile] = useState<File | null>(null);
  const [notes, setNotes] = useState("");
  const [isUploading, setIsUploading] = useState(false);
  const [error, setError] = useState("");
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  const bankAccounts = [
    {
      method: "BCA",
      accountNumber: "1234567890",
      accountName: "PT Kos Kita Indonesia",
    },
    {
      method: "Mandiri",
      accountNumber: "0987654321",
      accountName: "PT Kos Kita Indonesia",
    },
    {
      method: "BNI",
      accountNumber: "5555666677",
      accountName: "PT Kos Kita Indonesia",
    },
  ];

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Validate file type
      if (!file.type.startsWith("image/")) {
        setError("Hanya file gambar yang diperbolehkan");
        return;
      }

      // Validate file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        setError("Ukuran file maksimal 5MB");
        return;
      }

      setProofFile(file);
      setError("");

      // Create preview
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async () => {
    if (!paymentMethod) {
      setError("Pilih metode pembayaran");
      return;
    }

    if (!proofFile) {
      setError("Upload bukti pembayaran");
      return;
    }

    setIsUploading(true);
    setError("");

    try {
      // Get access token from localStorage
      const accessToken = localStorage.getItem("access_token");
      
      if (!accessToken) {
        throw new Error("Anda harus login terlebih dahulu");
      }

      // Convert file to base64
      const reader = new FileReader();
      reader.readAsDataURL(proofFile);
      
      reader.onloadend = async () => {
        const base64File = reader.result as string;

        const response = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-dbd6b95a/payment/manual`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${accessToken}`,
            },
            body: JSON.stringify({
              invoiceId,
              amount,
              description,
              paymentMethod,
              proofFile: base64File,
              fileName: proofFile.name,
              notes,
            }),
          }
        );

        const data = await response.json();

        if (!response.ok) {
          throw new Error(data.error || "Gagal mengirim bukti pembayaran");
        }

        alert("Bukti pembayaran berhasil dikirim! Menunggu verifikasi dari admin.");
        onSuccess();
      };

      reader.onerror = () => {
        throw new Error("Gagal membaca file");
      };
    } catch (error: any) {
      console.error("Manual payment error:", error);
      setError(error.message || "Gagal mengirim bukti pembayaran");
    } finally {
      setIsUploading(false);
    }
  };

  const selectedBank = bankAccounts.find((bank) => bank.method === paymentMethod);

  return (
    <div className="space-y-4">
      {/* Bank Selection */}
      <div className="space-y-2">
        <Label>Pilih Metode Pembayaran</Label>
        <Select value={paymentMethod} onValueChange={setPaymentMethod}>
          <SelectTrigger>
            <SelectValue placeholder="Pilih bank tujuan transfer" />
          </SelectTrigger>
          <SelectContent>
            {bankAccounts.map((bank) => (
              <SelectItem key={bank.method} value={bank.method}>
                {bank.method} - {bank.accountNumber}
              </SelectItem>
            ))}
            <SelectItem value="Cash">Bayar Tunai</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Bank Account Details */}
      {selectedBank && (
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="p-4 space-y-2">
            <div className="flex items-center gap-2 text-blue-700">
              <CheckCircle className="h-4 w-4" />
              <span className="font-medium">Detail Rekening Tujuan</span>
            </div>
            <div className="space-y-1 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Bank:</span>
                <span className="font-medium">{selectedBank.method}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">No. Rekening:</span>
                <span className="font-medium">{selectedBank.accountNumber}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Atas Nama:</span>
                <span className="font-medium">{selectedBank.accountName}</span>
              </div>
              <div className="flex justify-between pt-2 border-t">
                <span className="text-gray-600">Jumlah Transfer:</span>
                <span className="text-lg font-bold text-blue-700">
                  Rp {amount.toLocaleString("id-ID")}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {paymentMethod === "Cash" && (
        <Card className="bg-orange-50 border-orange-200">
          <CardContent className="p-4">
            <div className="flex items-start gap-2 text-orange-700">
              <AlertCircle className="h-4 w-4 mt-0.5" />
              <div className="text-sm">
                <p className="font-medium mb-1">Pembayaran Tunai</p>
                <p className="text-orange-600">
                  Silakan datang ke kantor manajemen kos untuk melakukan pembayaran tunai.
                  Jangan lupa untuk meminta dan upload foto bukti kwitansi pembayaran.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Upload Proof */}
      <div className="space-y-2">
        <Label>Upload Bukti Pembayaran</Label>
        <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-400 transition-colors">
          <input
            type="file"
            id="proof-upload"
            accept="image/*"
            onChange={handleFileChange}
            className="hidden"
          />
          <label
            htmlFor="proof-upload"
            className="cursor-pointer flex flex-col items-center gap-2"
          >
            {previewUrl ? (
              <div className="space-y-2">
                <img
                  src={previewUrl}
                  alt="Preview"
                  className="max-w-full h-48 object-contain rounded"
                />
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <FileText className="h-4 w-4" />
                  <span>{proofFile?.name}</span>
                </div>
                <Button type="button" variant="outline" size="sm">
                  Ganti File
                </Button>
              </div>
            ) : (
              <>
                <Upload className="h-12 w-12 text-gray-400" />
                <div className="space-y-1">
                  <p className="text-sm">
                    <span className="text-blue-600 hover:underline">Klik untuk upload</span>
                  </p>
                  <p className="text-xs text-gray-500">PNG, JPG, JPEG (Max. 5MB)</p>
                </div>
              </>
            )}
          </label>
        </div>
      </div>

      {/* Notes */}
      <div className="space-y-2">
        <Label>Catatan (Opsional)</Label>
        <Textarea
          placeholder="Tambahkan catatan jika ada..."
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          rows={3}
        />
      </div>

      {/* Error Message */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-3 flex items-start gap-2 text-red-700">
          <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
          <p className="text-sm">{error}</p>
        </div>
      )}

      {/* Actions */}
      <div className="flex gap-3 pt-4">
        <Button
          variant="outline"
          className="flex-1"
          onClick={onClose}
          disabled={isUploading}
        >
          Batal
        </Button>
        <Button
          className="flex-1"
          onClick={handleSubmit}
          disabled={isUploading || !paymentMethod || !proofFile}
        >
          {isUploading ? "Mengirim..." : "Kirim Bukti Pembayaran"}
        </Button>
      </div>
    </div>
  );
}
