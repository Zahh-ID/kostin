import { useState, useEffect } from "react";
import {
  CheckCircle,
  XCircle,
  Eye,
  Clock,
  Calendar,
  User,
  DollarSign,
  FileText,
  AlertCircle,
} from "lucide-react";
import { Card, CardContent, CardHeader } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "./ui/dialog";
import { Textarea } from "./ui/textarea";
import { Label } from "./ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "./ui/table";
import { projectId } from "../utils/supabase/info";

interface ManualPaymentVerificationProps {
  onNavigate: (path: string) => void;
}

export function ManualPaymentVerification({ onNavigate }: ManualPaymentVerificationProps) {
  const [payments, setPayments] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedPayment, setSelectedPayment] = useState<any>(null);
  const [showVerifyDialog, setShowVerifyDialog] = useState(false);
  const [verifyAction, setVerifyAction] = useState<'approve' | 'reject'>('approve');
  const [rejectionReason, setRejectionReason] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    fetchPendingPayments();
  }, []);

  const fetchPendingPayments = async () => {
    try {
      const accessToken = localStorage.getItem("access_token");
      if (!accessToken) {
        onNavigate("/login");
        return;
      }

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-dbd6b95a/payment/manual/pending`,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Gagal memuat data pembayaran");
      }

      setPayments(data.payments || []);
    } catch (error: any) {
      console.error("Fetch pending payments error:", error);
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerify = async () => {
    if (verifyAction === 'reject' && !rejectionReason) {
      setError("Alasan penolakan harus diisi");
      return;
    }

    setIsProcessing(true);
    setError("");

    try {
      const accessToken = localStorage.getItem("access_token");
      if (!accessToken) {
        throw new Error("Anda harus login terlebih dahulu");
      }

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-dbd6b95a/payment/manual/verify`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${accessToken}`,
          },
          body: JSON.stringify({
            paymentId: selectedPayment.paymentId,
            action: verifyAction,
            rejectionReason: verifyAction === 'reject' ? rejectionReason : undefined,
          }),
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Gagal memverifikasi pembayaran");
      }

      alert(
        verifyAction === 'approve'
          ? "Pembayaran berhasil disetujui!"
          : "Pembayaran ditolak"
      );
      setShowVerifyDialog(false);
      setSelectedPayment(null);
      setRejectionReason("");
      fetchPendingPayments(); // Reload data
    } catch (error: any) {
      console.error("Verify payment error:", error);
      setError(error.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const openVerifyDialog = (payment: any, action: 'approve' | 'reject') => {
    setSelectedPayment(payment);
    setVerifyAction(action);
    setShowVerifyDialog(true);
    setError("");
    setRejectionReason("");
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Memuat data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1>Verifikasi Pembayaran Manual</h1>
          <p className="text-gray-600">Kelola dan verifikasi bukti pembayaran yang dikirim tenant</p>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-3 gap-4 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-orange-100 rounded-lg">
                  <Clock className="h-6 w-6 text-orange-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Menunggu Verifikasi</p>
                  <p className="text-2xl text-orange-600">{payments.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Payments Table */}
        <Card>
          <CardHeader>
            <h2>Daftar Pembayaran Manual</h2>
          </CardHeader>
          <CardContent>
            {payments.length === 0 ? (
              <div className="text-center py-12">
                <FileText className="h-12 w-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500">Tidak ada pembayaran yang menunggu verifikasi</p>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID Pembayaran</TableHead>
                    <TableHead>Invoice</TableHead>
                    <TableHead>Tenant</TableHead>
                    <TableHead>Metode</TableHead>
                    <TableHead>Jumlah</TableHead>
                    <TableHead>Tanggal</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Aksi</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {payments.map((payment) => (
                    <TableRow key={payment.paymentId}>
                      <TableCell>
                        <p className="text-sm">{payment.paymentId}</p>
                      </TableCell>
                      <TableCell>
                        <p className="text-sm">{payment.invoiceId}</p>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <User className="h-4 w-4 text-gray-400" />
                          <span className="text-sm">{payment.userName}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{payment.paymentMethod}</Badge>
                      </TableCell>
                      <TableCell>
                        <p>Rp {payment.amount.toLocaleString("id-ID")}</p>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <Calendar className="h-4 w-4" />
                          {new Date(payment.submittedAt).toLocaleDateString("id-ID")}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className="bg-orange-500">
                          <Clock className="h-3 w-3 mr-1" />
                          Menunggu
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setSelectedPayment(payment)}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Payment Detail Dialog */}
      <Dialog
        open={selectedPayment && !showVerifyDialog}
        onOpenChange={() => setSelectedPayment(null)}
      >
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Detail Pembayaran Manual</DialogTitle>
          </DialogHeader>
          {selectedPayment && (
            <div className="space-y-6">
              {/* Payment Info */}
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <div>
                    <p className="text-sm text-gray-600">ID Pembayaran</p>
                    <p className="font-medium">{selectedPayment.paymentId}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Invoice ID</p>
                    <p className="font-medium">{selectedPayment.invoiceId}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Nama Tenant</p>
                    <p className="font-medium">{selectedPayment.userName}</p>
                  </div>
                </div>
                <div className="space-y-3">
                  <div>
                    <p className="text-sm text-gray-600">Metode Pembayaran</p>
                    <p className="font-medium">{selectedPayment.paymentMethod}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Jumlah</p>
                    <p className="text-xl text-blue-600 font-bold">
                      Rp {selectedPayment.amount.toLocaleString("id-ID")}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Tanggal Pengajuan</p>
                    <p className="font-medium">
                      {new Date(selectedPayment.submittedAt).toLocaleString("id-ID")}
                    </p>
                  </div>
                </div>
              </div>

              {/* Description */}
              {selectedPayment.description && (
                <div>
                  <p className="text-sm text-gray-600 mb-1">Deskripsi</p>
                  <p>{selectedPayment.description}</p>
                </div>
              )}

              {/* Notes */}
              {selectedPayment.notes && (
                <div>
                  <p className="text-sm text-gray-600 mb-1">Catatan dari Tenant</p>
                  <p className="bg-gray-50 p-3 rounded">{selectedPayment.notes}</p>
                </div>
              )}

              {/* Proof Image */}
              <div>
                <p className="text-sm text-gray-600 mb-2">Bukti Pembayaran</p>
                <div className="border rounded-lg overflow-hidden">
                  <img
                    src={selectedPayment.proofFile}
                    alt="Bukti pembayaran"
                    className="w-full h-auto"
                  />
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-3 pt-4 border-t">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => setSelectedPayment(null)}
                >
                  Tutup
                </Button>
                <Button
                  variant="outline"
                  className="flex-1 text-red-600 hover:bg-red-50"
                  onClick={() => openVerifyDialog(selectedPayment, 'reject')}
                >
                  <XCircle className="h-4 w-4 mr-2" />
                  Tolak
                </Button>
                <Button
                  className="flex-1"
                  onClick={() => openVerifyDialog(selectedPayment, 'approve')}
                >
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Setujui
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Verify Dialog */}
      <Dialog open={showVerifyDialog} onOpenChange={setShowVerifyDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {verifyAction === 'approve' ? 'Setujui Pembayaran' : 'Tolak Pembayaran'}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {verifyAction === 'approve' ? (
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium text-green-900 mb-1">Konfirmasi Persetujuan</p>
                    <p className="text-sm text-green-700">
                      Apakah Anda yakin ingin menyetujui pembayaran ini? Invoice akan ditandai sebagai
                      lunas.
                    </p>
                  </div>
                </div>
              </div>
            ) : (
              <>
                <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <AlertCircle className="h-5 w-5 text-red-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium text-red-900 mb-1">Konfirmasi Penolakan</p>
                      <p className="text-sm text-red-700">
                        Pembayaran akan ditolak dan tenant akan menerima notifikasi.
                      </p>
                    </div>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="rejectionReason">Alasan Penolakan *</Label>
                  <Textarea
                    id="rejectionReason"
                    value={rejectionReason}
                    onChange={(e) => setRejectionReason(e.target.value)}
                    placeholder="Jelaskan alasan penolakan..."
                    rows={3}
                  />
                </div>
              </>
            )}

            {error && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-3 flex items-start gap-2 text-red-700">
                <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                <p className="text-sm">{error}</p>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowVerifyDialog(false)}
              disabled={isProcessing}
            >
              Batal
            </Button>
            <Button
              onClick={handleVerify}
              disabled={isProcessing || (verifyAction === 'reject' && !rejectionReason)}
              className={verifyAction === 'reject' ? 'bg-red-600 hover:bg-red-700' : ''}
            >
              {isProcessing
                ? 'Memproses...'
                : verifyAction === 'approve'
                ? 'Ya, Setujui'
                : 'Ya, Tolak'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
