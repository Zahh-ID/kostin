import { useState, useEffect } from "react";
import { Clock, ArrowRight, CheckSquare } from "lucide-react";
import { Card, CardContent, CardHeader } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { projectId } from "../utils/supabase/info";

interface PendingPaymentsCardProps {
  onNavigate: (path: string) => void;
}

export function PendingPaymentsCard({ onNavigate }: PendingPaymentsCardProps) {
  const [pendingCount, setPendingCount] = useState(0);
  const [recentPayments, setRecentPayments] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchPendingPayments();
  }, []);

  const fetchPendingPayments = async () => {
    try {
      const accessToken = localStorage.getItem("access_token");
      if (!accessToken) return;

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-dbd6b95a/payment/manual/pending`,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );

      if (response.ok) {
        const data = await response.json();
        const payments = data.payments || [];
        setPendingCount(payments.length);
        setRecentPayments(payments.slice(0, 3)); // Show only 3 most recent
      }
    } catch (error) {
      console.error("Error fetching pending payments:", error);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="animate-pulse space-y-3">
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
            <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-l-4 border-l-orange-500">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-orange-100 rounded-lg">
              <CheckSquare className="h-6 w-6 text-orange-600" />
            </div>
            <div>
              <h3>Verifikasi Pembayaran</h3>
              <p className="text-sm text-gray-600">Manual payment pending</p>
            </div>
          </div>
          {pendingCount > 0 && (
            <Badge className="bg-orange-500 text-lg px-3 py-1">
              {pendingCount}
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {pendingCount === 0 ? (
          <div className="text-center py-6">
            <CheckSquare className="h-12 w-12 text-gray-300 mx-auto mb-2" />
            <p className="text-gray-500 text-sm">
              Tidak ada pembayaran yang menunggu verifikasi
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Recent Payments List */}
            <div className="space-y-2">
              {recentPayments.map((payment) => (
                <div
                  key={payment.paymentId}
                  className="flex items-center justify-between p-3 bg-orange-50 rounded-lg hover:bg-orange-100 transition-colors"
                >
                  <div className="flex-1">
                    <p className="font-medium text-sm">{payment.userName}</p>
                    <p className="text-xs text-gray-600">{payment.invoiceId}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-sm">
                      Rp {payment.amount.toLocaleString("id-ID")}
                    </p>
                    <p className="text-xs text-gray-600">{payment.paymentMethod}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* View All Button */}
            <Button
              className="w-full"
              variant="outline"
              onClick={() => {
                // Determine the path based on user role
                const userRole = localStorage.getItem("user_role");
                const path = userRole === "admin" 
                  ? "/admin/manual-payments" 
                  : "/owner/manual-payments";
                onNavigate(path);
              }}
            >
              Lihat Semua Pembayaran
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>

            {/* Quick Stats */}
            <div className="pt-4 border-t flex items-center justify-between text-sm">
              <div className="flex items-center gap-2 text-gray-600">
                <Clock className="h-4 w-4" />
                <span>
                  {pendingCount} pembayaran menunggu
                </span>
              </div>
              <span className="text-orange-600 font-medium">
                Butuh tindakan
              </span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
