import { useState } from "react";
import { 
  User, 
  Building2, 
  Crown, 
  CheckCircle, 
  ArrowRight,
  Home,
  FileText,
  Settings,
  LogOut,
  Sparkles,
  Shield,
} from "lucide-react";
import { Card, CardContent, CardHeader } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Separator } from "./ui/separator";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "./ui/alert-dialog";
import { toast } from "sonner@2.0.3";
import { projectId } from "../utils/supabase/info";
import { createClient } from "../utils/supabase/client";

interface ProfileSidebarProps {
  profile: {
    id: string;
    email: string;
    name: string;
    role: string;
    phone?: string;
    address?: string;
  };
  onNavigate: (path: string) => void;
  onRoleUpdate?: () => void;
}

export function ProfileSidebar({ profile, onNavigate, onRoleUpdate }: ProfileSidebarProps) {
  const [showUpgradeDialog, setShowUpgradeDialog] = useState(false);
  const [upgrading, setUpgrading] = useState(false);
  const supabase = createClient();

  const getRoleBadge = () => {
    switch (profile.role) {
      case "owner":
        return (
          <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-300">
            <Crown className="h-3 w-3 mr-1" />
            Owner
          </Badge>
        );
      case "admin":
        return (
          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-300">
            <Shield className="h-3 w-3 mr-1" />
            Admin
          </Badge>
        );
      case "tenant":
        return (
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-300">
            <User className="h-3 w-3 mr-1" />
            Tenant
          </Badge>
        );
      default:
        return null;
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  const handleBecomeOwner = async () => {
    setUpgrading(true);
    
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session?.access_token) {
        throw new Error("Silakan login terlebih dahulu");
      }

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-dbd6b95a/auth/upgrade-to-owner`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${session.access_token}`,
          },
        }
      );

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || "Gagal upgrade ke Owner");
      }

      toast.success("Selamat! Anda sekarang terdaftar sebagai Owner");
      setShowUpgradeDialog(false);
      
      // Refresh profile and redirect to owner dashboard
      if (onRoleUpdate) {
        onRoleUpdate();
      }
      
      // Small delay to show success message
      setTimeout(() => {
        onNavigate("/owner");
      }, 1500);

    } catch (error: any) {
      console.error("Upgrade to owner error:", error);
      toast.error(error.message || "Gagal upgrade ke Owner");
    } finally {
      setUpgrading(false);
    }
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    toast.success("Berhasil logout");
    onNavigate("/login");
  };

  const getDashboardLink = () => {
    switch (profile.role) {
      case "owner":
        return "/owner";
      case "admin":
        return "/admin";
      case "tenant":
        return "/tenant";
      default:
        return "/";
    }
  };

  return (
    <>
      <Card className="sticky top-24">
        <CardHeader className="pb-4">
          <div className="flex flex-col items-center text-center space-y-4">
            {/* Avatar */}
            <Avatar className="h-24 w-24 border-4 border-gray-100">
              <AvatarImage src="" alt={profile.name} />
              <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-600 text-white text-xl">
                {getInitials(profile.name)}
              </AvatarFallback>
            </Avatar>

            {/* Name & Email */}
            <div className="space-y-1 w-full">
              <h3 className="text-lg m-0">{profile.name}</h3>
              <p className="text-sm text-gray-500 break-all">{profile.email}</p>
              <div className="flex justify-center pt-2">
                {getRoleBadge()}
              </div>
            </div>
          </div>
        </CardHeader>

        <CardContent className="space-y-4">
          {/* Become Owner CTA - Only show for tenants */}
          {profile.role === "tenant" && (
            <>
              <Card className="bg-gradient-to-br from-purple-50 to-blue-50 border-purple-200">
                <CardContent className="p-4 space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="bg-purple-100 rounded-full p-2">
                      <Crown className="h-5 w-5 text-purple-600" />
                    </div>
                    <div className="flex-1">
                      <h4 className="text-sm m-0 mb-1 text-purple-900">Punya Properti Kos?</h4>
                      <p className="text-xs text-purple-700 m-0">
                        Daftar sebagai Owner dan mulai kelola properti Anda
                      </p>
                    </div>
                  </div>
                  
                  <Button 
                    className="w-full bg-purple-600 hover:bg-purple-700 text-white"
                    onClick={() => setShowUpgradeDialog(true)}
                  >
                    <Sparkles className="h-4 w-4 mr-2" />
                    Daftar Sebagai Owner
                  </Button>

                  <div className="space-y-1.5 pt-2 border-t border-purple-200">
                    <div className="flex items-center gap-2 text-xs text-purple-700">
                      <CheckCircle className="h-3 w-3" />
                      <span>Kelola properti kos Anda</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-purple-700">
                      <CheckCircle className="h-3 w-3" />
                      <span>Terima pembayaran online</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-purple-700">
                      <CheckCircle className="h-3 w-3" />
                      <span>Monitor pendapatan real-time</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Separator />
            </>
          )}

          {/* Quick Links */}
          <div className="space-y-2">
            <h4 className="text-xs text-gray-500 uppercase tracking-wider mb-3">Quick Links</h4>
            
            <Button
              variant="ghost"
              className="w-full justify-start"
              onClick={() => onNavigate(getDashboardLink())}
            >
              <Home className="h-4 w-4 mr-3" />
              Dashboard
            </Button>

            {profile.role === "owner" && (
              <>
                <Button
                  variant="ghost"
                  className="w-full justify-start"
                  onClick={() => onNavigate("/owner/properties")}
                >
                  <Building2 className="h-4 w-4 mr-3" />
                  Properti Saya
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start"
                  onClick={() => onNavigate("/owner/invoices")}
                >
                  <FileText className="h-4 w-4 mr-3" />
                  Tagihan
                </Button>
              </>
            )}

            {profile.role === "tenant" && (
              <>
                <Button
                  variant="ghost"
                  className="w-full justify-start"
                  onClick={() => onNavigate("/tenant/invoices")}
                >
                  <FileText className="h-4 w-4 mr-3" />
                  Tagihan Saya
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start"
                  onClick={() => onNavigate("/tenant/contracts")}
                >
                  <FileText className="h-4 w-4 mr-3" />
                  Kontrak Saya
                </Button>
              </>
            )}

            <Button
              variant="ghost"
              className="w-full justify-start"
              onClick={() => onNavigate("/profile")}
            >
              <Settings className="h-4 w-4 mr-3" />
              Pengaturan
            </Button>
          </div>

          <Separator />

          {/* Sign Out */}
          <Button
            variant="ghost"
            className="w-full justify-start text-red-600 hover:text-red-700 hover:bg-red-50"
            onClick={handleSignOut}
          >
            <LogOut className="h-4 w-4 mr-3" />
            Keluar
          </Button>
        </CardContent>
      </Card>

      {/* Upgrade to Owner Dialog */}
      <AlertDialog open={showUpgradeDialog} onOpenChange={setShowUpgradeDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <div className="flex justify-center mb-4">
              <div className="bg-purple-100 rounded-full p-4">
                <Crown className="h-8 w-8 text-purple-600" />
              </div>
            </div>
            <AlertDialogTitle className="text-center">
              Daftar Sebagai Owner?
            </AlertDialogTitle>
            <AlertDialogDescription className="text-center">
              Dengan mendaftar sebagai Owner, Anda dapat:
            </AlertDialogDescription>
          </AlertDialogHeader>

          <div className="space-y-3 my-4">
            <div className="flex items-start gap-3 p-3 bg-purple-50 rounded-lg">
              <CheckCircle className="h-5 w-5 text-purple-600 mt-0.5" />
              <div>
                <p className="text-sm m-0">
                  <strong>Kelola Properti</strong>
                </p>
                <p className="text-xs text-gray-600 m-0">
                  Tambah dan kelola properti kos Anda dengan mudah
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3 bg-purple-50 rounded-lg">
              <CheckCircle className="h-5 w-5 text-purple-600 mt-0.5" />
              <div>
                <p className="text-sm m-0">
                  <strong>Terima Pembayaran</strong>
                </p>
                <p className="text-xs text-gray-600 m-0">
                  Pembayaran QRIS otomatis dari penyewa
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3 bg-purple-50 rounded-lg">
              <CheckCircle className="h-5 w-5 text-purple-600 mt-0.5" />
              <div>
                <p className="text-sm m-0">
                  <strong>Dashboard Analytics</strong>
                </p>
                <p className="text-xs text-gray-600 m-0">
                  Monitor okupansi dan pendapatan real-time
                </p>
              </div>
            </div>
          </div>

          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
            <p className="text-xs text-yellow-800 m-0">
              <strong>Catatan:</strong> Anda masih dapat menggunakan fitur tenant setelah upgrade ke owner.
            </p>
          </div>

          <AlertDialogFooter>
            <AlertDialogCancel disabled={upgrading}>
              Batal
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleBecomeOwner}
              disabled={upgrading}
              className="bg-purple-600 hover:bg-purple-700"
            >
              {upgrading ? (
                <>
                  <div className="h-4 w-4 mr-2 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Memproses...
                </>
              ) : (
                <>
                  <Crown className="h-4 w-4 mr-2" />
                  Ya, Daftar Sekarang
                </>
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
