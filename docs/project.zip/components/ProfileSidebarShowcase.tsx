import { useState } from "react";
import { ProfileSidebar } from "./ProfileSidebar";
import { ArrowLeft } from "lucide-react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader } from "./ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";

interface ProfileSidebarShowcaseProps {
  onNavigate: (path: string) => void;
}

export function ProfileSidebarShowcase({ onNavigate }: ProfileSidebarShowcaseProps) {
  const [selectedRole, setSelectedRole] = useState<"tenant" | "owner" | "admin">("tenant");

  const profiles = {
    tenant: {
      id: "demo-tenant-id",
      email: "tenant@demo.com",
      name: "John Tenant",
      role: "tenant",
      phone: "081234567890",
      address: "Jl. Merdeka No. 123, Jakarta",
    },
    owner: {
      id: "demo-owner-id",
      email: "owner@demo.com",
      name: "Sarah Owner",
      role: "owner",
      phone: "081234567891",
      address: "Jl. Sudirman No. 456, Jakarta",
    },
    admin: {
      id: "demo-admin-id",
      email: "admin@demo.com",
      name: "Admin System",
      role: "admin",
      phone: "081234567892",
      address: "Jl. Admin Office, Jakarta",
    },
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => onNavigate("/")}
            className="mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Kembali
          </Button>
          <h1>Profile Sidebar Showcase</h1>
          <p className="text-gray-600">
            Demo ProfileSidebar component dengan berbagai role dan fitur "Become an Owner"
          </p>
        </div>

        {/* Role Selector */}
        <Card className="mb-6">
          <CardHeader>
            <h3 className="m-0">Pilih Role untuk Preview</h3>
          </CardHeader>
          <CardContent>
            <Tabs value={selectedRole} onValueChange={(val) => setSelectedRole(val as any)}>
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="tenant">Tenant</TabsTrigger>
                <TabsTrigger value="owner">Owner</TabsTrigger>
                <TabsTrigger value="admin">Admin</TabsTrigger>
              </TabsList>
            </Tabs>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Sidebar Preview */}
          <div className="lg:col-span-1">
            <ProfileSidebar 
              profile={profiles[selectedRole]}
              onNavigate={onNavigate}
              onRoleUpdate={() => {
                console.log("Role updated!");
                alert("Role updated to Owner! (This is a demo)");
              }}
            />
          </div>

          {/* Info Panel */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <h3 className="m-0">ProfileSidebar Features</h3>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="text-sm m-0 mb-2">✨ Key Features:</h4>
                  <ul className="space-y-2 text-sm text-gray-600">
                    <li>• <strong>Profile Display:</strong> Avatar dengan initials, nama, email, dan role badge</li>
                    <li>• <strong>Become Owner CTA:</strong> Khusus untuk tenant, dengan dialog konfirmasi yang menarik</li>
                    <li>• <strong>Quick Links:</strong> Navigasi cepat ke dashboard, invoices, contracts, dll sesuai role</li>
                    <li>• <strong>Sign Out:</strong> Button logout dengan konfirmasi</li>
                    <li>• <strong>Responsive:</strong> Sticky positioning untuk desktop, mobile-friendly</li>
                  </ul>
                </div>

                <div className="pt-4 border-t">
                  <h4 className="text-sm m-0 mb-2">🎯 Tenant Role Features:</h4>
                  <ul className="space-y-2 text-sm text-gray-600">
                    <li>• Shows attractive "Become an Owner" CTA card</li>
                    <li>• Highlights benefits: Kelola properti, terima pembayaran, analytics</li>
                    <li>• Beautiful gradient background with purple theme</li>
                    <li>• Checkmark list of features included</li>
                  </ul>
                </div>

                <div className="pt-4 border-t">
                  <h4 className="text-sm m-0 mb-2">👑 Owner Role Features:</h4>
                  <ul className="space-y-2 text-sm text-gray-600">
                    <li>• Shows Crown badge for premium feel</li>
                    <li>• Quick links to "Properti Saya" and "Tagihan"</li>
                    <li>• No upgrade CTA (already an owner)</li>
                  </ul>
                </div>

                <div className="pt-4 border-t">
                  <h4 className="text-sm m-0 mb-2">🔧 Technical Details:</h4>
                  <ul className="space-y-2 text-sm text-gray-600">
                    <li>• Backend endpoint: <code className="bg-gray-100 px-2 py-1 rounded text-xs">/auth/upgrade-to-owner</code></li>
                    <li>• Updates user metadata in Supabase Auth</li>
                    <li>• Stores upgrade info in KV store for tracking</li>
                    <li>• Prevents admin from upgrading to owner</li>
                    <li>• Shows toast notifications for success/error</li>
                    <li>• Auto-redirects to owner dashboard after upgrade</li>
                  </ul>
                </div>

                <div className="pt-4 border-t">
                  <h4 className="text-sm m-0 mb-2">🎨 UI Components Used:</h4>
                  <ul className="space-y-2 text-sm text-gray-600">
                    <li>• Card, CardHeader, CardContent</li>
                    <li>• Avatar with fallback initials</li>
                    <li>• Badge with role-based colors</li>
                    <li>• AlertDialog for confirmation</li>
                    <li>• Button variants (ghost, default)</li>
                    <li>• Separator for visual sections</li>
                    <li>• Lucide icons (Crown, User, Building2, etc.)</li>
                  </ul>
                </div>

                <div className="pt-4 border-t bg-blue-50 p-4 rounded-lg">
                  <h4 className="text-sm m-0 mb-2 text-blue-900">💡 Usage Tip:</h4>
                  <p className="text-sm text-blue-800 m-0">
                    Switch between roles using the tabs above to see how the sidebar adapts. 
                    Notice how the "Become Owner" CTA only appears for tenants, and how 
                    quick links change based on the user's role!
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
