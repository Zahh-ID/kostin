import { MapPin, Wifi, Wind, Droplet, Car, Calendar, Check, X } from "lucide-react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader } from "./ui/card";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Separator } from "./ui/separator";

interface PropertyDetailProps {
  propertyId: string;
  onNavigate: (path: string) => void;
}

export function PropertyDetail({ propertyId, onNavigate }: PropertyDetailProps) {
  const property = {
    id: propertyId,
    name: "Kos Melati Residence",
    address: "Jl. Raya Dramaga No. 45, Bogor Barat, Kota Bogor, Jawa Barat",
    description: "Kos nyaman dan strategis dengan fasilitas lengkap. Dekat dengan kampus IPB dan akses mudah ke pusat kota. Lingkungan aman dan bersih.",
    images: [
      "https://images.unsplash.com/photo-1623334663819-1bb79f9f03f8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBib2FyZGluZyUyMGhvdXNlfGVufDF8fHx8MTc2MTg5MjA4OXww&ixlib=rb-4.1.0&q=80&w=1080",
      "https://images.unsplash.com/photo-1605191353027-d21e534a419a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3p5JTIwcm9vbSUyMGludGVyaW9yfGVufDF8fHx8MTc2MTg5MjA5MHww&ixlib=rb-4.1.0&q=80&w=1080",
      "https://images.unsplash.com/photo-1617325247661-675ab4b64ae2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbWFsaXN0JTIwYmVkcm9vbXxlbnwxfHx8fDE3NjE4NTU3Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080",
    ],
    facilities: [
      { icon: Wifi, label: "Wi-Fi", available: true },
      { icon: Wind, label: "AC", available: true },
      { icon: Droplet, label: "Kamar Mandi Dalam", available: true },
      { icon: Car, label: "Parkir Motor", available: true },
    ],
    rules: [
      "Dilarang membawa hewan peliharaan",
      "Tamu wajib lapor ke penjaga",
      "Jam malam pukul 22.00 WIB",
      "Dilarang merokok di dalam kamar",
    ],
    roomTypes: [
      {
        id: 1,
        name: "Single AC - Kamar Mandi Dalam",
        size: "3x4 m",
        price: 1200000,
        deposit: 1200000,
        available: 5,
        facilities: ["AC", "Kasur", "Lemari", "Meja Belajar", "Kamar Mandi Dalam"],
      },
      {
        id: 2,
        name: "Single AC - Kamar Mandi Luar",
        size: "3x3 m",
        price: 1000000,
        deposit: 1000000,
        available: 3,
        facilities: ["AC", "Kasur", "Lemari", "Meja Belajar"],
      },
      {
        id: 3,
        name: "Single Non-AC",
        size: "3x3 m",
        price: 800000,
        deposit: 800000,
        available: 0,
        facilities: ["Kasur", "Lemari", "Meja Belajar"],
      },
    ],
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <Button variant="ghost" onClick={() => onNavigate('/')} className="mb-4">
          ← Kembali ke Pencarian
        </Button>

        {/* Image Gallery */}
        <div className="grid md:grid-cols-3 gap-4 mb-8">
          <div className="md:col-span-2">
            <div className="aspect-video rounded-lg overflow-hidden">
              <ImageWithFallback
                src={property.images[0]}
                alt={property.name}
                className="w-full h-full object-cover"
              />
            </div>
          </div>
          <div className="grid grid-rows-2 gap-4">
            {property.images.slice(1, 3).map((image, index) => (
              <div key={index} className="aspect-video rounded-lg overflow-hidden">
                <ImageWithFallback
                  src={image}
                  alt={`${property.name} ${index + 2}`}
                  className="w-full h-full object-cover"
                />
              </div>
            ))}
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <h1>{property.name}</h1>
                <div className="flex items-center gap-2 text-gray-600">
                  <MapPin className="h-5 w-5" />
                  <span>{property.address}</span>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700">{property.description}</p>
              </CardContent>
            </Card>

            {/* Facilities */}
            <Card>
              <CardHeader>
                <h2>Fasilitas</h2>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {property.facilities.map((facility) => (
                    <div key={facility.label} className="flex items-center gap-2">
                      <div className="w-10 h-10 bg-blue-50 rounded-lg flex items-center justify-center">
                        <facility.icon className="h-5 w-5 text-blue-600" />
                      </div>
                      <span>{facility.label}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Rules */}
            <Card>
              <CardHeader>
                <h2>Peraturan</h2>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {property.rules.map((rule, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <X className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-700">{rule}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            {/* Room Types */}
            <Card>
              <CardHeader>
                <h2>Tipe Kamar & Harga</h2>
              </CardHeader>
              <CardContent className="space-y-4">
                {property.roomTypes.map((room) => (
                  <div key={room.id}>
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h3>{room.name}</h3>
                        <p className="text-gray-600 text-sm">Ukuran: {room.size}</p>
                        {room.available > 0 ? (
                          <Badge className="bg-green-500 mt-1">
                            {room.available} kamar tersedia
                          </Badge>
                        ) : (
                          <Badge variant="secondary" className="mt-1">
                            Penuh
                          </Badge>
                        )}
                      </div>
                      <div className="text-right">
                        <div className="text-blue-600">
                          Rp {room.price.toLocaleString('id-ID')}
                        </div>
                        <div className="text-gray-500 text-sm">
                          Deposit: Rp {room.deposit.toLocaleString('id-ID')}
                        </div>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {room.facilities.map((facility) => (
                        <Badge key={facility} variant="outline" className="text-xs">
                          <Check className="h-3 w-3 mr-1" />
                          {facility}
                        </Badge>
                      ))}
                    </div>
                    <Separator className="mt-4" />
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <Card className="sticky top-24">
              <CardHeader>
                <h3>Mulai dari</h3>
                <div className="text-blue-600 text-3xl">
                  Rp {property.roomTypes[0].price.toLocaleString('id-ID')}
                </div>
                <p className="text-gray-500">per bulan</p>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button className="w-full" size="lg" onClick={() => onNavigate(`/apply-rental/${propertyId}`)}>
                  <Calendar className="h-5 w-5 mr-2" />
                  Ajukan Sewa
                </Button>
                <Button variant="outline" className="w-full" size="lg">
                  Hubungi Pemilik
                </Button>
                <Separator />
                <div className="space-y-2 text-sm text-gray-600">
                  <div className="flex justify-between">
                    <span>Lama Sewa Minimum</span>
                    <span>1 bulan</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Pembayaran</span>
                    <span>Bulanan</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Deposit</span>
                    <span>1x sewa</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
