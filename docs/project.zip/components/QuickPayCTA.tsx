import { CreditCard, Zap } from "lucide-react";
import { Card, CardContent } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";

interface QuickPayCTAProps {
  amount: number;
  dueDate: string;
  invoiceMonth: string;
  onPayClick: () => void;
  daysUntilDue?: number;
}

export function QuickPayCTA({ amount, dueDate, invoiceMonth, onPayClick, daysUntilDue = 5 }: QuickPayCTAProps) {
  const isUrgent = daysUntilDue <= 3 && daysUntilDue >= 0;
  const isOverdue = daysUntilDue < 0;

  return (
    <Card className={`
      relative overflow-hidden border-2
      ${isOverdue ? 'border-red-500 bg-gradient-to-br from-red-50 to-red-100' : 
        isUrgent ? 'border-orange-500 bg-gradient-to-br from-orange-50 to-orange-100' : 
        'border-blue-500 bg-gradient-to-br from-blue-50 to-blue-100'}
    `}>
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: 'radial-gradient(circle, currentColor 1px, transparent 1px)',
          backgroundSize: '20px 20px'
        }} />
      </div>

      <CardContent className="relative p-6">
        <div className="flex items-start justify-between mb-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <CreditCard className={`h-5 w-5 ${
                isOverdue ? 'text-red-600' : isUrgent ? 'text-orange-600' : 'text-blue-600'
              }`} />
              <p className={`text-sm font-medium ${
                isOverdue ? 'text-red-700' : isUrgent ? 'text-orange-700' : 'text-blue-700'
              }`}>
                {isOverdue ? 'Tagihan Terlambat!' : isUrgent ? 'Segera Bayar!' : 'Tagihan Bulan Ini'}
              </p>
            </div>
            <p className="text-xs text-gray-600">{invoiceMonth}</p>
          </div>
          
          {isOverdue ? (
            <Badge className="bg-red-600 animate-pulse">
              <Zap className="h-3 w-3 mr-1" />
              Terlambat
            </Badge>
          ) : isUrgent ? (
            <Badge className="bg-orange-600 animate-pulse">
              <Zap className="h-3 w-3 mr-1" />
              Urgent
            </Badge>
          ) : (
            <Badge className="bg-blue-600">
              Pending
            </Badge>
          )}
        </div>

        <div className="mb-4">
          <p className="text-sm text-gray-600 mb-1">Total Tagihan</p>
          <p className={`text-3xl ${
            isOverdue ? 'text-red-700' : isUrgent ? 'text-orange-700' : 'text-blue-700'
          }`}>
            Rp {amount.toLocaleString('id-ID')}
          </p>
        </div>

        <div className={`
          p-3 rounded-lg mb-4
          ${isOverdue ? 'bg-red-100 border border-red-200' : 
            isUrgent ? 'bg-orange-100 border border-orange-200' : 
            'bg-blue-100 border border-blue-200'}
        `}>
          <p className="text-sm text-gray-700">
            <span className="font-medium">Jatuh Tempo:</span> {dueDate}
          </p>
          <p className={`text-xs mt-1 ${
            isOverdue ? 'text-red-700' : isUrgent ? 'text-orange-700' : 'text-blue-700'
          }`}>
            {isOverdue ? 
              `Terlambat ${Math.abs(daysUntilDue)} hari` : 
              isUrgent ?
              `${daysUntilDue} hari lagi` :
              `${daysUntilDue} hari lagi`
            }
          </p>
        </div>

        <Button 
          className={`
            w-full shadow-lg
            ${isOverdue ? 'bg-red-600 hover:bg-red-700' : 
              isUrgent ? 'bg-orange-600 hover:bg-orange-700' : 
              'bg-blue-600 hover:bg-blue-700'}
          `}
          onClick={onPayClick}
        >
          <CreditCard className="h-4 w-4 mr-2" />
          {isOverdue ? 'Bayar Sekarang!' : 'Bayar dengan Snap'}
        </Button>

        <div className="mt-4 flex items-center justify-center gap-2">
          <p className="text-xs text-gray-500">Pembayaran via:</p>
          <div className="flex gap-2">
            <span className="text-xs bg-white px-2 py-1 rounded border text-gray-700">QRIS</span>
            <span className="text-xs bg-white px-2 py-1 rounded border text-gray-700">GoPay</span>
            <span className="text-xs bg-white px-2 py-1 rounded border text-gray-700">ShopeePay</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
