import { Card, CardContent, CardHeader } from "./ui/card";
import { Alert, AlertDescription } from "./ui/alert";
import { AlertCircle, ExternalLink } from "lucide-react";

export function SetupInstructions() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-12">
        <Card className="max-w-3xl mx-auto">
          <CardHeader>
            <h1>Panduan Setup Google OAuth</h1>
            <p className="text-gray-600">
              Ikuti langkah-langkah berikut untuk mengaktifkan login dengan Google
            </p>
          </CardHeader>
          <CardContent className="space-y-6">
            <Alert className="border-blue-200 bg-blue-50">
              <AlertCircle className="h-4 w-4 text-blue-600" />
              <AlertDescription>
                <strong>Penting:</strong> Google OAuth memerlukan konfigurasi di Supabase Dashboard sebelum dapat digunakan.
              </AlertDescription>
            </Alert>

            <div className="space-y-4">
              <h3>Langkah 1: Buka Supabase Dashboard</h3>
              <p className="text-gray-600">
                Buka{' '}
                <a
                  href="https://supabase.com/dashboard"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-600 hover:underline inline-flex items-center gap-1"
                >
                  Supabase Dashboard
                  <ExternalLink className="h-3 w-3" />
                </a>
                {' '}dan login ke project Anda.
              </p>
            </div>

            <div className="space-y-4">
              <h3>Langkah 2: Konfigurasi Google Provider</h3>
              <ol className="list-decimal list-inside space-y-2 text-gray-600 ml-4">
                <li>Buka menu <strong>Authentication → Providers</strong></li>
                <li>Cari dan pilih <strong>Google</strong></li>
                <li>Aktifkan toggle <strong>Enable Sign in with Google</strong></li>
                <li>Masukkan <strong>Client ID</strong> dan <strong>Client Secret</strong> dari Google Cloud Console</li>
              </ol>
            </div>

            <div className="space-y-4">
              <h3>Langkah 3: Setup Google Cloud Console</h3>
              <p className="text-gray-600">
                Jika belum memiliki credentials, ikuti panduan lengkap di:
              </p>
              <a
                href="https://supabase.com/docs/guides/auth/social-login/auth-google"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-blue-600 hover:underline"
              >
                <ExternalLink className="h-4 w-4" />
                Dokumentasi Supabase - Google OAuth Setup
              </a>
            </div>

            <div className="space-y-4">
              <h3>Langkah 4: Authorized Redirect URIs</h3>
              <p className="text-gray-600">
                Pastikan Anda menambahkan URL callback berikut di Google Cloud Console:
              </p>
              <div className="bg-gray-100 p-4 rounded-lg">
                <code className="text-sm break-all">
                  https://fldiodzqqsxcgdltlskl.supabase.co/auth/v1/callback
                </code>
              </div>
            </div>

            <Alert className="border-green-200 bg-green-50">
              <AlertDescription>
                Setelah konfigurasi selesai, tombol "Masuk dengan Google" akan berfungsi dengan baik.
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
