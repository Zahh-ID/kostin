import { useState } from "react";
import { 
  ArrowLeft, 
  FileText, 
  Calendar, 
  Download,
  CheckCircle,
  Clock,
  AlertCircle,
  MapPin,
  DollarSign,
  User
} from "lucide-react";
import { Card, CardContent, CardHeader } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import { Separator } from "./ui/separator";

interface TenantContractsPageProps {
  onNavigate: (path: string) => void;
}

export function TenantContractsPage({ onNavigate }: TenantContractsPageProps) {
  const [selectedContract, setSelectedContract] = useState<any>(null);

  const contracts = [
    {
      id: "CTR-2024-001",
      property: "Kos Melati Residence",
      room: "Kamar 101",
      roomType: "Tipe A - Standard",
      address: "Jl. Melati No. 15, Dramaga, Bogor",
      owner: "Ibu Susi Rahayu",
      ownerPhone: "+62 812-3456-7890",
      startDate: "2024-01-01",
      endDate: "2024-12-31",
      monthlyRent: 1200000,
      deposit: 2400000,
      status: "active",
      daysRemaining: 61,
      facilities: [
        "AC",
        "Kasur",
        "Lemari",
        "Meja & Kursi",
        "Wi-Fi",
        "Kamar Mandi Dalam",
      ],
      rules: [
        "Dilarang membawa hewan peliharaan",
        "Tamu wajib lapor ke penjaga",
        "Jam malam pukul 22.00 WIB",
        "Dilarang merokok di dalam kamar",
      ],
      paymentDue: 5,
      signedDate: "2023-12-20",
    },
  ];

  const getStatusBadge = (status: string, daysRemaining?: number) => {
    if (status === "active") {
      if (daysRemaining && daysRemaining <= 30) {
        return (
          <Badge className="bg-orange-500">
            <Clock className="h-3 w-3 mr-1" />
            Akan Berakhir
          </Badge>
        );
      }
      return (
        <Badge className="bg-green-500">
          <CheckCircle className="h-3 w-3 mr-1" />
          Aktif
        </Badge>
      );
    } else if (status === "expired") {
      return (
        <Badge className="bg-red-500">
          <AlertCircle className="h-3 w-3 mr-1" />
          Berakhir
        </Badge>
      );
    } else if (status === "draft") {
      return (
        <Badge className="bg-gray-500">
          <FileText className="h-3 w-3 mr-1" />
          Draft
        </Badge>
      );
    }
    return null;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => onNavigate('/tenant/dashboard')}
            className="mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Kembali ke Dashboard
          </Button>
          <h1>Kontrak Sewa</h1>
          <p className="text-gray-600">Kelola kontrak sewa properti Anda</p>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-3 gap-4 mb-8">
          <Card>
            <CardContent className="p-6">
              <p className="text-sm text-gray-600 mb-1">Kontrak Aktif</p>
              <p className="text-2xl text-green-600">
                {contracts.filter(c => c.status === "active").length}
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <p className="text-sm text-gray-600 mb-1">Total Kontrak</p>
              <p className="text-2xl text-blue-600">{contracts.length}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <p className="text-sm text-gray-600 mb-1">Akan Berakhir</p>
              <p className="text-2xl text-orange-600">
                {contracts.filter(c => c.status === "active" && c.daysRemaining && c.daysRemaining <= 30).length}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Contracts List */}
        <div className="space-y-6">
          {contracts.map((contract) => (
            <Card key={contract.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h2>{contract.property}</h2>
                      {getStatusBadge(contract.status, contract.daysRemaining)}
                    </div>
                    <div className="flex items-center gap-4 text-sm text-gray-600">
                      <div className="flex items-center gap-1">
                        <MapPin className="h-4 w-4" />
                        {contract.room}
                      </div>
                      <div className="flex items-center gap-1">
                        <Calendar className="h-4 w-4" />
                        {new Date(contract.startDate).toLocaleDateString('id-ID')} - {new Date(contract.endDate).toLocaleDateString('id-ID')}
                      </div>
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    onClick={() => setSelectedContract(contract)}
                  >
                    <FileText className="h-4 w-4 mr-2" />
                    Lihat Detail
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-4 gap-6">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">No. Kontrak</p>
                    <p>{contract.id}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Biaya Bulanan</p>
                    <p className="text-blue-600">
                      Rp {contract.monthlyRent.toLocaleString('id-ID')}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Pemilik</p>
                    <p>{contract.owner}</p>
                  </div>
                  {contract.daysRemaining && contract.status === "active" && (
                    <div>
                      <p className="text-sm text-gray-600 mb-1">Sisa Waktu</p>
                      <p className={contract.daysRemaining <= 30 ? "text-orange-600" : ""}>
                        {contract.daysRemaining} hari
                      </p>
                    </div>
                  )}
                </div>

                {contract.daysRemaining && contract.daysRemaining <= 30 && contract.status === "active" && (
                  <div className="mt-4 p-4 bg-orange-50 border border-orange-200 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <AlertCircle className="h-5 w-5 text-orange-600" />
                      <p className="text-orange-800">
                        Kontrak akan berakhir dalam {contract.daysRemaining} hari
                      </p>
                    </div>
                    <p className="text-sm text-orange-700">
                      Hubungi pemilik untuk perpanjangan kontrak atau cari properti baru.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {contracts.length === 0 && (
          <Card>
            <CardContent className="p-12 text-center">
              <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600 mb-4">Anda belum memiliki kontrak aktif</p>
              <Button onClick={() => onNavigate('/')}>
                Cari Properti
              </Button>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Contract Detail Dialog */}
      <Dialog open={!!selectedContract} onOpenChange={() => setSelectedContract(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Detail Kontrak Sewa</DialogTitle>
          </DialogHeader>
          {selectedContract && (
            <div className="space-y-6">
              {/* Header */}
              <div className="flex items-start justify-between">
                <div>
                  <h2>{selectedContract.property}</h2>
                  <p className="text-gray-600">{selectedContract.address}</p>
                </div>
                {getStatusBadge(selectedContract.status, selectedContract.daysRemaining)}
              </div>

              <Separator />

              {/* Contract Info */}
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="mb-4">Informasi Kontrak</h3>
                  <div className="space-y-3">
                    <div>
                      <p className="text-sm text-gray-600">No. Kontrak</p>
                      <p>{selectedContract.id}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Tanggal Ditandatangani</p>
                      <p>{new Date(selectedContract.signedDate).toLocaleDateString('id-ID')}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Periode Kontrak</p>
                      <p>
                        {new Date(selectedContract.startDate).toLocaleDateString('id-ID')} - {new Date(selectedContract.endDate).toLocaleDateString('id-ID')}
                      </p>
                    </div>
                    {selectedContract.daysRemaining && (
                      <div>
                        <p className="text-sm text-gray-600">Sisa Waktu</p>
                        <p className={selectedContract.daysRemaining <= 30 ? "text-orange-600" : ""}>
                          {selectedContract.daysRemaining} hari
                        </p>
                      </div>
                    )}
                  </div>
                </div>

                <div>
                  <h3 className="mb-4">Informasi Properti</h3>
                  <div className="space-y-3">
                    <div>
                      <p className="text-sm text-gray-600">Kamar</p>
                      <p>{selectedContract.room}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Tipe Kamar</p>
                      <p>{selectedContract.roomType}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Pemilik</p>
                      <p>{selectedContract.owner}</p>
                      <p className="text-sm text-gray-500">{selectedContract.ownerPhone}</p>
                    </div>
                  </div>
                </div>
              </div>

              <Separator />

              {/* Financial */}
              <div>
                <h3 className="mb-4">Informasi Keuangan</h3>
                <div className="space-y-3">
                  <div className="flex justify-between p-3 bg-gray-50 rounded-lg">
                    <span className="text-gray-600">Biaya Sewa Bulanan</span>
                    <span className="text-blue-600">
                      Rp {selectedContract.monthlyRent.toLocaleString('id-ID')}
                    </span>
                  </div>
                  <div className="flex justify-between p-3 bg-gray-50 rounded-lg">
                    <span className="text-gray-600">Deposit</span>
                    <span>Rp {selectedContract.deposit.toLocaleString('id-ID')}</span>
                  </div>
                  <div className="flex justify-between p-3 bg-gray-50 rounded-lg">
                    <span className="text-gray-600">Tanggal Jatuh Tempo</span>
                    <span>Setiap tanggal {selectedContract.paymentDue}</span>
                  </div>
                </div>
              </div>

              <Separator />

              {/* Facilities */}
              <div>
                <h3 className="mb-4">Fasilitas Kamar</h3>
                <div className="grid grid-cols-2 gap-2">
                  {selectedContract.facilities.map((facility: string, index: number) => (
                    <div key={index} className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      <span className="text-sm">{facility}</span>
                    </div>
                  ))}
                </div>
              </div>

              <Separator />

              {/* Rules */}
              <div>
                <h3 className="mb-4">Peraturan</h3>
                <div className="space-y-2">
                  {selectedContract.rules.map((rule: string, index: number) => (
                    <div key={index} className="flex items-start gap-2">
                      <AlertCircle className="h-4 w-4 text-orange-600 mt-0.5 flex-shrink-0" />
                      <span className="text-sm">{rule}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-2 pt-4 border-t">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => {
                    // Download PDF logic
                    alert("Download kontrak PDF");
                  }}
                >
                  <Download className="h-4 w-4 mr-2" />
                  Download PDF
                </Button>
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => setSelectedContract(null)}
                >
                  Tutup
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
