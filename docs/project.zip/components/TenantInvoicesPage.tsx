import { useState } from "react";
import { 
  Search, 
  Filter, 
  Download, 
  Eye, 
  CheckCircle, 
  Clock, 
  XCircle,
  Calendar,
  CreditCard,
  ArrowLeft
} from "lucide-react";
import { Card, CardContent, CardHeader } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "./ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import { MidtransPayment } from "./MidtransPayment";
import { ManualPayment } from "./ManualPayment";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";

interface TenantInvoicesPageProps {
  onNavigate: (path: string) => void;
}

export function TenantInvoicesPage({ onNavigate }: TenantInvoicesPageProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedInvoice, setSelectedInvoice] = useState<any>(null);
  const [showPaymentDialog, setShowPaymentDialog] = useState(false);

  const invoices = [
    {
      id: "INV-2024-001",
      month: "November 2024",
      issueDate: "2024-11-01",
      dueDate: "2024-11-05",
      amount: 1200000,
      status: "pending",
      property: "Kos Melati Residence - Kamar 101",
      description: "Sewa bulan November 2024",
    },
    {
      id: "INV-2024-002",
      month: "Oktober 2024",
      issueDate: "2024-10-01",
      dueDate: "2024-10-05",
      paidDate: "2024-10-03",
      amount: 1200000,
      status: "paid",
      property: "Kos Melati Residence - Kamar 101",
      description: "Sewa bulan Oktober 2024",
      paymentMethod: "QRIS",
    },
    {
      id: "INV-2024-003",
      month: "September 2024",
      issueDate: "2024-09-01",
      dueDate: "2024-09-05",
      paidDate: "2024-09-02",
      amount: 1200000,
      status: "paid",
      property: "Kos Melati Residence - Kamar 101",
      description: "Sewa bulan September 2024",
      paymentMethod: "QRIS",
    },
    {
      id: "INV-2024-004",
      month: "Agustus 2024",
      issueDate: "2024-08-01",
      dueDate: "2024-08-05",
      paidDate: "2024-08-10",
      amount: 1200000,
      status: "paid",
      property: "Kos Melati Residence - Kamar 101",
      description: "Sewa bulan Agustus 2024",
      paymentMethod: "Transfer Bank",
      lateFee: 50000,
    },
  ];

  const filteredInvoices = invoices.filter((invoice) => {
    const matchesSearch = 
      invoice.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      invoice.month.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "all" || invoice.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "paid":
        return <Badge className="bg-green-500"><CheckCircle className="h-3 w-3 mr-1" />Lunas</Badge>;
      case "pending":
        return <Badge className="bg-orange-500"><Clock className="h-3 w-3 mr-1" />Menunggu</Badge>;
      case "overdue":
        return <Badge className="bg-red-500"><XCircle className="h-3 w-3 mr-1" />Terlambat</Badge>;
      default:
        return null;
    }
  };

  const handlePayNow = (invoice: any) => {
    setSelectedInvoice(invoice);
    setShowPaymentDialog(true);
  };

  const stats = [
    {
      label: "Total Tagihan",
      value: invoices.length,
      color: "text-blue-600",
      bgColor: "bg-blue-50",
    },
    {
      label: "Belum Dibayar",
      value: invoices.filter(inv => inv.status === "pending").length,
      color: "text-orange-600",
      bgColor: "bg-orange-50",
    },
    {
      label: "Sudah Dibayar",
      value: invoices.filter(inv => inv.status === "paid").length,
      color: "text-green-600",
      bgColor: "bg-green-50",
    },
    {
      label: "Total Dibayar",
      value: `Rp ${invoices.filter(inv => inv.status === "paid").reduce((sum, inv) => sum + inv.amount, 0).toLocaleString('id-ID')}`,
      color: "text-purple-600",
      bgColor: "bg-purple-50",
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => onNavigate('/tenant/dashboard')}
            className="mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Kembali ke Dashboard
          </Button>
          <h1>Daftar Tagihan</h1>
          <p className="text-gray-600">Kelola dan bayar tagihan sewa Anda</p>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          {stats.map((stat) => (
            <Card key={stat.label}>
              <CardContent className="p-6">
                <p className="text-sm text-gray-600 mb-1">{stat.label}</p>
                <p className={`text-2xl ${stat.color}`}>{stat.value}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Cari nomor invoice atau bulan..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full md:w-[200px]">
                  <Filter className="h-4 w-4 mr-2" />
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Semua Status</SelectItem>
                  <SelectItem value="pending">Menunggu</SelectItem>
                  <SelectItem value="paid">Lunas</SelectItem>
                  <SelectItem value="overdue">Terlambat</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Invoices Table */}
        <Card>
          <CardHeader>
            <h2>Riwayat Tagihan</h2>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>No. Invoice</TableHead>
                  <TableHead>Bulan</TableHead>
                  <TableHead>Properti</TableHead>
                  <TableHead>Tanggal Jatuh Tempo</TableHead>
                  <TableHead>Jumlah</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Aksi</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredInvoices.map((invoice) => (
                  <TableRow key={invoice.id}>
                    <TableCell>
                      <div>
                        <p>{invoice.id}</p>
                        <p className="text-sm text-gray-500">
                          {new Date(invoice.issueDate).toLocaleDateString('id-ID')}
                        </p>
                      </div>
                    </TableCell>
                    <TableCell>{invoice.month}</TableCell>
                    <TableCell>
                      <p className="text-sm">{invoice.property}</p>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-gray-400" />
                        {new Date(invoice.dueDate).toLocaleDateString('id-ID')}
                      </div>
                    </TableCell>
                    <TableCell>
                      <p>Rp {invoice.amount.toLocaleString('id-ID')}</p>
                      {invoice.lateFee && (
                        <p className="text-xs text-red-600">
                          +Rp {invoice.lateFee.toLocaleString('id-ID')} (denda)
                        </p>
                      )}
                    </TableCell>
                    <TableCell>{getStatusBadge(invoice.status)}</TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        {invoice.status === "pending" ? (
                          <Button
                            size="sm"
                            onClick={() => handlePayNow(invoice)}
                          >
                            <CreditCard className="h-4 w-4 mr-1" />
                            Bayar
                          </Button>
                        ) : (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setSelectedInvoice(invoice)}
                          >
                            <Eye className="h-4 w-4 mr-1" />
                            Detail
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      {/* Payment Dialog */}
      <Dialog open={showPaymentDialog} onOpenChange={setShowPaymentDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Pilih Metode Pembayaran</DialogTitle>
          </DialogHeader>
          {selectedInvoice && (
            <Tabs defaultValue="snap" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="snap">QRIS / E-Wallet</TabsTrigger>
                <TabsTrigger value="manual">Transfer Manual</TabsTrigger>
              </TabsList>
              
              <TabsContent value="snap" className="mt-4">
                <div className="space-y-4">
                  <p className="text-sm text-gray-600">
                    Bayar dengan QRIS, GoPay, ShopeePay, atau e-wallet lainnya
                  </p>
                  <MidtransPayment
                    invoiceId={selectedInvoice.id}
                    amount={selectedInvoice.amount + (selectedInvoice.lateFee || 0)}
                    description={`Pembayaran ${selectedInvoice.month} - ${selectedInvoice.property}`}
                    onSuccess={() => {
                      setShowPaymentDialog(false);
                      alert("Pembayaran berhasil! Tagihan akan diperbarui dalam beberapa saat.");
                    }}
                    onPending={() => {
                      setShowPaymentDialog(false);
                    }}
                    onError={(error) => {
                      console.error("Payment error:", error);
                    }}
                    onClose={() => {
                      setShowPaymentDialog(false);
                    }}
                  />
                </div>
              </TabsContent>
              
              <TabsContent value="manual" className="mt-4">
                <div className="space-y-4">
                  <p className="text-sm text-gray-600">
                    Transfer ke rekening bank atau bayar tunai, lalu upload bukti pembayaran
                  </p>
                  <ManualPayment
                    invoiceId={selectedInvoice.id}
                    amount={selectedInvoice.amount + (selectedInvoice.lateFee || 0)}
                    description={`Pembayaran ${selectedInvoice.month} - ${selectedInvoice.property}`}
                    onSuccess={() => {
                      setShowPaymentDialog(false);
                    }}
                    onClose={() => {
                      setShowPaymentDialog(false);
                    }}
                  />
                </div>
              </TabsContent>
            </Tabs>
          )}
        </DialogContent>
      </Dialog>

      {/* Invoice Detail Dialog */}
      <Dialog open={selectedInvoice && !showPaymentDialog} onOpenChange={() => setSelectedInvoice(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Detail Tagihan</DialogTitle>
          </DialogHeader>
          {selectedInvoice && (
            <div className="space-y-4">
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">No. Invoice</span>
                  <span>{selectedInvoice.id}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Periode</span>
                  <span>{selectedInvoice.month}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Properti</span>
                  <span className="text-sm text-right">{selectedInvoice.property}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Tanggal Terbit</span>
                  <span>{new Date(selectedInvoice.issueDate).toLocaleDateString('id-ID')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Jatuh Tempo</span>
                  <span>{new Date(selectedInvoice.dueDate).toLocaleDateString('id-ID')}</span>
                </div>
                {selectedInvoice.paidDate && (
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Tanggal Bayar</span>
                    <span>{new Date(selectedInvoice.paidDate).toLocaleDateString('id-ID')}</span>
                  </div>
                )}
                {selectedInvoice.paymentMethod && (
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Metode Pembayaran</span>
                    <span>{selectedInvoice.paymentMethod}</span>
                  </div>
                )}
              </div>

              <div className="border-t pt-4">
                <div className="flex justify-between mb-2">
                  <span className="text-sm text-gray-600">Biaya Sewa</span>
                  <span>Rp {selectedInvoice.amount.toLocaleString('id-ID')}</span>
                </div>
                {selectedInvoice.lateFee && (
                  <div className="flex justify-between mb-2">
                    <span className="text-sm text-red-600">Denda Keterlambatan</span>
                    <span className="text-red-600">Rp {selectedInvoice.lateFee.toLocaleString('id-ID')}</span>
                  </div>
                )}
                <div className="flex justify-between pt-2 border-t">
                  <span>Total</span>
                  <span className="text-blue-600">
                    Rp {(selectedInvoice.amount + (selectedInvoice.lateFee || 0)).toLocaleString('id-ID')}
                  </span>
                </div>
              </div>

              <div className="flex justify-between items-center pt-4 border-t">
                <span>Status</span>
                {getStatusBadge(selectedInvoice.status)}
              </div>

              <Button
                variant="outline"
                className="w-full"
                onClick={() => setSelectedInvoice(null)}
              >
                Tutup
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
