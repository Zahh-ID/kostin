import { useState, useEffect } from "react";
import { Plus, AlertCircle, Clock, CheckCircle, XCircle, MessageSquare } from "lucide-react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader } from "./ui/card";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "./ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { toast } from "sonner@2.0.3";
import { projectId } from "../utils/supabase/info";
import { createClient } from "../utils/supabase/client";

interface TicketingPageProps {
  onNavigate: (path: string) => void;
  userRole: string;
}

export function TicketingPage({ onNavigate, userRole }: TicketingPageProps) {
  const [tickets, setTickets] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState<any>(null);
  const [comment, setComment] = useState("");
  const [formData, setFormData] = useState({
    category: "technical",
    subject: "",
    description: "",
    priority: "medium",
  });
  const supabase = createClient();

  useEffect(() => {
    fetchTickets();
  }, []);

  const fetchTickets = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session?.access_token) {
        toast.error("Silakan login terlebih dahulu");
        onNavigate("/login");
        return;
      }

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-dbd6b95a/tickets`,
        {
          headers: {
            Authorization: `Bearer ${session.access_token}`,
          },
        }
      );

      const data = await response.json();

      if (response.ok) {
        setTickets(data.tickets);
      } else {
        throw new Error(data.error);
      }
    } catch (error: any) {
      console.error("Fetch tickets error:", error);
      toast.error(error.message || "Gagal memuat tiket");
    } finally {
      setLoading(false);
    }
  };

  const createTicket = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session?.access_token) {
        toast.error("Silakan login terlebih dahulu");
        return;
      }

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-dbd6b95a/tickets`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${session.access_token}`,
          },
          body: JSON.stringify(formData),
        }
      );

      const data = await response.json();

      if (response.ok) {
        toast.success("Tiket berhasil dibuat");
        setShowCreateDialog(false);
        resetForm();
        fetchTickets();
      } else {
        throw new Error(data.error);
      }
    } catch (error: any) {
      console.error("Create ticket error:", error);
      toast.error(error.message || "Gagal membuat tiket");
    }
  };

  const updateTicketStatus = async (ticketId: string, status: string) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session?.access_token) {
        toast.error("Silakan login terlebih dahulu");
        return;
      }

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-dbd6b95a/tickets/${ticketId}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${session.access_token}`,
          },
          body: JSON.stringify({ status }),
        }
      );

      const data = await response.json();

      if (response.ok) {
        toast.success("Status tiket diupdate");
        fetchTickets();
        if (selectedTicket?.id === ticketId) {
          setSelectedTicket(data.ticket);
        }
      } else {
        throw new Error(data.error);
      }
    } catch (error: any) {
      console.error("Update ticket error:", error);
      toast.error(error.message || "Gagal update status tiket");
    }
  };

  const addComment = async () => {
    if (!comment.trim() || !selectedTicket) return;

    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session?.access_token) {
        toast.error("Silakan login terlebih dahulu");
        return;
      }

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-dbd6b95a/tickets/${selectedTicket.id}/comments`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${session.access_token}`,
          },
          body: JSON.stringify({ comment }),
        }
      );

      const data = await response.json();

      if (response.ok) {
        toast.success("Komentar ditambahkan");
        setComment("");
        setSelectedTicket(data.ticket);
        fetchTickets();
      } else {
        throw new Error(data.error);
      }
    } catch (error: any) {
      console.error("Add comment error:", error);
      toast.error(error.message || "Gagal menambahkan komentar");
    }
  };

  const resetForm = () => {
    setFormData({
      category: "technical",
      subject: "",
      description: "",
      priority: "medium",
    });
  };

  const getStatusConfig = (status: string) => {
    const configs = {
      open: { icon: AlertCircle, label: "Open", className: "bg-blue-100 text-blue-700" },
      in_review: { icon: Clock, label: "In Review", className: "bg-yellow-100 text-yellow-700" },
      escalated: { icon: AlertCircle, label: "Escalated", className: "bg-red-100 text-red-700" },
      resolved: { icon: CheckCircle, label: "Resolved", className: "bg-green-100 text-green-700" },
      rejected: { icon: XCircle, label: "Rejected", className: "bg-gray-100 text-gray-700" },
    };
    return configs[status as keyof typeof configs] || configs.open;
  };

  const getPriorityBadge = (priority: string) => {
    const configs = {
      low: { label: "Low", className: "bg-gray-100 text-gray-700" },
      medium: { label: "Medium", className: "bg-blue-100 text-blue-700" },
      high: { label: "High", className: "bg-orange-100 text-orange-700" },
      urgent: { label: "Urgent", className: "bg-red-100 text-red-700" },
    };
    const config = configs[priority as keyof typeof configs] || configs.medium;
    return <Badge className={config.className}>{config.label}</Badge>;
  };

  const getCategoryLabel = (category: string) => {
    const labels = {
      abuse: "Abuse",
      payment: "Pembayaran",
      content: "Konten",
      technical: "Teknis",
    };
    return labels[category as keyof typeof labels] || category;
  };

  const ticketsByStatus = {
    open: tickets.filter(t => t.status === 'open'),
    in_review: tickets.filter(t => t.status === 'in_review'),
    escalated: tickets.filter(t => t.status === 'escalated'),
    resolved: tickets.filter(t => t.status === 'resolved'),
    rejected: tickets.filter(t => t.status === 'rejected'),
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Memuat tiket...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="mb-2">Ticketing & Moderasi</h1>
            <p className="text-gray-600">
              {userRole === 'admin' ? 'Kelola semua tiket moderasi' : 'Laporkan masalah dan lacak status'}
            </p>
          </div>
          <Button onClick={() => setShowCreateDialog(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Buat Tiket
          </Button>
        </div>

        {userRole === 'admin' ? (
          // Kanban Board for Admin
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            {Object.entries(ticketsByStatus).map(([status, statusTickets]) => {
              const statusConfig = getStatusConfig(status);
              const Icon = statusConfig.icon;
              
              return (
                <div key={status} className="space-y-3">
                  <div className="flex items-center gap-2 px-3 py-2 bg-white rounded-lg border">
                    <Icon className="h-4 w-4" />
                    <span className="font-medium">{statusConfig.label}</span>
                    <Badge variant="outline" className="ml-auto">{statusTickets.length}</Badge>
                  </div>
                  
                  <div className="space-y-2">
                    {statusTickets.map((ticket) => (
                      <Card
                        key={ticket.id}
                        className="cursor-pointer hover:shadow-md transition-shadow"
                        onClick={() => setSelectedTicket(ticket)}
                      >
                        <CardContent className="p-3 space-y-2">
                          <div className="flex items-start justify-between gap-2">
                            <p className="font-medium text-sm line-clamp-2">{ticket.subject}</p>
                            {getPriorityBadge(ticket.priority)}
                          </div>
                          <div className="flex items-center gap-2 text-xs text-gray-600">
                            <Badge variant="outline" className="text-xs">
                              {getCategoryLabel(ticket.category)}
                            </Badge>
                            <span>#{ticket.id.slice(-6)}</span>
                          </div>
                          <p className="text-xs text-gray-500">
                            {ticket.reporterName}
                          </p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          // List View for Tenant/Owner
          <div className="space-y-4">
            {tickets.length === 0 ? (
              <Card>
                <CardContent className="p-12 text-center">
                  <AlertCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="mb-2 text-gray-900">Belum ada tiket</h3>
                  <p className="text-gray-600 mb-4">
                    Buat tiket untuk melaporkan masalah atau mengajukan pertanyaan
                  </p>
                  <Button onClick={() => setShowCreateDialog(true)}>
                    <Plus className="h-4 w-4 mr-2" />
                    Buat Tiket Pertama
                  </Button>
                </CardContent>
              </Card>
            ) : (
              tickets.map((ticket) => {
                const statusConfig = getStatusConfig(ticket.status);
                const Icon = statusConfig.icon;
                
                return (
                  <Card
                    key={ticket.id}
                    className="cursor-pointer hover:shadow-md transition-shadow"
                    onClick={() => setSelectedTicket(ticket)}
                  >
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h3 className="text-lg m-0">{ticket.subject}</h3>
                            <Badge className={statusConfig.className}>
                              <Icon className="h-3 w-3 mr-1" />
                              {statusConfig.label}
                            </Badge>
                          </div>
                          <p className="text-gray-600 mb-2">{ticket.description}</p>
                          <div className="flex items-center gap-3 text-sm text-gray-500">
                            <Badge variant="outline">{getCategoryLabel(ticket.category)}</Badge>
                            {getPriorityBadge(ticket.priority)}
                            <span>#{ticket.id.slice(-8)}</span>
                            <span>•</span>
                            <span>
                              {new Date(ticket.createdAt).toLocaleDateString('id-ID')}
                            </span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })
            )}
          </div>
        )}

        {/* Create Ticket Dialog */}
        <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Buat Tiket Baru</DialogTitle>
              <DialogDescription>
                Laporkan masalah atau ajukan pertanyaan kepada tim moderasi
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="category">Kategori *</Label>
                  <Select value={formData.category} onValueChange={(value) => setFormData({ ...formData, category: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="technical">Teknis</SelectItem>
                      <SelectItem value="payment">Pembayaran</SelectItem>
                      <SelectItem value="content">Konten</SelectItem>
                      <SelectItem value="abuse">Abuse</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="priority">Prioritas *</Label>
                  <Select value={formData.priority} onValueChange={(value) => setFormData({ ...formData, priority: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="urgent">Urgent</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="subject">Subjek *</Label>
                <Input
                  id="subject"
                  placeholder="Ringkasan masalah..."
                  value={formData.subject}
                  onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Deskripsi *</Label>
                <Textarea
                  id="description"
                  placeholder="Jelaskan masalah secara detail..."
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows={5}
                />
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
                Batal
              </Button>
              <Button onClick={createTicket}>Buat Tiket</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Ticket Detail Dialog */}
        <Dialog open={!!selectedTicket} onOpenChange={() => setSelectedTicket(null)}>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            {selectedTicket && (
              <>
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-3">
                    {selectedTicket.subject}
                    <Badge className={getStatusConfig(selectedTicket.status).className}>
                      {getStatusConfig(selectedTicket.status).label}
                    </Badge>
                  </DialogTitle>
                  <DialogDescription>
                    Tiket #{selectedTicket.id.slice(-8)} • {getCategoryLabel(selectedTicket.category)} • {selectedTicket.reporterName}
                  </DialogDescription>
                </DialogHeader>

                <div className="space-y-6 py-4">
                  {/* Description */}
                  <div>
                    <Label className="mb-2 block">Deskripsi</Label>
                    <p className="text-gray-700">{selectedTicket.description}</p>
                  </div>

                  {/* Admin Actions */}
                  {userRole === 'admin' && selectedTicket.status !== 'resolved' && selectedTicket.status !== 'rejected' && (
                    <div className="flex gap-2 p-4 bg-gray-50 rounded-lg">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => updateTicketStatus(selectedTicket.id, 'in_review')}
                        disabled={selectedTicket.status === 'in_review'}
                      >
                        Tinjau
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => updateTicketStatus(selectedTicket.id, 'escalated')}
                        disabled={selectedTicket.status === 'escalated'}
                      >
                        Eskalasi
                      </Button>
                      <Button
                        size="sm"
                        onClick={() => updateTicketStatus(selectedTicket.id, 'resolved')}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        Selesaikan
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => updateTicketStatus(selectedTicket.id, 'rejected')}
                        className="text-red-600 hover:text-red-700"
                      >
                        Tolak
                      </Button>
                    </div>
                  )}

                  {/* Timeline/Events */}
                  <div>
                    <Label className="mb-3 block">Timeline</Label>
                    <div className="space-y-3">
                      {selectedTicket.events?.map((event: any, index: number) => (
                        <div key={index} className="flex gap-3 text-sm">
                          <div className="flex-shrink-0 w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
                          <div className="flex-1">
                            <p className="font-medium">{event.userName}</p>
                            <p className="text-gray-600">
                              {event.type === 'created' && 'Membuat tiket'}
                              {event.type === 'status_changed' && `Mengubah status ke ${event.newStatus}`}
                              {event.type === 'comment' && event.comment}
                            </p>
                            <p className="text-xs text-gray-500">
                              {new Date(event.timestamp).toLocaleString('id-ID')}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Add Comment */}
                  <div>
                    <Label htmlFor="comment" className="mb-2 block">Tambah Komentar</Label>
                    <div className="flex gap-2">
                      <Textarea
                        id="comment"
                        placeholder="Tulis komentar..."
                        value={comment}
                        onChange={(e) => setComment(e.target.value)}
                        rows={2}
                        className="flex-1"
                      />
                      <Button onClick={addComment} disabled={!comment.trim()}>
                        <MessageSquare className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
